#!/bin/bash 

function usage() 
{
    echo " Usage : "
    echo "   bash swarm_run.sh deploy parameter_len sampling_rate individual_list_address "
    echo "   bash swarm_run.sh append append_individual_list_address "
    echo "   bash swarm_run.sh renew swarm_parameter_address local_epoch individual_rank "
    echo " "
    echo " "
    echo "examples : "
    echo "   bash swarm_run.sh deploy 100 70 C:\\Users\\Administrator\\Desktop\\01.txt "
    echo "   bash swarm_run.sh append  C:\\Users\\Administrator\\Desktop\\01.txt "
    echo "   bash swarm_run.sh renew  C:\\Users\\Administrator\\Desktop\\01.txt 0 0 "
    exit 0
}

    case $1 in
    deploy)
            [ $# -lt 4 ] && { usage; }
            ;;
    append)
            [ $# -lt 2 ] && { usage; }
            ;;
    renew)
            [ $# -lt 4 ] && { usage; }
            ;;
    *)
        usage
            ;;
    esac

    java -Djdk.tls.namedGroups="secp256k1" -cp 'apps/*:conf/:lib/*' org.fisco.bcos.swarm.client.SwarmClient $@

