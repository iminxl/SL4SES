import os
import numpy as np 
import pandas as pd 
import torch 
import torch.nn.functional as F 

from models.gruNet import get_gru2
from utils.plot_utils import plot_curve, plot_sample
from utils.utils import build_optimizer 

def train_x(args, trainLoader, valLoader, log_path, scaler, device = torch.device('cpu')):
    model = get_gru2(args).to(device)

    trainable_parameters = list(model.parameters())
    scheduler, opt = build_optimizer(args, trainable_parameters)

    Train_loss = []
    Evaluate_loss = []
    Lr = []

    modelPath = log_path + '/model'
    if not os.path.exists(modelPath):
        os.makedirs(modelPath)

    for epoch in range(args.epochs):
        #train(args, trainLoader, model, opt, scaler, device)

        tr_loss = train(args, trainLoader, model, opt, scaler, device)

        vl_loss = evaluate(args, valLoader, model, scaler, device)

        Train_loss.append(tr_loss)
        Evaluate_loss.append(vl_loss)

        if scheduler is not None:
            scheduler.step()

        for param_group in opt.param_groups:
            Lr.append(param_group['lr'])

        print('epoch: {}, tr_loss: {:7.4f}, vl_loss: {:7.4f}'.format(epoch, tr_loss, vl_loss))

        modelname = '_'.join(['model', str(epoch), '.ckpt'])
        torch.save(model.state_dict(), os.path.join(modelPath, modelname))


    obj= dict()
    obj['args'] = args
    obj['curves'] = dict()
    obj['curves']['train_loss'] = Train_loss
    obj['curves']['eval_loss'] = Evaluate_loss
    obj['lr'] = Lr

    plot_curve(obj['curves'], log_path + 'curves.png', keys = None, 
                clip = True, label_min = False, label_end = False)
    plot_curve(obj, log_path + 'lr.png',keys = ['lr'], 
                clip = False, label_min = False, label_end = False)

    df_out = dict()
    df_out['train_loss'] = Train_loss

    df_out['eval_loss'] = Evaluate_loss

    df = pd.DataFrame.from_dict(df_out, orient = 'index').transpose()
    df.to_csv(os.path.join(log_path, 'result.csv')) 


def train(args, dataLoader, model, opt, scaler, device):
    model.train()
    train_loss = 0

    for batch_idx, (data, target) in enumerate(dataLoader):
        data = data.float().to(device)
        target = target.float().to(device)

        opt.zero_grad()
        y_output = model(data)

        target_ = target.view(len(y_output), -1)

        loss = torch.nn.functional.mse_loss(y_output, target_)
        loss.backward()
        opt.step()

        # the shape of y_output is n_observations, n_features 

        r1, r2, r3 = data.size()

        data_r = data.reshape(r1 * r2, r3)
        target_r = target.reshape(r1 * r2, -1)
        
        #print('shape of data_r: ', data_r.size())
        #print('target_r: ', target_r.size())
        data_r_n = data_r.cpu().detach().numpy()
        target_r_n = target_r.cpu().detach().numpy()

        y_output_n = y_output.cpu().detach().numpy()

        #print('shape of y_output: ', y_output.size())

        #print('type of target_r_n: ', type(data_r_n))

        data_xy = np.concatenate((data_r_n, target_r_n), axis  = 1)
        #print('shape of data_xy: ', data_xy.shape)

        data_xy_p = np.concatenate((data_r_n, y_output_n), axis = 1)
        #print('shape of data_xy_p: ', data_xy_p.shape)

        data_xy_i = scaler.inverse_transform(data_xy)
        data_xy_p_i = scaler.inverse_transform(data_xy_p)

        #print(data_xy_i[0,:])
        #print(data_xy_p_i[0, :])

        label_i = data_xy_i[:,5]
        pred_i = data_xy_p_i[:,5]
        #print('shape of label_i: ', label_i.shape)
        #print('shape of pred_i: ', pred_i.shape)

        loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_i), torch.tensor(label_i))
        train_loss += loss_i.item()

    return train_loss /len(dataLoader)

def evaluate2(args, dataLoader, model, mu, std, device):
    model.eval()
    eval_loss = 0
    eval_loss_scaled = 0
    
    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(dataLoader):
            data = data.float().to(device)
            target = target.float().to(device)

            y_output = model(data)

            target_ = target.view(len(y_output), -1)

            loss = torch.nn.functional.mse_loss(y_output, target_)
            eval_loss_scaled += loss.item()

            
            r1, r2, r3 = data.size()
            
            data_r = data.reshape(r1 * r2, r3)
            
            target_r = target.reshape(r1 * r2, -1)
            
            data_r_n = data_r.cpu().detach().numpy()
            target_r_n = target_r.cpu().detach().numpy()
            y_output_n = y_output.cpu().detach().numpy()

            data_xy = np.concatenate((data_r_n, target_r_n), axis  = 1)
            data_xy_p = np.concatenate((data_r_n, y_output_n), axis = 1)

            data_xy_i = data_xy*std + mu
            data_xy_p_i = data_xy_p*std + mu

            label_i = data_xy_i[:,3]
            pred_i = data_xy_p_i[:,3]
            
            loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_i), torch.tensor(label_i))
            eval_loss += loss_i.item()

    return eval_loss_scaled/len(dataLoader), eval_loss /len(dataLoader)

def evaluate(args, dataLoader, model, scaler, device):
    model.eval()
    eval_loss = 0
    
    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(dataLoader):
            data = data.float().to(device)
            target = target.float().to(device)

            y_output = model(data)
            
            r1, r2, r3 = data.size()
            
            data_r = data.reshape(r1 * r2, r3)
            
            target_r = target.reshape(r1 * r2, -1)
            
            data_r_n = data_r.cpu().detach().numpy()
            target_r_n = target_r.cpu().detach().numpy()
            y_output_n = y_output.cpu().detach().numpy()

            data_xy = np.concatenate((data_r_n, target_r_n), axis  = 1)
            data_xy_p = np.concatenate((data_r_n, y_output_n), axis = 1)

            data_xy_i = scaler.inverse_transform(data_xy)
            data_xy_p_i = scaler.inverse_transform(data_xy_p)

            label_i = data_xy_i[:,5]
            pred_i = data_xy_p_i[:,5]
            
            loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_i), torch.tensor(label_i))
            eval_loss += loss_i.item()

    return eval_loss /len(dataLoader)


def evaluate3(args, dataLoader, model, scaler, device):
    model.eval()
    eval_loss = 0
    eval_loss_scaled = 0
    
    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(dataLoader):
            data = data.float().to(device)
            target = target.float().to(device)

            y_output = model(data)

            target_ = target.view(len(y_output), -1)

            loss = torch.nn.functional.mse_loss(y_output, target_)
            eval_loss_scaled += loss.item()

            ####
            
            r1, r2, r3 = data.size()
            
            data_r = data.reshape(r1 * r2, r3)
            
            target_r = target.reshape(r1 * r2, -1)
            
            data_r_n = data_r.cpu().detach().numpy()
            target_r_n = target_r.cpu().detach().numpy()
            y_output_n = y_output.cpu().detach().numpy()

            data_xy = np.concatenate((data_r_n, target_r_n), axis  = 1)
            data_xy_p = np.concatenate((data_r_n, y_output_n), axis = 1)

            data_xy_i = scaler.inverse_transform(data_xy)
            data_xy_p_i = scaler.inverse_transform(data_xy_p)

            label_i = data_xy_i[:,3]
            pred_i = data_xy_p_i[:,3]
            
            loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_i), torch.tensor(label_i))
            eval_loss += loss_i.item()

    return eval_loss_scaled / len(dataLoader), eval_loss /len(dataLoader)

def predictCurve(args, dataLoader, model, scaler, device):
    model.eval()
    eval_loss = 0
    eval_loss_scaled = 0

    output_list = []
    data_list = []

    
    with torch.no_grad():
        for batch_idx, (data, target, data_c) in enumerate(dataLoader):
            data = data.float().to(device)
            target = target.float().to(device)

            y_output = model(data)

            target_ = target.view(len(y_output), -1)

            loss = torch.nn.functional.mse_loss(y_output, target_)
            eval_loss_scaled += loss.item()

            ####
            #print(f'shape of data: {data.size()}')
            #print(f'shape of data_c: {data_c.size()}')
            
            r1, r2, r3 = data.size()
            
            data_r = data.reshape(r1 * r2, r3)
            
            target_r = target.reshape(r1 * r2, -1)
            
            data_r_n = data_r.cpu().detach().numpy()
            target_r_n = target_r.cpu().detach().numpy()
            y_output_n = y_output.cpu().detach().numpy()

            data_xy = np.concatenate((data_r_n, target_r_n), axis  = 1)
            data_xy_p = np.concatenate((data_r_n, y_output_n), axis = 1)

            data_xy_i = scaler.inverse_transform(data_xy)
            data_xy_p_i = scaler.inverse_transform(data_xy_p)

            label_i = data_xy_i[:,5]
            pred_i = data_xy_p_i[:,5]

            output_list.append(pred_i)
            
            data_c_r = data_c.cpu().detach().numpy().reshape(r1*r2, -1)
            data_list.append(data_c_r)
            
            loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_i), torch.tensor(label_i))
            eval_loss += loss_i.item()

    return eval_loss_scaled / len(dataLoader), eval_loss /len(dataLoader), data_list, output_list


def predictCurve2(args, dataLoader, model, mu, std, device):
    model.eval()
    eval_loss = 0
    eval_loss_scaled = 0

    output_list = []
    data_list = []

    with torch.no_grad():
        for batch_idx, (data, target, data_c) in enumerate(dataLoader):
            data = data.float().to(device)
            target = target.float().to(device)

            y_output = model(data)

            target_ = target.view(len(y_output), -1)

            loss = torch.nn.functional.mse_loss(y_output, target_)
            eval_loss_scaled += loss.item()

            ####
            #print(f'shape of data: {data.size()}')
            #print(f'shape of data_c: {data_c.size()}')
            
            r1, r2, r3 = data.size()
            
            data_r = data.reshape(r1 * r2, r3)
            
            target_r = target.reshape(r1 * r2, -1)
            
            data_r_n = data_r.cpu().detach().numpy()
            target_r_n = target_r.cpu().detach().numpy()
            y_output_n = y_output.cpu().detach().numpy()

            data_xy = np.concatenate((data_r_n, target_r_n), axis  = 1)
            data_xy_p = np.concatenate((data_r_n, y_output_n), axis = 1)

            #data_xy_i = scaler.inverse_transform(data_xy)
            #data_xy_p_i = scaler.inverse_transform(data_xy_p)

            data_xy_i = data_xy * std + mu
            data_xy_p_i = data_xy_p * std + mu


            label_i = data_xy_i[:,5]
            pred_i = data_xy_p_i[:,5]

            output_list.append(pred_i)
            
            data_c_r = data_c.cpu().detach().numpy().reshape(r1*r2, -1)
            data_list.append(data_c_r)
            
            loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_i), torch.tensor(label_i))
            eval_loss += loss_i.item()

    return eval_loss_scaled / len(dataLoader), eval_loss /len(dataLoader), data_list, output_list
