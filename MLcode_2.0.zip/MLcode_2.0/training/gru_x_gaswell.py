import os
import numpy as np 
import pandas as pd 
import os.path as osp
import torch 
import torch.nn.functional as F 
import copy
from models.gruNet import get_gru3
from utils.plot_utils import plot_curve, plot_sample
from utils.utils import build_optimizer 
# from utils.dataReading_gaswell import inverse_transform_col

def train_x(args, trainLoader, valLoader, log_path, device = torch.device('cpu')):
    model = get_gru3(args).to(device)
    trainable_parameters = list(model.parameters())
    # scheduler, opt = build_optimizer(args, trainable_parameters)
    scheduler = None
    Train_loss = []
    Evaluate_loss = []
    Lr = []

    switch_noteffect = 0
    switch_times = 0
    switch_critria = args.switch_critria
    state =''
    lr = args.lr

    modelPath = log_path + '/model'
    if not os.path.exists(modelPath):
        os.makedirs(modelPath)

    for epoch in range(args.global_epochs):

        #train(args, trainLoader, model, opt, scaler, device)

        opt = torch.optim.Adam(model.parameters(), lr = lr, weight_decay = args.weight_decay)

        tr_loss = train(args, trainLoader, model, opt, device)

        vl_loss = evaluate(args, valLoader, model, device)

        Train_loss.append(tr_loss)
        Evaluate_loss.append(vl_loss)
        
        ##lr switch
        if min(Evaluate_loss)==vl_loss:
            state = 'best'
            switch_count = 0
            switch_noteffect = 0
            best_model = copy.deepcopy(model)
        else:
            switch_count += 1
            state = 'not best %d' % switch_count

        if switch_count >= switch_critria and epoch > args.min_epochs:
            lr /= 2
            switch_noteffect += 1
            model = copy.deepcopy(best_model)
            switch_times += 1
            switch_count = -args.switch_tol
            state = 'lr half %d time(s), not effect %d time(s)'% (switch_times,switch_noteffect)

        ##early stopping
        #min_vl_loss = min(Evaluate_loss)
        # criteria = 100*(Evaluate_loss[-1]/min_vl_loss-1)#all (x < y for x, y in zip(Evaluate_loss[-6:-2],Evaluate_loss[-5:-1]))
        criteria = (switch_noteffect >= args.switch_max_noteffect) or  (switch_times >= args.switch_max_times)
        print("Epoch %d, training_loss: %f, eval_loss: %f, state: %s" % (epoch, Train_loss[-1], Evaluate_loss[-1],state))
        args.final_epochs = epoch
        if epoch > args.min_epochs and criteria == True:  
            break

        if scheduler is not None:
            scheduler.step()

        for param_group in opt.param_groups:
            Lr.append(param_group['lr'])

    modelname = '_'.join(['model', str(epoch).rjust(3,'0'), '.ckpt'])
    torch.save(best_model.state_dict(), os.path.join(modelPath, modelname))

    obj= dict()
    obj['args'] = args
    obj['curves'] = dict()
    obj['curves']['train_loss'] = Train_loss
    obj['curves']['eval_loss'] = Evaluate_loss
    obj['lr'] = Lr

    plot_curve(obj['curves'], log_path + 'curves.png', keys = None, 
                clip = True, label_min = False, label_end = False)
    plot_curve(obj, log_path + 'lr.png',keys = ['lr'], 
                clip = False, label_min = False, label_end = False)

    df_out = dict()
    df_out['train_loss'] = Train_loss

    df_out['eval_loss'] = Evaluate_loss

    df = pd.DataFrame.from_dict(df_out, orient = 'index').transpose()
    df.to_csv(os.path.join(log_path, 'result.csv')) 
    return args


def train(args, dataLoader, model, opt, device):
    model.train()
    train_loss = 0

    for batch_idx, (data, target) in enumerate(dataLoader):
        data = data.float().to(device)
        target = target.float().to(device)

        opt.zero_grad()
        #print('shape of data: ', data.size())
        y_output = model(data)

        #print('shape of y_output: ', y_output.size())
        #print('shape of target: ', target.size())

        target_ = target.view(len(y_output), -1)

        loss = torch.nn.functional.mse_loss(y_output, target_)
        loss.backward()
        opt.step()

        loss_i = loss
        train_loss += loss_i.item()

    return train_loss /len(dataLoader)

def evaluate(args, dataLoader, model, device):
    model.eval()
    eval_loss = 0
    
    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(dataLoader):
            data = data.float().to(device)
            target = target.float().to(device)
            y_output = model(data)
            target_ = target.view(len(y_output), -1)
            loss = torch.nn.functional.mse_loss(y_output, target_)
            loss_i = loss
            eval_loss += loss_i.item()

    return eval_loss /len(dataLoader)


def evaluate3(args, dataLoader, model, scaler, device):
    model.eval()
    eval_loss = 0
    eval_loss_scaled = 0
    
    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(dataLoader):
            data = data.float().to(device)
            target = target.float().to(device)

            y_output = model(data)

            target_ = target.view(len(y_output), -1)

            loss = torch.nn.functional.mse_loss(y_output, target_)
            eval_loss_scaled += loss.item()

            ####
            
            r1, r2, r3 = data.size()
            
            data_r = data.reshape(r1 * r2, r3)
            
            target_r = target.reshape(r1 * r2, -1)
            
            data_r_n = data_r.cpu().detach().numpy()
            target_r_n = target_r.cpu().detach().numpy()
            y_output_n = y_output.cpu().detach().numpy()

            data_xy = np.concatenate((data_r_n, target_r_n), axis  = 1)
            data_xy_p = np.concatenate((data_r_n, y_output_n), axis = 1)

            data_xy_i = scaler.inverse_transform(data_xy)
            data_xy_p_i = scaler.inverse_transform(data_xy_p)

            label_i = data_xy_i[:,3]
            pred_i = data_xy_p_i[:,3]
            
            loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_i), torch.tensor(label_i))
            eval_loss += loss_i.item()

    return eval_loss_scaled / len(dataLoader), eval_loss /len(dataLoader)

def predictCurve(args, dataLoader, model, scaler, device, ratio, d):
    model.eval()
    eval_loss = 0
    eval_loss_scaled = 0

    data_list = []
    output_list = []
    
    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(dataLoader):
            data = data.float().to(device)
            target = target.float().to(device)

            y_output = model(data)

            target_ = target.view(len(y_output), -1)

            loss = torch.nn.functional.mse_loss(y_output, target_)
            eval_loss_scaled += loss.item()

            target_r_n = target_.cpu().detach().numpy()
            y_output_n = y_output.cpu().detach().numpy()
            
            pred_i = y_output_n
            label_i = target_r_n
            # pred_i = inverse_transform_col(scaler,y_output_n,-1)
            # label_i = inverse_transform_col(scaler,target_r_n,-1)
            data_list.extend(list(label_i.reshape(-1)))
            output_list.extend(list(pred_i.reshape(-1)))

        rl=np.array(data_list).reshape(-1)
        pre=np.array(output_list).reshape(-1)
        ratio=np.array(ratio).reshape(-1)
        d=np.array(d).reshape(-1)
        
        pred_arr = ratio[7:] /24 * (pre + d[6:-1])
        real_array = ratio[7:] /24 * (rl + d[6:-1])

        loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_arr), torch.tensor(real_array))
        eval_loss = loss_i.item()

    return eval_loss_scaled / len(dataLoader), eval_loss, list(real_array), list(pred_arr)

def predictCurve2(args, dataLoader, model, device, ratio, d):
    model.eval()
    eval_loss = 0
    eval_loss_scaled = 0

    data_list = []
    output_list = []
    
    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(dataLoader):
            data = data.float().to(device)
            target = target.float().to(device)

            y_output = model(data)

            target_ = target.view(len(y_output), -1)

            loss = torch.nn.functional.mse_loss(y_output, target_)
            eval_loss_scaled += loss.item()

            target_r_n = target_.cpu().detach().numpy()
            y_output_n = y_output.cpu().detach().numpy()
            
            pred_i = y_output_n
            label_i = target_r_n
            # pred_i = inverse_transform_col(scaler,y_output_n,-1)
            # label_i = inverse_transform_col(scaler,target_r_n,-1)
            data_list.extend(list(label_i.reshape(-1)))
            output_list.extend(list(pred_i.reshape(-1)))

        rl=np.array(data_list).reshape(-1)
        pre=np.array(output_list).reshape(-1)
        ratio=np.array(ratio).reshape(-1)
        d=np.array(d).reshape(-1)
        
        pred_arr = ratio[7:] /24 * (pre + d[6:-1])
        real_array = ratio[7:] /24 * (rl + d[6:-1])

        loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_arr), torch.tensor(real_array))
        eval_loss = loss_i.item()

        loss_i2 = torch.nn.functional.l1_loss(torch.tensor(pred_arr), torch.tensor(real_array))
        eval_loss2 = loss_i2.item()

    return eval_loss_scaled / len(dataLoader), eval_loss, eval_loss2, list(real_array), list(pred_arr)