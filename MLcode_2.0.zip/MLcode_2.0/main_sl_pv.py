import time 
import argparse 
import os 
os.environ['CUBLAS_WORKSPACE_CONFIG']=':16:8'
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
import numpy as  np 
import torch 
from torch.autograd import Variable
import warnings
warnings.filterwarnings('ignore')
from utils.dataset import SeqDataset3
torch.use_deterministic_algorithms(True) 
import pandas as pd 
import random 
from concurrent.futures import ThreadPoolExecutor
import threading
from utils.dataReading_pv import pv_data,getRank,getDataset_sl_full,evaluate
from utils.ssh_tool import ssh_cmd,ssh_get,ssh_put
from models.transformer import get_transformer2
from models.model_output import downloadparm,arr
from client_pv import Client
from utils.plot_utils import plot_curve
import matplotlib.pyplot as plt

def main():
    # T1=time.perf_counter()
    # args
    parser = argparse.ArgumentParser()

    parser.add_argument('--model', type = str, default = 'Transformer') #
    parser.add_argument('--d_model', type = int, default = 12) # Lattent dim
    parser.add_argument('--q', type = int, default = 8) # Query size
    parser.add_argument('--v', type = int, default = 8) # Value size
    parser.add_argument('--h', type = int, default = 2) # Number of heads
    parser.add_argument('--N', type = int, default = 1) # Number of encoder and decoder to stack
    parser.add_argument('--attention_size', type = int, default = None)#12 # Attention window size
    parser.add_argument('--pe', type = str, default = 'regular') # Positional encoding
    parser.add_argument('--chunk_mode', type = str, default = None)
    parser.add_argument('--d_input', type = int, default = 9)  # From dataset
    parser.add_argument('--d_output', type = int, default = 1)  # From dataset
                        
    parser.add_argument('--n_layers', type = int, default = 1)
    parser.add_argument('--opt', type = str, default = 'adam')
    parser.add_argument('--opt_scheduler', type=str, default='step')
    parser.add_argument('--opt_restart', type=int, default=0)
    parser.add_argument('--opt_decay_step', type=int, default=2000)
    parser.add_argument('--opt_decay_rate', type=float, default=0.9)
    parser.add_argument('--dropout', type=float, default=0.)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--lr', type=float, default=0.002)
    parser.add_argument('--momentum', type = float, default = 0.9)
    parser.add_argument('--seed', type=int, default=0)    
    parser.add_argument('--dataPath', type = str, default = '../data_pv')
    parser.add_argument('--logPath', type = str, default = '../log_pv/validation/sl')
    parser.add_argument('--logPath_ts', type = str, default = '../log_pv/test/sl')

    parser.add_argument('--num_feature', type = int, default = 9)
    parser.add_argument('--batch_size', type = int, default = 512)
    parser.add_argument('--lambda_',type = float, default = 1)
    parser.add_argument('--use_forcast_weather', type = int, default = 1)

    parser.add_argument('--local_epochs', type = int, default = 1)
    parser.add_argument('--global_epochs', type = int, default = 100)

    parser.add_argument('--train_len', type = int, default = 48)
    parser.add_argument('--predict_len', type = int, default = 12)
    parser.add_argument('--input_dim', type = int, default = 9)
    parser.add_argument('--output_dim', type = int, default = 1)
    parser.add_argument('--fold_id', type = int, default = 0)

    parser.add_argument('--dataframes', type = int, default = 18)
    parser.add_argument('--testout_num', type = int, default = 3)

    parser.add_argument('--no_models', type = int, default = 15)#client num
    parser.add_argument('--k', type = int, default = 0)#aggregate num
    parser.add_argument('--locframe_num', type = int, default = 1)
    parser.add_argument('--crit',type = float, default = 0.5)

    args = parser.parse_args()

    #select device
    if torch.cuda.is_available():
        device = torch.device('cuda')
    else:
        device = torch.device('cpu')
    # device = torch.device('cpu')
    seed = args.seed 
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # feature and dataloader
    nodein_list,testout_list = getRank(args.dataframes,args.testout_num,args.fold_id,args.no_models,args.locframe_num)
    use_list = [j for j in [i for item in nodein_list for i in item]]
    data = pv_data(args,use_list)
    mu = 0; std =1

    data_tr_dict,data_tr,data_vl,data_ts_in_dict,data_ts_out_dict,n_total = getDataset_sl_full(args.dataPath, nodein_list, testout_list, args.no_models, args.locframe_num, data.data_origin, data.data_input_list, data.data_output_list, args)
    #print(f'type of data_tr_dict: {data_tr_dict}')

    trainDataLoader_dict = {}
    for name, param in data_tr_dict.items():
        trainDataLoader_dict[name] = torch.utils.data.DataLoader(param, batch_size = args.batch_size, shuffle = False)
    
    trainDataLoader = torch.utils.data.DataLoader(data_tr, batch_size = args.batch_size, shuffle = False)

    evalDataLoader = torch.utils.data.DataLoader(data_vl, batch_size = args.batch_size, shuffle = False)

    #log&model path
    str_lr = '_'.join(['lr', str(args.lr)])
    str_seed = '_'.join(['seed', str(args.seed)])

    log_path = args.logPath + '/{}/{}/{}clients/{}frames/fold_{}/'.format(str_lr, str_seed, args.no_models, args.locframe_num, args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    model_path = log_path + '/model'
    if not os.path.exists(model_path):
        os.makedirs(model_path)
    
    # args record -> log path
    args_dict = vars(args)
    with open(os.path.join(log_path, 'args.txt'), 'w') as f:
        for key, value in args_dict.items():
            f.write('{}:{}'.format(key, value))
            f.write('\n')
    
    #create server and clients
    global_model=get_transformer2(args).to(device)

    parmlist = []
    for name,parameters in global_model.state_dict().items():

        parmlist.extend(parameters.cpu().flatten().detach().numpy().tolist())
        parmarray=np.array(parmlist)

    clients = []
    time_array=np.zeros(args.no_models+1)
    for c in range(args.no_models):
        clients.append(Client(args, c, device))
    
    Train_loss = []
    Eval_loss = []
    epoch_ = []
    lr_ = []
    lr = args.lr
    
    command_start="cd fisco;bash nodes/127.0.0.1/start_all.sh;"
    command_0 = "cd ~/fisco/swarm-app-main/dist;"
    command_deploy = "bash swarm_run.sh deploy {} 100 /Users/xulei/Desktop/java_io/name.txt".format(len(parmarray))
    ssh_cmd(command_start,1)
    ssh_cmd(command_0+command_deploy,1)
    command_merge="bash swarm_run.sh merge"    
    # global loop
    T1=time.perf_counter()
    for e in range(args.global_epochs):
        # ssh_put('./0.txt',getfile)
        if args.k ==0:
            candidates=clients
        else:
            candidates = random.sample(clients, args.k)
            candidates = sorted(candidates,key=(lambda x:x.client_id))
        total_loss = 0.0
        par_arr_accumulator = np.zeros_like(parmarray)        
        pool=ThreadPoolExecutor(max_workers=args.no_models)

        # local loop需要分别计时
        work=[0]*args.no_models
        for c in candidates:
            work[c.client_id]=pool.submit(local_train,global_model,c,seed,lr,trainDataLoader_dict,mu,std,n_total)
            # exec("work"+str(c.client_id)+"=pool.submit(local_train,c,seed,lr,server,trainDataLoader_dict,mu,std,n_total)")
            
        pool.shutdown()

        # parmlen=work[0].result()[3]
        for i_ in range(args.no_models):
            time_array[i_]+=work[i_].result()[0]
            # exec("time_array[i_]+=work"+str(i_)+".result()[0]")
            
            # ctime=time.perf_counter()
            # id_ = c.client_id
            # #print(' ')
            # #print(' ')
            # #print(f'id_: {id_}') 
            
            # random.seed(seed)
            # np.random.seed(seed)
            # torch.manual_seed(seed)
            # diff, loss_a = c.local_train(lr, server.global_model, trainDataLoader_dict[id_], mu, std, n_total)
            loc_diff=work[i_].result()[1]
            loc_par_arr,parmlen=arr(loc_diff)
            par_arr_accumulator+=loc_par_arr
            total_loss+=work[i_].result()[2]
            # exec("total_loss=work"+str(i_)+".result()[2]",globals())
            #weight  select

        # aggregate and evaluate需要通讯计时
        stime=time.perf_counter()
        # par_arr_accumulator/=args.no_models
        agg_par_arr = np.floor(par_arr_accumulator)
        # ssh_cmd(command_0+command_merge)
        mgd_file="array.txt"
        getfile,tar2="/Users/xulei/Desktop/java_io/"+mgd_file,\
            'C:/Users/iminx/Desktop/sl_sm/code/'+mgd_file
        ssh_get(getfile,tar2)
        # global_model=loadparm(mgd_file,global_model,args.no_models,parmlen,8)
        global_model=downloadparm(agg_par_arr,global_model,args.no_models,parmlen,8)
        time_array[-1]=time.perf_counter()-stime
        
        loss = local_eval(lr, global_model, evalDataLoader, 0, 1, args, device)
        # print("Epoch %d, training_loss: %f, validating_loss: %f" % (e, total_loss/len(candidates), loss))
        #print(' ')
        #print(' ')
        
        Train_loss.append(total_loss /len(candidates))
        Eval_loss.append(loss)
        epoch_.append(e)
        lr_.append(lr)
        
        ##early stopping
        min_vl_loss = min(Eval_loss)
        criteria = 100*(Eval_loss[-1]/min_vl_loss-1)
        print("Epoch %d, training_loss: %f, eval_loss: %f, stopping_criteria: %f" % (e, Train_loss[-1], Eval_loss[-1],criteria))
        args.final_epochs = e

        #lr adjust
        if(e != 0 and e %args.opt_decay_step == 0):
            lr = lr * args.opt_decay_rate
        
        #save model
        modelname = '_'.join(['model', str(e).rjust(3,'0'), '.ckpt'])
        torch.save(global_model.state_dict(), os.path.join(model_path, modelname))

    # df -> logpath
    df_out = dict()
    df_out['epoch'] = epoch_
    df_out['train_loss'] = Train_loss
    df_out['eval_loss'] = Eval_loss

    obj = dict()
    obj['args']= args 
    obj['curves'] = dict()
    obj['curves']['train_loss'] = Train_loss
    obj['curves']['eval_loss'] = Eval_loss
    obj['lr'] = lr_
    
    plot_curve(obj, log_path + 'lr.png', keys = ['lr'], clip = False, label_min = False, label_end = False)
    
    plot_curve(obj['curves'], log_path + 'curves.png', keys = None, clip = True, label_min = False, label_end = False)

    df = pd.DataFrame.from_dict(df_out, orient = 'index').transpose()
    df.to_csv(os.path.join(log_path, 'result.csv'))
        
    T2=time.perf_counter()
    TT=T2-T1
    print('Program execution time:%s second'%(TT))
    for i_ in range(args.no_models):
        print('Program execution time of client %s :%s second'%(i_,time_array[i_]))
    print('Program execution time of server :%s second'%(time_array[-1]))
    with open(os.path.join(log_path, 'args.txt'), 'a') as f:
        f.write('Program execution time:{}'.format(TT))
        for i_ in range(args.no_models):
            f.write('Program execution time of client %s :%s second'%(i_,time_array[i_]))
            f.write('\n')
        f.write('Program execution time of server :%s second'%(time_array[-1]))

    # evaluate(args, global_model, nodein_list, testout_list, data)

def local_train(global_model,c,seed,lr,trainDataLoader_dict,mu,std,n_total):
    ctime=time.perf_counter()
    id_ = c.client_id
    filepath="client"+str(id_)+".csv"
    #print(' ')
    #print(' ')
    # print(f'id_: {id_}') 
    diff = {}

    # random.seed(seed)
    # np.random.seed(seed)
    # torch.manual_seed(seed)
    diff, loss_a = c.local_train(lr, global_model, trainDataLoader_dict[id_], mu, std, n_total)
    # parmlen=saveparm(diff,filepath)
    upfile,tar1='C:/Users/iminx/Desktop/sl_sm/code/'+filepath,\
        "/Users/xulei/Desktop/Jiang_FL/code_NorthDakota/code_NorthDakota/"+filepath
    ssh_put(upfile,tar1)
    command_renew ="bash swarm_run.sh renew /Users/xulei/Desktop/Jiang_FL/code_NorthDakota/code_NorthDakota/"+filepath+" "+str(id_)
    command_0 = "cd ~/fisco/swarm-app-main/dist;"
    str1=command_0+command_renew
    ssh_cmd(str1)
    loacltime=time.perf_counter()-ctime
    return loacltime,diff,loss_a

def local_eval(lr, model, dataLoader, mu, std, args, device):

        opt = torch.optim.Adam(model.parameters(), lr = lr, weight_decay = args.weight_decay)
        model.eval()

        loss_a = []

        n_k = 0
        for e in range(1):
            train_loss = 0
            n_k = 0
            for batch_idx, (data, target) in enumerate(dataLoader):

                data = data.float().to(device)
                # print(f'input shape:{data.shape}')
                # print(f'target shape:{target.shape}')
                target = target.float().to(device)

                opt.zero_grad()
                y_output = model(data)
                y_output = y_output.reshape(-1,24,1)
                y_output = y_output[:,-args.predict_len:, :].reshape(-1,1)
                # print(f'output shape:{y_output.shape,len(y_output)}')
                target_ = target.view(len(y_output), -1)

                loss = torch.nn.functional.mse_loss(y_output, target_)
                loss.backward()
                opt.step()

                r1, r2, r3 = data.size()
                if target.dim() == 3:
                    r11,r22,r33 = target.size()
                elif target.dim() == 2:
                    r11,r22 = target.size()
                data_r = data[:,-r22:,:].reshape(r1 * r22, r3)
                target_r = target.reshape(r11 * r22, -1)
                y_output = y_output.reshape(r11 * r22, -1)

                data_r_n = data_r.cpu().detach().numpy()
                target_r_n = target_r.cpu().detach().numpy()
                y_output_n = y_output.cpu().detach().numpy()

                data_xy = np.concatenate((data_r_n, target_r_n), axis = 1)

                data_xy_p = np.concatenate((data_r_n, y_output_n), axis = 1)
                
                #print('shape of data_xy: ', data_xy.shape)
                #print('shape of data_r_n: ', data_r_n.shape)
                #print('shape of target_r_n: ', target_r_n.shape)
                #print('shape of mu: ', mu.shape)
                #print('shape of std: ', std.shape)
                #data_xy_i = scaler.inverse_transform(data_xy)

                data_xy_i = data_xy * std + mu

                #data_xy_p_i = scaler.inverse_transform(data_xy_p)
                data_xy_p_i = data_xy_p * std + mu

                label_i = data_xy_i[:, args.num_feature]
                pred_i = data_xy_p_i[:, args.num_feature]

                loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_i), torch.tensor(label_i))
                train_loss += loss_i.item()

                n_k += r11 * r22
 
            loss_a.append(train_loss / len(dataLoader))  
            
        return loss_a[-1]

if __name__ == '__main__':
    main()

