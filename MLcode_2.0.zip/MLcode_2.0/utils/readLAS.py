
import os
import pandas as pd
import numpy as np

import lasio
fdir= '../../GEOLINK_Lithology and wells NORTH SEA'
sdir = '../../read_out'
if(not os.path.exists(sdir)):
    os.makedirs(sdir)

ssdir = '../../read_out/DTS'
if(not os.path.exists(ssdir)):
    os.makedirs(ssdir)

hdir = '../../read_out/DTS/hold'
if (not os.path.exists(hdir)):
    os.makedirs(hdir)

flist = [ff for ff in os.listdir(fdir) if ff.endswith('.las')]
for fname in flist:
    s1 = fname.split('.')[0]
    sname = '.'.join([s1, 'csv'])
    las = lasio.read(os.path.join(fdir, fname))
    df = las.df()
    columns = df.columns
    if not ('NPHI' in columns):
        df['NPHI'] = [None] * len(df)
    if not ('DTC' in columns):
        df['DTC'] = [None] * len(df)
    if not ('RHOB' in columns):
        df['RHOB'] = [None] * len(df)
    if not ('GR' in columns):
        df['GR'] = [None] * len(df)
    if not ('DTS' in columns):
        df['DTS']=[None] * len(df)
        df.to_csv(os.path.join(sdir, sname))
    else:
        nphi = df['NPHI'].values
        dtc = df['DTC'].values
        dts = df['DTS'].values
        rhob = df['RHOB'].values
        gr = df['GR'].values

        flag10 = df['NPHI'].isna().all()
        flag11 = (not flag10) and (nphi > 1).any()

        flag20 = df['DTC'].isna().all()
        flag21 = (not flag20) and (dtc < 0).any()

        flag30 = df['DTS'].isna().all()
        flag31 = (not flag30) and (dts < 0).any()


        flag40 = df['RHOB'].isna().all()
        flag41 = (not flag40) and (rhob < 1.0).any()

        flag50 = df['GR'].isna().all()
        flag51 = (not flag50) and (gr < 0.0).any()


        if flag11 or flag21 or flag31 or flag41 or flag51:
            df.to_csv(os.path.join(hdir, sname))
        else:
            df.to_csv(os.path.join(ssdir, sname))



