import os
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 
import matplotlib  
from matplotlib.colors import ListedColormap 
import seaborn as sns 
import math 

def calResbywell(fdir):
    seed = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    filenameList = ['15_9-23', '25_10-9', '34_4-10 R', '34_12-1', '35_3-7 S', '35_9-9', '35_11-10']
    filename = 'result.csv'

    seedList = []
    fileList = []
    lossList = []
    scaledlossList = []
 
    for ff in filenameList:
        for sd in seed:
            sd_str = '_'.join(['seed', str(sd)])
            filepath = os.path.join(fdir, sd_str, ff, filename)
            df = pd.read_csv(filepath)
            seedList.append(sd)
            fileList.append(ff)
            lossList.append(df['test_loss'].values[0])
            scaledlossList.append(df['test_loss_scaled'].values[0])

    
    results_o = dict()
    results_o['seed'] = seedList
    results_o['filename'] = fileList
    results_o['test_loss'] = lossList
    results_o['scaledlossList'] = scaledlossList
    results_1 = pd.DataFrame(results_o)

    results_1.to_csv(os.path.join(fdir, 'results_bywell.csv'))





def calMSEloss(fdir):
    seed = [0, 1, 2, 3, 4, 5,6, 7, 8, 9]
    decayrate = [0.5, 0.7, 0.9]
    decaystep = [10, 30, 50, 70, 90]
    lrate = [1e-3]

    filename = 'result.csv'
    columns = ['train_loss', 'eval_loss']
    df_out = pd.DataFrame()

    for lr in lrate:
        lr_str = '_'.join(['lr', str(lr)])
        for sd in seed:
            sd_str = '_'.join(['seed', str(sd)])

            re_loss = dict()

            lr_list = []
            sd_list = []
            ds_list = []
            dr_list = []
            mseloss_list = []
            epoch_list = []


            for ds in decaystep:
                ds_str = '_'.join(['decaystep', str(ds)])

                for dr in decayrate:
                    dr_str = '_'.join(['decayrate', str(dr)])

                    path = os.path.join(fdir, lr_str, sd_str, ds_str, dr_str)
                    fpath = os.path.join(path, filename)
                    df = pd.read_csv(fpath)
                    values = df.values
                    #print('shape of values: ', values.shape)

                    c0 = '_'.join([columns[0], ds_str, dr_str])
                    tr_loss = df['train_loss'].values

                    #re_loss[c0] = tr_loss[0:100].tolist()
                    re_loss[c0] = tr_loss.tolist()

                    c1 = '_'.join([columns[1], ds_str, dr_str])
                    vl_loss = df['eval_loss'].values
                    #re_loss[c1] = vl_loss[0:100].tolist()
                    re_loss[c1] = vl_loss.tolist()


                    min_mseloss = min(re_loss[c1])
                    mseloss_index = re_loss[c1].index(min_mseloss)

                    lr_list.append(lr)
                    sd_list.append(sd)
                    ds_list.append(ds)
                    dr_list.append(dr)
                    mseloss_list.append(min_mseloss)
                    epoch_list.append(mseloss_index)

            result_loss = pd.DataFrame(re_loss)
            result_loss.to_csv(os.path.join(fdir, lr_str, sd_str, 'result_loss.csv'))


            results_o = dict()
            results_o['lr'] = lr_list
            results_o['seed'] = sd_list
            results_o['decay_step'] = ds_list
            results_o['decay_rate'] = dr_list
            results_o['epoch'] = epoch_list
            results_o['mse_loss'] = mseloss_list
            results_1 = pd.DataFrame(results_o)

            df_out = pd.concat([df_out, results_1], ignore_index = True)

            results_1.to_csv(os.path.join(fdir, lr_str, sd_str, 'results.csv'))

        df_out.to_csv(os.path.join(fdir, 'validation_results.csv'))

def calTestloss(fdir):
    seed = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    filename = 'result.csv'
    data = pd.DataFrame()
    for sd in seed:
        sd_str = '_'.join(['seed', str(sd)])
        fpath = os.path.join(fdir, sd_str, filename)
        df = pd.read_csv(fpath)
        data = pd.concat([data, df], ignore_index = True)

    data.to_csv(os.path.join(fdir, 'testing_100_results.csv'))



def main():
    """
    fdir = '../../log_newfeatureset/training/regular/MinMaxScaler/'
    calMSEloss(fdir)
    fdir = '../../log_newfeatureset/training/regular/StandardScaler/'
    calMSEloss(fdir)

    fdir = '../../log_newfeatureset/training/fl/MinMaxScaler/'
    calMSEloss(fdir)
    
    fdir = '../../log_newfeatureset/training/fl/StandardScaler/'
    calMSEloss(fdir)
    """

    #fdir = '../../log_newfeatureset/testing_19/regular/MinMaxScaler'
    #calTestloss(fdir)
    
    #fdir = '../../log_newfeatureset/testing_7de0_500/fl/StandardScaler'
    #calTestloss(fdir)

    #fdir = '../../log_newfeatureset/testing_19/fl/MinMaxScaler'
    #calTestloss(fdir)
    
    #fdir = '../../log_newfeatureset/testing_60_500/fl/StandardScaler'
    #calTestloss(fdir)

    fdir = '../../log/testing/hefl'
    calResbywell(fdir)


if __name__ == '__main__':
    main()