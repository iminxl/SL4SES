import numpy as np 
import math 

def Dpoly_degree(items):
    """
    items is a dictionary
    model.state_dict().items()
    """
    r_max = 0 
    for key, value in items:
        s = value.size()
        ln = s[0]
        if(len(s) == 2):
            ln = ln * s[1]

        if(ln > r_max):
            r_max = ln

    p = 2**int(math.ceil(np.log2(r_max))) * 2
    return p

