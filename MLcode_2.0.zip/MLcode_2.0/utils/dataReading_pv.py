import os 
import pandas as pd 
import numpy as np 
import random 
from utils.dataset import SeqDataset3
from models.transformer import get_transformer

import torch
from torch.autograd import Variable
import matplotlib.pyplot as plt

class pv_data:
    def __init__(self,args,uselist):
        # hyper parameters
        use_forcast_weather = args.use_forcast_weather # whether to use the forecast data, 1 means True, 0 means False

        data_origin = []
        data_list = [i for i in range(25)]
        for i in range (25):
            name = '../data_pv/data/'+ str(i+1).rjust(2,'0') +'.csv'
            #name = 'E:/Research CYT/grid/enlstm_code/ratio/data/data_day_'+ data_list[i] +'.csv'
            df = pd.read_csv(name)
            # print(df.shape)
            data_origin.append(df)
        print('shape of df',np.shape(np.array(df)))
        print(len(data_origin))
        use_forcast_weather = True
        features = ['elec_num','rh','u10','v10','t2m','ssrd','strd','tsr','tcc']
        data = []
        load_min = np.zeros((25, 9))
        load_max = np.zeros((25, 9))

        load_mean = np.zeros(12)
        for i in uselist:
            data_temp = data_origin[i][features]

            load_min[i] = data_temp.min(axis=0)
            load_min[i,1:]=0
            load_max[i] = data_temp.max(axis=0)
            load_max[i,1:]=0
            data_temp.loc[:,'elec_num'] -= load_min[i][0]
            data_temp.loc[:,'elec_num'] /= (load_max[i][0] - load_min[i][0])
            arr = np.array(data_temp['elec_num'])
            arr = arr.reshape(-1,12)
            mean = np.mean(arr,axis=0)
            load_mean += mean
        load_mean /= len(uselist)

        for i in range (25):
            print(i)
            data_temp = data_origin[i][features]

            load_min[i] = data_temp.min(axis=0)
            load_min[i,1:]=0
            load_max[i] = data_temp.max(axis=0)
            load_max[i,1:]=0
            data_temp.loc[:,'elec_num'] -= load_min[i][0]
            data_temp.loc[:,'elec_num'] /= (load_max[i][0] - load_min[i][0])
            num=len(data_temp['elec_num'])/12
            # arr_mean=np.tile(load_mean,int(num))
            # data_temp.loc[:,'elec_num'] -=arr_mean
            # data_temp.loc[:,'elec_num'] *=2
            data.append(data_temp)

        data_normal=[]
        data_input_list = []
        data_output_list = []

        for i in range (25):
            data_use = np.array(data[i])
            test_num = data[i].shape[0]
            next_tsr = np.zeros((test_num, 1))
            next_rh = np.zeros((test_num, 1))
            next_u10 = np.zeros((test_num, 1))
            next_v10 = np.zeros((test_num, 1))
            next_t2m = np.zeros((test_num, 1))
            data_output = np.zeros((test_num-12,1))
            if use_forcast_weather == True:
                next_tsr[:-12] = np.array(data[i]['tsr']).reshape(-1,1)[12:]
                next_rh[:-12] = np.array(data[i]['rh']).reshape(-1,1)[12:]
                next_u10[:-12] = np.array(data[i]['u10']).reshape(-1,1)[12:]
                next_v10[:-12] = np.array(data[i]['v10']).reshape(-1,1)[12:]
                next_t2m[:-12] = np.array(data[i]['t2m']).reshape(-1,1)[12:]
            # generate the whole dataset
            if use_forcast_weather == True:
                data_input_all = np.concatenate((data_use, next_tsr, next_rh, next_u10, next_v10, next_t2m),axis=1)
                #load_normal 0,1,2,3, rain 4, Sat 5, Mon 6,   date 7:18, weekend 19
            else:
                data_input_all = data_use
            # generate data_input
            delet_ID = np.arange(test_num-12,test_num)
            data_input = np.delete(data_input_all,delet_ID,0)
            if use_forcast_weather == True:
                data_input = np.delete( data_input,[1,2,3,4,7],1)

            # load_min[i] = data_temp.min(axis=0)
            # load_max[i] = data_temp.max(axis=0)
            # 9 inputs
            data_input_list.append(data_input)
            # generate data_output
            for i in range (test_num-12):
                data_output[i] = data_use[i+12,0]
            data_output_list.append(data_output)
        self.data_origin = data_origin
        self.data_input_list = data_input_list
        self.data_output_list = data_output_list
        self.load_min = load_min
        self.load_max = load_max
        self.data_list = data_list
        self.load_mean = load_mean

def getRank(dataset_len,testout_num,testout_rank,locnode_num,locframe_num):
    
    fold_num=dataset_len/testout_num
    all_list=list(range(0,dataset_len))
    testout_list=[all_list[i:i+testout_num] for i in range(0,dataset_len,testout_num)][testout_rank]
    
    in_list=list(set(all_list)-set(testout_list))
    o_list=random.sample(in_list,testout_num)

    in_list=list(set(in_list)-set(o_list))
    nodein_list=[[i] for i in o_list]
    if locframe_num == 1:
        for i in range(testout_num,locnode_num):
            app_list=random.sample(in_list,1)
            in_list=list(set(in_list)-set(app_list))
            nodein_list.append(app_list)
        nodein_list=sorted(nodein_list,key=(lambda x:x[0]))
    else:
        for _ in range(1,locframe_num):
            app_list=random.sample(in_list,locnode_num)
            in_list=list(set(in_list)-set(app_list))
            for i in range(locnode_num):
                nodein_list[i].append(app_list[i])
        nodein_list=sorted(nodein_list,key=(lambda x:x[0]))
        for i in range(locnode_num):
            nodein_list[i]=sorted(nodein_list[i])
    return nodein_list,testout_list

def loadDataSeq_num(num, data_id, data_origin, data_in_list, data_out_list, args):
    train_data_input = None
    train_data_output = None
    for k in (data_id):
        # get the k th train date
        table_input = data_in_list [k]
        table_output = data_out_list [k]
        # calcute the length of training set
        len_num = int((data_origin[k].shape[0]/12)-(args.train_len/12))
        numlist=[0,len_num-60*2,len_num-60*1,len_num]

        # generate train_data_input
        train_data_input_temp = np.zeros((len_num, args.train_len, args.input_dim))
        for i in range (numlist[num],numlist[num+1]):
            if num == 0:
                if i <= numlist[num+1]*args.prop:
                    for j in range (args.input_dim):
                        train_data_input_temp[i,:,j] = table_input[:,j][(i*12):((i*12)+args.train_len)]
            else:
                    for j in range (args.input_dim):
                        train_data_input_temp[i,:,j] = table_input[:,j][(i*12):((i*12)+args.train_len)]                
        if train_data_input is None:
            train_data_input = train_data_input_temp
        else:
            train_data_input = np.concatenate((train_data_input, train_data_input_temp), axis = 0)
        
        # generate train_data_output
        train_data_output_temp = np.zeros((len_num, args.train_len, args.output_dim)) 
        for i in range (numlist[num],numlist[num+1]):
            for j in range (args.output_dim):
                train_data_output_temp[i,:,j] = table_output[:,j][(i*12):((i*12)+args.train_len)]
        if train_data_output is None:
            train_data_output = train_data_output_temp
        else:
            train_data_output = np.concatenate((train_data_output, train_data_output_temp), axis = 0)

    return train_data_input, train_data_output 

def loadDataSeq_pv(data_id, data_origin, data_in_list, data_out_list, args):
    train_data_input = None
    train_data_output = None
    for k in (data_id):
        # get the k th train date
        table_input = data_in_list [k]
        table_output = data_out_list [k]
        # calcute the length of training set
        len_num = int((data_origin[k].shape[0]/12)-(args.train_len/12))
        
        # generate train_data_input
        train_data_input_temp = np.zeros((len_num, args.train_len, args.input_dim))
        for i in range (len_num):
            for j in range (args.input_dim):
                train_data_input_temp[i,:,j] = table_input[:,j][(i*12):((i*12)+args.train_len)]
        if train_data_input is None:
            train_data_input = train_data_input_temp
        else:
            train_data_input = np.concatenate((train_data_input, train_data_input_temp), axis = 0)
        
        # generate train_data_output
        train_data_output_temp = np.zeros((len_num, args.train_len, args.output_dim)) 
        for i in range (len_num):
            for j in range (args.output_dim):
                train_data_output_temp[i,:,j] = table_output[:,j][(i*12):((i*12)+args.train_len)]
        if train_data_output is None:
            train_data_output = train_data_output_temp
        else:
            train_data_output = np.concatenate((train_data_output, train_data_output_temp), axis = 0)

    return train_data_input, train_data_output 

def getDataset_loc(data_origin, data_in_list, data_out_list, args):

    x_tr, y_tr = loadDataSeq_num(0,[args.model_rank], data_origin, data_in_list, data_out_list, args)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr[:, -args.predict_len:, :])) 

    x_vl, y_vl = loadDataSeq_num(1,[args.model_rank], data_origin, data_in_list, data_out_list, args)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl[:, -args.predict_len:, :]))
    
    return data_tr, data_vl

def getDataset_locmulti(nodein_list,data_origin,data_in_list, data_out_list, args):

    uselist=nodein_list[args.model_rank]

    x_tr, y_tr = loadDataSeq_num(0,[j for j in uselist], data_origin, data_in_list, data_out_list, args)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr[:, -args.predict_len:, :])) 

    x_vl, y_vl = loadDataSeq_num(1,[j for j in uselist], data_origin, data_in_list, data_out_list, args)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl[:, -args.predict_len:, :])) 

    name=args.model_rank

    return data_tr,data_vl,name

def getDataset_sl_full(dataDir,nodein_list,testout_list,locnode_num,locframe_num, data_origin, data_in_list, data_out_list, args):
    filelist=os.listdir(dataDir)
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    data_tr_dict = {}
    data_ts_dict = {}
    data_ts_in_dict = {}
    data_ts_out_dict = {}

    n_total = 0
    counter=0
    for i in range(locnode_num):
        x_tr, y_tr = loadDataSeq_num(0,[j for j in nodein_list[i]], data_origin, data_in_list, data_out_list, args)
        # x_ts, y_ts, _ = loadData_swprop(2,[fpathlist[j] for j in nodein_list[i]], features, dataset_features, seq_len, step, winsize)

        x_tp = np.asarray(x_tr)
        r1, r2, r3 = x_tp.shape
        n_total += r1 * r2
        #print('r1 * r2: ', r1 * r2)
        tp_tr = np.asarray(x_tr)
        print(' ')
        print(f'id_: {counter}')
        print(f'x_tr.shape: {tp_tr.shape}')
        print(f'y_tr.shape: {np.asarray(y_tr).shape}')
        dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr[:, -args.predict_len:, :]))
        # dataset_ts = SeqDataset3(np.asarray(x_ts), np.asarray(y_ts))

        data_tr_dict[counter] = dataset_tr
        # data_ts_dict[counter] = dataset_ts
        counter+=1
    
    x_tr, y_tr = loadDataSeq_num(0,[j for j in [i for item in nodein_list for i in item]], data_origin, data_in_list, data_out_list, args)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr[:, -args.predict_len:, :])) 

    x_vl, y_vl = loadDataSeq_num(1,[j for j in [i for item in nodein_list for i in item]], data_origin, data_in_list, data_out_list, args)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl[:, -args.predict_len:, :])) 
    
    counter=0
    for i in range(locframe_num * locnode_num):
        rank=[j for item in nodein_list for j in item][i]
        x_ts_in, y_ts_in = loadDataSeq_num(2,[rank], data_origin, data_in_list, data_out_list, args)

        tp_in = np.asarray(x_ts_in)
        print(f'shape of x_ts_in: {tp_in.shape}')

        data_ts_in_dict[counter] = SeqDataset3(np.asarray(x_ts_in), np.asarray(y_ts_in[:, -args.predict_len:, :]))
        counter+=1

    counter=0
    for i in testout_list:
        x_ts_out, y_ts_out = loadDataSeq_pv([i], data_origin, data_in_list, data_out_list, args)

        tp_out = np.asarray(x_ts_out)
        print(f'shape of x_ts_out: {tp_out.shape}')

        data_ts_out_dict[counter] = SeqDataset3(np.asarray(x_ts_out), np.asarray(y_ts_out[:, -args.predict_len:, :]))
        counter+=1

    return data_tr_dict,data_tr,data_vl,data_ts_in_dict,data_ts_out_dict,n_total

def predict(data, args, model_predict=None): # predict 24h each time，and join the predictions to get the final result
    result = []
    input_ = torch.tensor(data)
    input_ = Variable(input_.view(1, len(data), args.input_dim).float()).cuda()
    i = 0
    while i <= len(data) - args.train_len:
        # pred = model_predict(input_[:, i:i+config.train_len, :].transpose(1,2))
        # result.append(pred[:, 0, :])
        pred = model_predict(input_[:, i:i+args.train_len, :])
        pred = pred.reshape(-1,24,1)
        pred = pred[:,-args.predict_len:, :].reshape(-1,1)
        result.append(pred.reshape(-1,12))
        i += 12
    #save_var(result, 'result')
    return torch.cat(result, dim=1)

def predictcurve(model,args,k,data,num): # evaluate the performance of the model in test set
    criterion = torch.nn.MSELoss()
    criterion2 = torch.nn.L1Loss()


    input_ = data.data_input_list[k] # ->array(data_len * in_dim)
    target = data.data_output_list[k]# ->array(data_len * 1)
    pred = predict(input_, args, model_predict=model)
    # add the average trend to get the real ratio
    train_len = args.train_len - 12
    # print(pred.shape)
    pred = pred.cpu().detach().numpy()[0]
    target = target[train_len:]
    mseloss = criterion(torch.tensor(pred[-num*12:]).float(), torch.tensor(target[-num*12:, 0].reshape(-1)).float())
    maeloss = criterion2(torch.tensor(pred[-num*12:]).float(), torch.tensor(target[-num*12:, 0].reshape(-1)).float())
    cvloss = mseloss**0.5/torch.mean(torch.tensor(target[-num*12:, 0].reshape(-1)).float())
    # print("ID{}\t test loss: {}".format(k, loss))
    min = data.load_min[k][0]
    max = data.load_max[k][0]
    num2 = len(pred)/12
    arr_mean=np.tile(data.load_mean,int(num2))
    arr_mean=0
    pred = np.array(pred) + arr_mean
    pred_real = Regeneralize(pred, min, max)
    target = target.reshape(-1) + arr_mean
    target_real = Regeneralize(target, min, max)

    loss_real_innormal = criterion(Variable(torch.tensor(pred_real).float()),
                            Variable(torch.tensor(target_real).float()))

    return np.array(mseloss), np.array(maeloss), np.array(cvloss), pred_real, target_real


def evaluate(args, model, nodein_list, testout_list, data):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    
    str_lr = '_'.join(['lr', str(args.lr)])
    str_seed = '_'.join(['seed', str(args.seed)])
    args_dict =vars(args)
    arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models,args.locframe_num, args.fold_id)
    if not os.path.exists(arg_path):
        os.makedirs(arg_path)    
    with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
        for key, value in args_dict.items():
            f.write('{}:{}'.format(key, value))
            f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = data.data_list
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]
    test_in_name_list=[]
    test_in_mseloss_list=[]
    test_in_maeloss_list=[]
    test_in_cvloss_list=[]
    test_in_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    for d in range(args.no_models*args.locframe_num):
        rank = test_in_id[d]
        filename=filelist[rank]
        print('in file name:'+str(filename))
        name='A'+str(filename)
        test_in_name_list.append(name)

        ts_mseloss, ts_maeloss, ts_cvloss, data_list, output_list = predictcurve(model, args, rank, data, 60)
        test_in_mseloss_list.append(ts_mseloss)
        test_in_maeloss_list.append(ts_maeloss)

        test_in_len_list.append(len(data_list[-60*12:]))
        
        df = dict()
        df['Target'] = output_list[-60*12:]
        df['Predict'] = data_list[-60*12:]
        df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
        df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

        figplt(data_list[-60*12:],output_list[-60*12:],log_path,name)

    mseloss_locnode=[]
    maeloss_locnode=[]
    if args.locframe_num != 1:
        test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
        test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
        test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
        for i in range(args.no_models):
            node_datanum = sum(test_in_len_list2[i])
            node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
            node_ts_mseloss = node_unbl_mseloss/node_datanum
            mseloss_locnode.append(node_ts_mseloss)
            node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
            node_ts_maeloss = node_unbl_maeloss/node_datanum
            maeloss_locnode.append(node_ts_maeloss)
    
    test_out_name_list=[]
    test_out_mseloss_list=[]
    test_out_maeloss_list=[]
    test_out_cvloss_list=[]
    test_out_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testout'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)
        
    for j in range(args.testout_num):
        rank = testout_list[j]
        filename=filelist[rank]
        print('out file name:'+str(filename))
        name='A'+str(filename)
        ##路径，计算loss，绘图
        test_out_name_list.append(name)

        ts_mseloss, ts_maeloss, ts_cvloss, data_list, output_list = predictcurve(model, args, rank, data, 0)
        test_out_mseloss_list.append(ts_mseloss)
        test_out_maeloss_list.append(ts_maeloss)

        test_out_len_list.append(len(data_list))

        df = dict()
        df['Target'] = output_list
        df['Predict'] = data_list
        df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
        df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

        figplt(data_list,output_list,log_path,name)

    #记录,做表格
    log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_in_mseloss_list[i]
        log_list[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_out_mseloss_list[j]
        log_list[2][id_]=0
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list[3][k] = mseloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df = pd.DataFrame(data = log_list)
    df=df.T
    df.rename(columns = columns,inplace=True)
    df.to_csv(os.path.join(arg_path,'mse.csv'))
    
    #记录,做表格
    log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_in_maeloss_list[i]
        log_list2[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_out_maeloss_list[j]
        log_list2[2][id_]=0
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list2[3][k] = maeloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df2 = pd.DataFrame(data = log_list2)
    df2=df2.T
    df2.rename(columns = columns,inplace=True)
    df2.to_csv(os.path.join(arg_path,'mae.csv')) 

def evaluated(args, model, nodein_list, testout_list, data):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    
    str_lr = '_'.join(['lr', str(args.lr)])
    str_seed = '_'.join(['seed', str(args.seed)])
    str_slseed = '_'.join(['seed', str(args.selseed)])

    args_dict =vars(args)
    arg_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_slseed, str_seed, args.no_models,args.locframe_num, args.fold_id)
    if not os.path.exists(arg_path):
        os.makedirs(arg_path)    
    with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
        for key, value in args_dict.items():
            f.write('{}:{}'.format(key, value))
            f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = data.data_list
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]
    test_in_name_list=[]
    test_in_mseloss_list=[]
    test_in_maeloss_list=[]
    test_in_cvloss_list=[]
    test_in_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_slseed, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    for d in range(args.no_models*args.locframe_num):
        rank = test_in_id[d]
        filename=filelist[rank]
        print('in file name:'+str(filename))
        name='A'+str(filename)
        test_in_name_list.append(name)

        ts_mseloss, ts_maeloss, ts_cvloss, data_list, output_list = predictcurve(model, args, rank, data, 60)
        test_in_mseloss_list.append(ts_mseloss)
        test_in_maeloss_list.append(ts_maeloss)

        test_in_len_list.append(len(data_list[-60*12:]))
        
        df = dict()
        df['Target'] = output_list[-60*12:]
        df['Predict'] = data_list[-60*12:]
        df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
        df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

        figplt(data_list[-60*12:],output_list[-60*12:],log_path,name)

    mseloss_locnode=[]
    maeloss_locnode=[]
    if args.locframe_num != 1:
        test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
        test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
        test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
        for i in range(args.no_models):
            node_datanum = sum(test_in_len_list2[i])
            node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
            node_ts_mseloss = node_unbl_mseloss/node_datanum
            mseloss_locnode.append(node_ts_mseloss)
            node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
            node_ts_maeloss = node_unbl_maeloss/node_datanum
            maeloss_locnode.append(node_ts_maeloss)
    
    test_out_name_list=[]
    test_out_mseloss_list=[]
    test_out_maeloss_list=[]
    test_out_cvloss_list=[]
    test_out_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}/testout'.format(args.global_epochs, str_lr, str_slseed, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)
        
    for j in range(args.testout_num):
        rank = testout_list[j]
        filename=filelist[rank]
        print('out file name:'+str(filename))
        name='A'+str(filename)
        ##路径，计算loss，绘图
        test_out_name_list.append(name)

        ts_mseloss, ts_maeloss, ts_cvloss, data_list, output_list = predictcurve(model, args, rank, data, 0)
        test_out_mseloss_list.append(ts_mseloss)
        test_out_maeloss_list.append(ts_maeloss)

        test_out_len_list.append(len(data_list))

        df = dict()
        df['Target'] = output_list
        df['Predict'] = data_list
        df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
        df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

        figplt(data_list,output_list,log_path,name)

    #记录,做表格
    log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_in_mseloss_list[i]
        log_list[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_out_mseloss_list[j]
        log_list[2][id_]=0
    for i in range(18):
        log_list[0][i]=filelist[i]
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list[3][k] = mseloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df = pd.DataFrame(data = log_list)
    df=df.T
    df.rename(columns = columns,inplace=True)
    df.to_csv(os.path.join(arg_path,'mse.csv'))
    
    #记录,做表格
    log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_in_maeloss_list[i]
        log_list2[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_out_maeloss_list[j]
        log_list2[2][id_]=0
    for i in range(18):
        log_list2[0][i]=filelist[i]
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list2[3][k] = maeloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df2 = pd.DataFrame(data = log_list2)
    df2=df2.T
    df2.rename(columns = columns,inplace=True)
    df2.to_csv(os.path.join(arg_path,'mae.csv')) 

def loc_evaluate(args, nodein_list, testout_list, data, device):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    # str_lr = '_'.join(['lr', str(args.lr)])
    # str_seed = '_'.join(['seed', str(args.seed)])
    # args_dict =vars(args)
    # arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models,args.locframe_num, args.fold_id)
    # if not os.path.exists(arg_path):
    #     os.makedirs(arg_path)    
    # with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
    #     for key, value in args_dict.items():
    #         f.write('{}:{}'.format(key, value))
    #         f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = data.data_list
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]
    ##路径，计算loss，绘图
    # log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    # if not os.path.exists(log_path):
    #     os.makedirs(log_path)


    for k in range(args.no_models):#对于每个local device的model作eval
        str_lr = '_'.join(['lr', str(args.lr)])
        str_seed = '_'.join(['seed', str(args.seed)])

        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        print('**********************************************')

        if args.locframe_num==1:
            rank = test_in_id[k]
            filename=filelist[rank]
            print('model filename')
            print(filename)
            print('')
            Name=filename
            model_path = modelpath + '/{}/{}clients/{}frames/{}/model'.format(str_seed,args.no_models,args.locframe_num,Name)
        else:
            Name=k
            print('model filename')
            print(Name)
            print('')
            model_path = modelpath + '/{}/{}clients/{}frames/fold{}/{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
         
        args_dict =vars(args)
        arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models, args.locframe_num, args.fold_id,Name)
        if not os.path.exists(arg_path):
            os.makedirs(arg_path)    
        with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
            for key, value in args_dict.items():
                f.write('{}:{}'.format(key, value))
                f.write('\n')        
        

        test_in_name_list=[]
        test_in_mseloss_list=[]
        test_in_maeloss_list=[]
        test_in_cvloss_list=[]
        test_in_len_list=[]
        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)

        model = get_transformer(args).to(device)
        
        model_list=os.listdir(model_path)
        model_list.sort()
        modelname=model_list[-1]
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        for d in range(args.no_models*args.locframe_num):
            
            rank = test_in_id[d]
            filename=filelist[rank]
            print(filename)
            name=filename
            test_in_name_list.append(name)

            ts_mseloss, ts_maeloss, ts_cvloss, data_list, output_list = predictcurve(model, args, rank, data, 60)
            test_in_mseloss_list.append(ts_mseloss)
            test_in_maeloss_list.append(ts_maeloss)
            test_in_len_list.append(len(data_list[-60*12:]))
            
            df = dict()
            df['Target'] = output_list
            df['Predict'] = data_list
            df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
            df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

            figplt(data_list[-60*12:],output_list[-60*12:],log_path,name)

        mseloss_locnode=[]
        maeloss_locnode=[]
        if args.locframe_num != 1:
            test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
            test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
            test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
            for i in range(args.no_models):
                node_datanum = sum(test_in_len_list2[i])
                node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
                node_ts_mseloss = node_unbl_mseloss/node_datanum
                mseloss_locnode.append(node_ts_mseloss)
                node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
                node_ts_maeloss = node_unbl_maeloss/node_datanum
                maeloss_locnode.append(node_ts_maeloss)
        
        test_out_name_list=[]
        test_out_mseloss_list=[]
        test_out_maeloss_list=[]
        test_out_cvloss_list=[]
        test_out_len_list=[]

        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testout'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)
            
        for j in range(args.testout_num):
            rank = testout_list[j]
            filename=filelist[rank]
            print(filename)
            name=filename
            ##路径，计算loss，绘图
            test_out_name_list.append(name)

            ts_mseloss, ts_maeloss, ts_cvloss, data_list, output_list = predictcurve(model, args, rank, data, 0)
            test_out_mseloss_list.append(ts_mseloss)
            test_out_maeloss_list.append(ts_maeloss)
            test_out_len_list.append(len(data_list))

            df = dict()
            df['Target'] = output_list
            df['Predict'] = data_list
            df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
            df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

            figplt(data_list,output_list,log_path,name)

        #记录,做表格
        log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_in_mseloss_list[i]
            log_list[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_out_mseloss_list[j]
            log_list[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list[3][k] = mseloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df = pd.DataFrame(data = log_list)
        df=df.T
        df.rename(columns = columns,inplace=True)
        df.to_csv(os.path.join(arg_path,'mse.csv'))
        
        #记录,做表格
        log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_in_maeloss_list[i]
            log_list2[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_out_maeloss_list[j]
            log_list2[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list2[3][k] = maeloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df2 = pd.DataFrame(data = log_list2)
        df2=df2.T
        df2.rename(columns = columns,inplace=True)
        df2.to_csv(os.path.join(arg_path,'mae.csv')) 

def loc_entry_evaluate(args, nodein_list, testout_list, data, device):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    # str_lr = '_'.join(['lr', str(args.lr)])
    # str_seed = '_'.join(['seed', str(args.seed)])
    # args_dict =vars(args)
    # arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models,args.locframe_num, args.fold_id)
    # if not os.path.exists(arg_path):
    #     os.makedirs(arg_path)    
    # with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
    #     for key, value in args_dict.items():
    #         f.write('{}:{}'.format(key, value))
    #         f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = data.data_list
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]
    ##路径，计算loss，绘图
    # log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    # if not os.path.exists(log_path):
    #     os.makedirs(log_path)


    for k in range(args.no_models):#对于每个local device的model作eval
        str_lr = '_'.join(['lr', str(args.lr)])
        str_seed = '_'.join(['seed', str(args.seed)])

        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        print('**********************************************')

        if args.locframe_num==1:
            rank = test_in_id[k]
            filename=filelist[rank]
            print('model filename')
            print(filename)
            print('')
            Name=filename
            model_path = modelpath + '/{}/{}clients/{}frames/{}/model'.format(str_seed,args.no_models,args.locframe_num,Name)
        else:
            Name=k
            print('model filename')
            print(Name)
            print('')
            model_path = modelpath + '/{}/{}clients/{}frames/fold{}/{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
         
        args_dict =vars(args)
        arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models, args.locframe_num, args.fold_id,Name)
        if not os.path.exists(arg_path):
            os.makedirs(arg_path)    
        with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
            for key, value in args_dict.items():
                f.write('{}:{}'.format(key, value))
                f.write('\n')        
        

        test_in_name_list=[]
        test_in_mseloss_list=[]
        test_in_maeloss_list=[]
        test_in_cvloss_list=[]
        test_in_len_list=[]
        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)

        model = get_transformer(args).to(device)
        
        model_list=os.listdir(model_path)
        model_list.sort()
        modelname=model_list[-1]
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        for d in range(args.no_models*args.locframe_num):
            
            rank = test_in_id[d]
            filename=filelist[rank]
            print(filename)
            name=filename
            test_in_name_list.append(name)

            ts_mseloss, ts_maeloss, ts_cvloss, data_list, output_list = predictcurve(model, args, rank, data, 60)
            test_in_mseloss_list.append(ts_mseloss)
            test_in_maeloss_list.append(ts_maeloss)
            test_in_len_list.append(len(data_list[-60*12:]))
            
            df = dict()
            df['Target'] = output_list
            df['Predict'] = data_list
            df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
            df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

            figplt(data_list[-60*12:],output_list[-60*12:],log_path,name)

        mseloss_locnode=[]
        maeloss_locnode=[]
        if args.locframe_num != 1:
            test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
            test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
            test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
            for i in range(args.no_models):
                node_datanum = sum(test_in_len_list2[i])
                node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
                node_ts_mseloss = node_unbl_mseloss/node_datanum
                mseloss_locnode.append(node_ts_mseloss)
                node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
                node_ts_maeloss = node_unbl_maeloss/node_datanum
                maeloss_locnode.append(node_ts_maeloss)
        
        test_out_name_list=[]
        test_out_mseloss_list=[]
        test_out_maeloss_list=[]
        test_out_cvloss_list=[]
        test_out_len_list=[]

        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testout'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)
            
        for j in range(args.testout_num):
            rank = testout_list[j]
            filename=filelist[rank]
            print(filename)
            name=filename
            ##路径，计算loss，绘图
            test_out_name_list.append(name)

            ts_mseloss, ts_maeloss, ts_cvloss, data_list, output_list = predictcurve(model, args, rank, data, 0)
            test_out_mseloss_list.append(ts_mseloss)
            test_out_maeloss_list.append(ts_maeloss)
            test_out_len_list.append(len(data_list))

            df = dict()
            df['Target'] = output_list
            df['Predict'] = data_list
            df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
            df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

            figplt(data_list,output_list,log_path,name)

        #记录,做表格
        log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_in_mseloss_list[i]
            log_list[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_out_mseloss_list[j]
            log_list[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list[3][k] = mseloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df = pd.DataFrame(data = log_list)
        df=df.T
        df.rename(columns = columns,inplace=True)
        df.to_csv(os.path.join(arg_path,'mse.csv'))
        
        #记录,做表格
        log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_in_maeloss_list[i]
            log_list2[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_out_maeloss_list[j]
            log_list2[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list2[3][k] = maeloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df2 = pd.DataFrame(data = log_list2)
        df2=df2.T
        df2.rename(columns = columns,inplace=True)
        df2.to_csv(os.path.join(arg_path,'mae.csv')) 

def figplt(pred_real,target_real,logpath,name):
    plt.figure(figsize = (120, 6))
    plt.plot(np.arange(len(pred_real)),pred_real,linewidth=1.5,label='predict')
    plt.plot(np.arange(len(pred_real)),target_real.reshape(-1),linewidth=1.5,label='target')
    plt.xlim(0,len(pred_real))
    plt.legend()
    plt.savefig(logpath+'/'+str(name)+ '_.png', dpi=100, bbox_inches='tight')
    plt.close()    

def Regeneralize(result, min, max):
    result_real_scale = (result * (max-min)) + min
    return result_real_scale

if __name__ == '__main__':
    pass