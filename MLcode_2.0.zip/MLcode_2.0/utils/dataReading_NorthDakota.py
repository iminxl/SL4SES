import os 
import pandas as pd 
import numpy as np 
import random 
import torch
from training.gru_x_NorthDakota import predictCurve2 
from models.gruNet import get_gru2
from utils.dataset import SeqDataset3, SeqDataset4 
from sklearn.preprocessing import StandardScaler, MinMaxScaler 
import matplotlib.pyplot as plt

def getRank(dataset_len,testout_num,testout_rank,locnode_num,locframe_num):
    
    fold_num=dataset_len/testout_num
    all_list=list(range(0,dataset_len))
    testout_list=[all_list[i:i+testout_num] for i in range(0,dataset_len,testout_num)][testout_rank]
    
    in_list=list(set(all_list)-set(testout_list))
    o_list=random.sample(in_list,testout_num)

    in_list=list(set(in_list)-set(o_list))
    nodein_list=[[i] for i in o_list]
    if locframe_num == 1:
        for i in range(testout_num,locnode_num):
            app_list=random.sample(in_list,1)
            in_list=list(set(in_list)-set(app_list))
            nodein_list.append(app_list)
        nodein_list=sorted(nodein_list,key=(lambda x:x[0]))
    else:
        for _ in range(1,locframe_num):
            app_list=random.sample(in_list,locnode_num)
            in_list=list(set(in_list)-set(app_list))
            for i in range(locnode_num):
                nodein_list[i].append(app_list[i])
        nodein_list=sorted(nodein_list,key=(lambda x:x[0]))
        for i in range(locnode_num):
            nodein_list[i]=sorted(nodein_list[i])
    return nodein_list,testout_list

def combineData(filePathList):
    data = pd.DataFrame()
    for filepath in filePathList:
        df = pd.read_csv(filepath)
        data = pd.concat([data, df], ignore_index = True)
    return data

def combineDataprop(num,filePathList):
    proplist=[0,.7,.9,1]
    data = pd.DataFrame()
    for filepath in filePathList:
        df = pd.read_csv(filepath)
        df=df[int(np.floor(proplist[num]*len(df))):int(np.floor(proplist[num+1]*len(df)))]
        data = pd.concat([data, df], ignore_index = True)
    return data

def getDataset(dataDir, features, seq_len, step, scaler, rank):
    # datadir is '../data'

    dir_tr = os.path.join(dataDir, 'training')
    dir_vl = os.path.join(dataDir, 'validation')
    dir_ts = os.path.join(dataDir, 'testing')

    filePathList_tr = []
    filePathList_vl = []
    filePathList_ts = []
    
    data_str = '_'.join(['data', str(rank)])

    fdir_tr = os.path.join(dir_tr, data_str)
    flist_tr = [ff for ff in os.listdir(fdir_tr) if ff.endswith('.csv')]
    filePath_tr = [os.path.join(fdir_tr, ff) for ff in flist_tr]
    filePathList_tr += filePath_tr

    flist_vl = [ff for ff in os.listdir(dir_vl) if ff.endswith('.csv')]
    filePathList_vl = [os.path.join(dir_vl, ff) for ff in flist_vl]

    flist_ts = [ff for ff in os.listdir(dir_ts) if ff.endswith('.csv')]
    filePathList_ts = [os.path.join(dir_ts, ff) for ff in flist_ts]

    #print(filePathList_tr)


    data_tr = combineData(filePathList_tr)

    #print('type of data_tr: ', type(data_tr))
    #print('size of data_tr: ', data_tr.shape)

    data_tr_s= data_tr[features].values 

    scaler.fit(data_tr_s)

    x_tr, y_tr = loadDataSeq(filePathList_tr, features, seq_len, step, scaler)
    x_vl, y_vl = loadDataSeq(filePathList_vl, features, seq_len, step, scaler)
    x_ts, y_ts = loadDataSeq(filePathList_ts, features, seq_len, step, scaler)


    x_tr_t = np.asarray(x_tr)
    x_vl_t = np.asarray(x_vl)
    x_ts_t = np.asarray(x_ts)

    #print('shape of x_tr: ', x_tr_t.shape)
    #print('shape of x_vl: ', x_vl_t.shape)
    #print('shape of x_ts: ', x_ts_t.shape)

    dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr))
    dataset_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl))
    dataset_ts = SeqDataset3(np.asarray(x_ts), np.asarray(y_ts))

    return dataset_tr, dataset_vl, dataset_ts

def loadDataSeq(filePathList, features, seq_len, step, scaler):
    xx_list = []
    yy_list = []

    for filePath in filePathList:
        df = pd.read_csv(filePath)
        df_s = df[features]

        data = df_s.values
        data_scaled = scaler.transform(data)

        x_list, y_list = genSeq(data_scaled, seq_len, step)

        xx_list += x_list
        yy_list += y_list 

    return xx_list, yy_list 

def genSeq(data, seq_len, step):
    x_list = []
    y_list = []
    nrow, ncol = data.shape
    for i in range(0, nrow, step):
        i_end = i  + seq_len
        if(i_end > nrow):
            break

        data_s = data[i: i_end]
        #skip if any of the element is nan
        if(np.isnan(data_s).any()):
            continue

        i_s = 3 #index of DTS

        x = data_s[:, 0:3]
        y = data_s[:, 3]

        x_list.append(x)
        y_list.append(y)

    return x_list, y_list

def getDataset_mulstdScaler_fl(dataDir, features, seq_len, step):
    """
    scalername is a string type
    """
    scaler_list = []
    fpathlist_tr = []

    for id_ in range(3):

        data_str = '_'.join(['data', str(id_)])
        tr_dir = os.path.join(dataDir, 'training')
        fdir = os.path.join(tr_dir, data_str)
        fpathlist = [os.path.join(fdir, ff) for ff in os.listdir(fdir) if ff.endswith('.csv')]
        if(len(fpathlist) == 0):
            continue

        fpathlist_tr += fpathlist

        data = combineData(fpathlist)
        data_s = data[features].values

        scaler = StandardScaler()

        scaler.fit(data_s)
        scaler_list.append(scaler)

    std_denominator = np.array([0.0, 0.0, 0.0, 0.0])
    std_numerator =  np.array([0.0, 0.0, 0.0, 0.0])
    mean_denominator =  np.array([0.0, 0.0, 0.0, 0.0])
    mean_numerator =  np.array([0.0, 0.0, 0.0, 0.0])

    for e in scaler_list:
        mu = e.mean_
        std = e.scale_
        var = e.var_
        nn = e.n_samples_seen_

        mean_numerator += mu * nn
        mean_denominator += nn

        nn_1 = nn - np.array([1.0, 1.0, 1.0, 1.0])
        std_denominator += nn_1

        std_numerator += nn_1 * var

    std_overall = np.sqrt(std_numerator*1.0 /std_denominator)
    mu_overall = mean_numerator*1.0 / mean_denominator

    data_tr_dict = {}

    n_total = 0

    for id_ in range(3):
        data_str = '_'.join(['data', str(id_)])

        tr_dir = os.path.join(dataDir, 'training')
        fdir = os.path.join(tr_dir, data_str)
        fpathlist = [os.path.join(fdir, ff) for ff in os.listdir(fdir)  if ff.endswith('.csv')]

        #x_tr, y_tr = loadDataSeq(fpathlist, features, seq_len, step, scaler)

        x_tr, y_tr = loadDataSeq2(fpathlist, features, seq_len, step, mu_overall, std_overall)
        x_tp = np.asarray(x_tr)
        r1, r2, r3 = x_tp.shape
        n_total += r1 * r2
        #print('r1 * r2: ', r1 * r2)
        tp_tr = np.asarray(x_tr)
        print(' ')
        print(f'id_: {id_}')
        print(f'tp_tr.shape: {tp_tr.shape}')
        dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr))
        
        data_tr_dict[id_] = dataset_tr

    #validation
    dir_vl = os.path.join(dataDir, 'validation')
    fpathlist_vl = [os.path.join(dir_vl, ff) for ff in os.listdir(dir_vl) if ff.endswith('.csv')]
    x_vl, y_vl = loadDataSeq2(fpathlist_vl, features, seq_len, step, mu_overall, std_overall)

    dir_ts = os.path.join(dataDir, 'testing')
    fpathlist_ts = [os.path.join(dir_ts, ff) for ff in os.listdir(dir_ts) if ff.endswith('.csv')]
    x_ts, y_ts = loadDataSeq2(fpathlist_ts, features, seq_len, step, mu_overall, std_overall)


    tp_vl = np.asarray(x_vl)
    print(f'shape of x_vl: {tp_vl.shape}')
    tp_ts = np.asarray(x_ts)
    print(f'shape of x_ts: {tp_ts.shape}')

    dataset_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl))
    dataset_ts = SeqDataset3(np.asarray(x_ts), np.asarray(y_ts))

    return data_tr_dict, dataset_vl, dataset_ts, mu_overall, std_overall, n_total

def getDataset_loc(dataDir,rank,features, seq_len, step):

    filelist=os.listdir(dataDir)
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    fpathlist.sort()
    print('filelist:')
    print(fpathlist)
    print(fpathlist[rank])

    data=combineDataprop(0,[fpathlist[rank]])
    data_s=data[features].values
    scaler = StandardScaler()

    scaler.fit(data_s)

    mu = scaler.mean_
    std = scaler.scale_


    x_tr, y_tr = loadDataSeq2_prop(0,[fpathlist[rank]], features, seq_len, step, mu, std)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr)) 

    x_vl, y_vl = loadDataSeq2_prop(1,[fpathlist[rank]], features, seq_len, step, mu, std)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl)) 

    name=str(filelist[rank]).split(".")[0]

    return data_tr,data_vl,mu,std,name

def getDataset_loc_entry(dataDir,rank,features, seq_len, step, prop):

    filelist=os.listdir(dataDir)
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    fpathlist.sort()
    print('filelist:')
    print(fpathlist)
    print(fpathlist[rank])

    data=combineDataprop(0,[fpathlist[rank]])
    data_s=data[features].values
    scaler = StandardScaler()

    scaler.fit(data_s)

    mu = scaler.mean_
    std = scaler.scale_


    x_tr, y_tr = loadDataSeq2_prop_entry(0,[fpathlist[rank]], features, seq_len, step, mu, std, prop)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr)) 

    x_vl, y_vl = loadDataSeq2_prop(1,[fpathlist[rank]], features, seq_len, step, mu, std)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl)) 

    name=str(filelist[rank]).split(".")[0]

    return data_tr,data_vl,mu,std,name

def getDataset_locmulti(dataDir,nodein_list,rank,features, seq_len, step):

    filelist=os.listdir(dataDir)
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    fpathlist.sort()

    uselist=nodein_list[rank]
    print('filelist:')
    print(fpathlist)
    print('uselist:')
    print(uselist)
    data=combineDataprop(0,[fpathlist[j] for j in uselist])
    data_s=data[features].values
    scaler = StandardScaler()

    scaler.fit(data_s)

    mu = scaler.mean_
    std = scaler.scale_

    x_tr, y_tr = loadDataSeq2_prop(0,[fpathlist[j] for j in uselist], features, seq_len, step, mu, std)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr)) 

    x_vl, y_vl = loadDataSeq2_prop(1,[fpathlist[j] for j in uselist], features, seq_len, step, mu, std)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl)) 

    name=rank

    return data_tr,data_vl,mu,std,name

def getDataset_mulstdScaler_sl(dataDir,nodein_list,testout_list,locnode_num,locframe_num,features, seq_len, step):
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    fpathlist.sort()

    ##compute std mean
    scaler_list = []
    for i in range(locnode_num):
        data=combineDataprop(0,[fpathlist[j] for j in nodein_list[i]])
        data_s=data[features].values
        scaler = StandardScaler()

        scaler.fit(data_s)
        scaler_list.append(scaler)

    std_denominator = np.array([0.0]*len(features))
    std_numerator =  np.array([0.0]*len(features))
    mean_denominator =  np.array([0.0]*len(features))
    mean_numerator =  np.array([0.0]*len(features))

    for e in scaler_list:
        mu = e.mean_
        std = e.scale_
        var = e.var_
        nn = e.n_samples_seen_

        mean_numerator += mu * nn
        mean_denominator += nn

        nn_1 = nn - np.array([1.0]*len(features))
        std_denominator += nn_1

        std_numerator += nn_1 * var

    std_overall = np.sqrt(std_numerator*1.0 /std_denominator)
    mu_overall = mean_numerator*1.0 / mean_denominator


    data_tr_dict = {}
    data_ts_in_dict = {}
    data_ts_out_dict = {}
    
    n_total = 0
    counter=0
    for i in range(locnode_num):
        x_tr, y_tr = loadDataSeq2_prop(0,[fpathlist[j] for j in nodein_list[i]], features, seq_len, step, mu_overall, std_overall)

        x_tp = np.asarray(x_tr)
        r1, r2, r3 = x_tp.shape
        n_total += r1 * r2
        #print('r1 * r2: ', r1 * r2)
        tp_tr = np.asarray(x_tr)
        print(' ')
        print(f'id_: {counter}')
        print(f'x_tr.shape: {tp_tr.shape}')
        print(f'y_tr.shape: {np.asarray(y_tr).shape}')
        dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr))
        # dataset_ts = SeqDataset3(np.asarray(x_ts), np.asarray(y_ts))

        data_tr_dict[counter] = dataset_tr
        # data_ts_dict[counter] = dataset_ts
        counter+=1
    
    x_tr, y_tr= loadDataSeq2_prop(0,[fpathlist[j] for j in [i for item in nodein_list for i in item]], features, seq_len, step, mu_overall, std_overall)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr)) 

    x_vl, y_vl= loadDataSeq2_prop(1,[fpathlist[j] for j in [i for item in nodein_list for i in item]], features, seq_len, step, mu_overall, std_overall)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl)) 
    
    counter=0
    for i in range(locframe_num * locnode_num):
        rank=[j for item in nodein_list for j in item][i]
        x_ts_in, y_ts_in, depth_list = loadDataSeq3_prop(2,[fpathlist[rank]], features, seq_len, step, mu_overall, std_overall)

        tp_in = np.asarray(x_ts_in)
        print(f'shape of x_ts_in: {tp_in.shape}')

        data_ts_in_dict[counter] = SeqDataset4(np.asarray(x_ts_in), np.asarray(y_ts_in), np.asarray(depth_list))
        counter+=1

    counter=0
    for i in testout_list:
        x_ts_out, y_ts_out, depth_list = loadDataSeq3([fpathlist[i]], features, seq_len, step, mu_overall, std_overall)

        tp_out = np.asarray(x_ts_out)
        print(f'shape of x_ts_out: {tp_out.shape}')

        data_ts_out_dict[counter] = SeqDataset4(np.asarray(x_ts_out), np.asarray(y_ts_out), np.asarray(depth_list))
        counter+=1

    return data_tr_dict,data_tr,data_vl,data_ts_in_dict,data_ts_out_dict,mu_overall, std_overall,n_total

def getDataset_mulstdScaler_sl_entry(dataDir,nodein_list,testout_list,locnode_num,locframe_num,features, seq_len, step, prop):
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    fpathlist.sort()

    ##compute std mean
    scaler_list = []
    for i in range(locnode_num):
        data=combineDataprop(0,[fpathlist[j] for j in nodein_list[i]])
        data_s=data[features].values
        scaler = StandardScaler()

        scaler.fit(data_s)
        scaler_list.append(scaler)

    std_denominator = np.array([0.0]*len(features))
    std_numerator =  np.array([0.0]*len(features))
    mean_denominator =  np.array([0.0]*len(features))
    mean_numerator =  np.array([0.0]*len(features))

    for e in scaler_list:
        mu = e.mean_
        std = e.scale_
        var = e.var_
        nn = e.n_samples_seen_

        mean_numerator += mu * nn
        mean_denominator += nn

        nn_1 = nn - np.array([1.0]*len(features))
        std_denominator += nn_1

        std_numerator += nn_1 * var

    std_overall = np.sqrt(std_numerator*1.0 /std_denominator)
    mu_overall = mean_numerator*1.0 / mean_denominator


    data_tr_dict = {}
    data_ts_in_dict = {}
    data_ts_out_dict = {}
    
    n_total = 0
    counter=0
    for i in range(locnode_num):
        x_tr, y_tr = loadDataSeq2_prop_entry(0,[fpathlist[j] for j in nodein_list[i]], features, seq_len, step, mu_overall, std_overall, prop)

        x_tp = np.asarray(x_tr)
        r1, r2, r3 = x_tp.shape
        n_total += r1 * r2
        #print('r1 * r2: ', r1 * r2)
        tp_tr = np.asarray(x_tr)
        print(' ')
        print(f'id_: {counter}')
        print(f'x_tr.shape: {tp_tr.shape}')
        print(f'y_tr.shape: {np.asarray(y_tr).shape}')
        dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr))
        # dataset_ts = SeqDataset3(np.asarray(x_ts), np.asarray(y_ts))

        data_tr_dict[counter] = dataset_tr
        # data_ts_dict[counter] = dataset_ts
        counter+=1
    
    x_tr, y_tr= loadDataSeq2_prop_entry(0,[fpathlist[j] for j in [i for item in nodein_list for i in item]], features, seq_len, step, mu_overall, std_overall, prop)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr)) 

    x_vl, y_vl= loadDataSeq2_prop(1,[fpathlist[j] for j in [i for item in nodein_list for i in item]], features, seq_len, step, mu_overall, std_overall)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl)) 
    
    counter=0
    for i in range(locframe_num * locnode_num):
        rank=[j for item in nodein_list for j in item][i]
        x_ts_in, y_ts_in, depth_list = loadDataSeq3_prop(2,[fpathlist[rank]], features, seq_len, step, mu_overall, std_overall)

        tp_in = np.asarray(x_ts_in)
        print(f'shape of x_ts_in: {tp_in.shape}')

        data_ts_in_dict[counter] = SeqDataset4(np.asarray(x_ts_in), np.asarray(y_ts_in), np.asarray(depth_list))
        counter+=1

    counter=0
    for i in testout_list:
        x_ts_out, y_ts_out, depth_list = loadDataSeq3([fpathlist[i]], features, seq_len, step, mu_overall, std_overall)

        tp_out = np.asarray(x_ts_out)
        print(f'shape of x_ts_out: {tp_out.shape}')

        data_ts_out_dict[counter] = SeqDataset4(np.asarray(x_ts_out), np.asarray(y_ts_out), np.asarray(depth_list))
        counter+=1

    return data_tr_dict,data_tr,data_vl,data_ts_in_dict,data_ts_out_dict,mu_overall, std_overall,n_total

def loadDataSeq_sw(filePathList, features, seq_len, step, mu, std, winsize):
    """
    mu is the overall mean of all the groups
    std is the overall std of all the groups

    also, mu can be min, and std can be max if MinMaxScaler is used
    """
    xx_list = []
    yy_list = []

    for filePath in filePathList:
        df = pd.read_csv(filePath)
        #print(' ')
        #print(f'filePath: {filePath}')
        df_s = df[features]

        data = df_s.values
        x_list, y_list = genSeq2_sw(data, seq_len, step, mu, std, winsize)

        xx_list += x_list
        yy_list += y_list 

    return xx_list, yy_list 

def genSeq2_sw(data, seq_len, step, mu, std, winsize):
    x_list = []
    y_list = []
    nrow, ncol = data.shape
    for i in range(0, nrow, step):
        i_end = i  + seq_len
        if(i_end+1 > nrow):
            break

        data_s = data[i: i_end+winsize]
        #skip if any of the element is nan
        if(np.isnan(data_s).any()):
            continue

        i_s = ncol #index of DTS

        data_scaled = (data_s - mu)/std
        x = data_scaled[:-winsize, 0:ncol-1]
        y = data_scaled[-winsize:, ncol-1]

        x_list.append(x)
        y_list.append(y)

    return x_list, y_list

def loadDataSeq2(filePathList, features, seq_len, step, mu, std):
    """
    mu is the overall mean of all the groups
    std is the overall std of all the groups

    also, mu can be min, and std can be max if MinMaxScaler is used
    """
    xx_list = []
    yy_list = []

    for filePath in filePathList:
        df = pd.read_csv(filePath)
        #print(' ')
        #print(f'filePath: {filePath}')
        df_s = df[features]

        data = df_s.values
        x_list, y_list = genSeq2(data, seq_len, step, mu, std)

        xx_list += x_list
        yy_list += y_list 

    return xx_list, yy_list 

def loadDataSeq2_prop(num,filePathList, features, seq_len, step, mu, std):
    """
    mu is the overall mean of all the groups
    std is the overall std of all the groups

    also, mu can be min, and std can be max if MinMaxScaler is used
    """
    xx_list = []
    yy_list = []
    proplist=[0,.7,.9,1]
    for filePath in filePathList:
        df = pd.read_csv(filePath)
        #print(' ')
        #print(f'filePath: {filePath}')
        df_s = df[features]
        data = df_s.values
        if num==2:
            data=data[int(np.floor(proplist[num]*len(data))):-1,:]
        else:
            data=data[int(np.floor(proplist[num]*len(data))):int(np.floor(proplist[num+1]*len(data))),:]

        x_list, y_list = genSeq2(data, seq_len, step, mu, std)

        xx_list += x_list
        yy_list += y_list 

    return xx_list, yy_list 

def loadDataSeq2_prop_entry(num,filePathList, features, seq_len, step, mu, std, prop):
    """
    mu is the overall mean of all the groups
    std is the overall std of all the groups

    also, mu can be min, and std can be max if MinMaxScaler is used
    """
    xx_list = []
    yy_list = []
    proplist=[0,.7,.9,1]
    for filePath in filePathList:
        df = pd.read_csv(filePath)
        #print(' ')
        #print(f'filePath: {filePath}')
        df_s = df[features]
        data = df_s.values
        if num==2:
            data=data[int(np.floor(proplist[num]*len(data))):-1,:]
        elif num ==1:
            data=data[int(np.floor(proplist[num]*len(data))*prop):int(np.floor(proplist[num+1]*len(data))*prop),:]
        else:
            data=data[int(np.floor(proplist[num]*len(data))):int(np.floor(proplist[num+1]*len(data))),:]

        x_list, y_list = genSeq2(data, seq_len, step, mu, std)

        xx_list += x_list
        yy_list += y_list 

    return xx_list, yy_list 

def genSeq2(data, seq_len, step, mu, std):
    x_list = []
    y_list = []
    nrow, ncol = data.shape
    for i in range(0, nrow, step):
        i_end = i  + seq_len
        if(i_end > nrow):
            break

        data_s = data[i: i_end]
        #skip if any of the element is nan
        if(np.isnan(data_s).any()):
            continue

        i_s = 3 #index of DTS

        data_scaled = (data_s - mu)/std
        x = data_scaled[:, 0:3]
        y = data_scaled[:, 3]

        x_list.append(x)
        y_list.append(y)

    return x_list, y_list

def loadDataSeq3(filePathList, features, seq_len, step, mu, std):
    xx_list = []
    yy_list = []
    data_list = []
    features2 = ['TVD']+features

    for filePath in filePathList:
        df = pd.read_csv(filePath)
        df_s = df[features]

        data = df_s.values
        data2 = df[features2].values

        x_list, y_list, depthts = genSeq3(data, data2, seq_len, step, mu, std)

        xx_list += x_list
        yy_list += y_list
        data_list += depthts

    return xx_list, yy_list, data_list  

def loadDataSeq3_prop(num,filePathList, features, seq_len, step, mu, std):
    """
    mu is the overall mean of all the groups
    std is the overall std of all the groups

    also, mu can be min, and std can be max if MinMaxScaler is used
    """
    xx_list = []
    yy_list = []
    data_list = []
    proplist=[0,.7,.9,1]
    features2 = ['TVD']+features

    for filePath in filePathList:
        df = pd.read_csv(filePath)
        #print(' ')
        #print(f'filePath: {filePath}')
        df_s = df[features]
        data = df_s.values
        data2 = df[features2].values
        if num==2:
            data=data[int(np.floor(proplist[num]*len(data))):,:]
            data2=data2[int(np.floor(proplist[num]*len(data2))):,:]
        else:
            data=data[int(np.floor(proplist[num]*len(data))):int(np.floor(proplist[num+1]*len(data))),:]
            data2=data2[int(np.floor(proplist[num]*len(data2))):int(np.floor(proplist[num+1]*len(data))),:]
        x_list, y_list, depthts = genSeq3(data, data2, seq_len, step, mu, std)

        xx_list += x_list
        yy_list += y_list
        data_list += depthts 

    return xx_list, yy_list, data_list 

def genSeq3(data, data2, seq_len, step, mu, std):
    x_list = []
    y_list = []
    data_list = []

    nrow, ncol = data.shape
    for i in range(0, nrow, step):
        i_end = i  + seq_len
        if(i_end > nrow):
            # i_end = nrow
            break

        data_s = data[i: i_end]
        #skip if any of the element is nan
        if(np.isnan(data_s).any()):
            continue

        i_s = 3 #index of DTS

        data_scaled = (data_s - mu)/std
        x = data_scaled[:, 0:3]
        y = data_scaled[:, 3]

        depthdts = data2[i: i_end]

        x_list.append(x)
        y_list.append(y)
        data_list.append(depthdts)

    return x_list, y_list, data_list

def getDataset_mulstdScaler_predictCurve(dataDir, filePath, features, seq_len, step):

    """
    scalername is a string type
    """
    scaler_list = []

    fpathlist_tr = []

    for id_ in range(3):
        data_str = '_'.join(['data', str(id_)])
        tr_dir = os.path.join(dataDir, 'training')
        fdir = os.path.join(tr_dir, data_str)
        fpathlist = [os.path.join(fdir, ff) for ff in os.listdir(fdir) if ff.endswith('.csv')]

        if(len(fpathlist) == 0):
            continue

        fpathlist_tr += fpathlist

        data =combineData(fpathlist)
        data_s = data[features].values 

        scaler = StandardScaler()

        scaler.fit(data_s)
        scaler_list.append(scaler)

    std_denominator = np.array([0.0, 0.0, 0.0, 0.0])
    std_numerator = np.array([0.0, 0.0, 0.0, 0.0])
    mean_denominator = np.array([0.0, 0.0, 0.0, 0.0])
    mean_numerator = np.array([0.0, 0.0, 0.0, 0.0])

    for e in scaler_list:
        mu = e.mean_
        std = e.scale_
        var = e.var_
        nn = e.n_samples_seen_

        mean_numerator += mu * nn
        mean_denominator += nn

        nn_1 = nn -  np.array([1.0, 1.0, 1.0, 1.0])
        std_denominator += nn_1 

        std_numerator += nn_1 * var

    std_overall = np.sqrt(std_numerator * 1.0 / std_denominator)
    mu_overall = mean_numerator * 1.0 / mean_denominator 

    df = pd.read_csv(filePath)
    data_s = df[features].values 

    data_scaled = (data_s - mu_overall)/std_overall

    features2 = ['TVD'] + features

    data2 = df[features2].values 

    x_list = []
    y_list = []
    data_list = []

    nrow, ncol = data_scaled.shape 
    for i in range(0, nrow, step):
        i_end = i + seq_len

        if(i_end > nrow):
            break 

        data_s = data_scaled[i: i_end]
        if(np.isnan(data_s).any()):
            continue 
        
        x = data_s[:, 0:3]
        y = data_s[:, 3]

        depthdts = data2[i: i_end]

        x_list.append(x)
        y_list.append(y)
        data_list.append(depthdts)

    tp1 = np.asarray(x_list)
    tp2 = np.asarray(y_list)
    tp3 = np.asarray(data_list)

    #print(f'shape of x_list: {tp1.shape}')
    #print(f'shape of y_list: {tp2.shape}')
    #print(f'shape of data_list: {tp3.shape}')

    dataset_ts = SeqDataset4(np.asarray(x_list),  np.asarray(y_list), np.asarray(data_list))
    return dataset_ts, mu_overall, std_overall    


def getDataset_entire_predictCurve(dataDir, filePath,features, seq_len, step, scaler):
    dir_tr = os.path.join(dataDir, 'training')

    filePathList_tr = []

    for id_ in range(3):
        data_str = '_'.join(['data', str(id_)])

        fdir_tr = os.path.join(dir_tr, data_str)
        flist_tr = [ff for ff in os.listdir(fdir_tr) if ff.endswith('.csv')]
        filePath_tr = [os.path.join(fdir_tr, ff) for ff in flist_tr]
        filePathList_tr += filePath_tr
    
    data_tr = combineData(filePathList_tr)

    data_tr_s = data_tr[features].values
    
    features2 = ['TVD']+features

    scaler.fit(data_tr_s)

    df = pd.read_csv(filePath)
    df_s = df[features]
    data = df_s.values
    data_scaled = scaler.transform(data)

    data2 = df[features2].values

    x_list = []
    y_list = []
    data_list = []

    nrow, ncol = data_scaled.shape
    for i in range(0, nrow, step):
        i_end = i  + seq_len
        if(i_end > nrow):
            break

        data_s = data_scaled[i: i_end]
        #skip if any of the element is nan
        if(np.isnan(data_s).any()):
            continue

        x = data_s[:, 0:3]
        y = data_s[:, 3]

        depthdts = data2[i: i_end]

        x_list.append(x)
        y_list.append(y)
        data_list.append(depthdts)

    tp1 = np.asarray(x_list)
    tp2 = np.asarray(y_list)
    tp3 = np.asarray(data_list)
    #print(f'shape of x_list: {tp1.shape}')
    #print(f'shape of y_list: {tp2.shape}')
    #print(f'shape of data_list: {tp3.shape}')

    dataset_ts = SeqDataset4(np.asarray(x_list), np.asarray(y_list), np.asarray(data_list))

    return dataset_ts
 
def Regeneralize (result, mean, std): # regeneralize the result to real scale
    mean_matrix = mean
    std_matrix = std
    result_real_scale = (result * std_matrix) + mean_matrix
    return result_real_scale

def evaluated(args, features, nodein_list, testout_list, data_ts_in_dict, data_ts_out_dict, mu, std):
    #select device
    if torch.cuda.is_available():
        device = torch.device('cuda')
    else:
        device = torch.device('cpu')

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    str_lr = '_'.join(['lr', str(args.lr)])
    str_seed = '_'.join(['seed', str(args.seed)])
    str_slseed = '_'.join(['seed', str(args.selseed)])

    args_dict =vars(args)
    arg_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_slseed, str_seed, args.no_models,args.locframe_num, args.fold_id)
    if not os.path.exists(arg_path):
        os.makedirs(arg_path)    
    with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
        for key, value in args_dict.items():
            f.write('{}:{}'.format(key, value))
            f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    fpathlist = [os.path.join(args.dataPath,ff) for ff in filelist if ff.endswith('.csv')]
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]
    test_in_name_list=[]
    test_in_mseloss_list=[]
    test_in_maeloss_list=[]
    test_in_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_slseed, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    for d in range(args.no_models*args.locframe_num):
        rank = test_in_id[d]
        filename=filelist[rank]
        print(filename.split('.')[0])
        name=filename.split('.')[0]
        test_in_name_list.append(name)


        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        model_path = modelpath + '/{}/{}/{}clients/{}frames/fold_{}/model'.format(str_slseed, str_seed,args.no_models,args.locframe_num,args.fold_id)
        model = get_gru2(args).to(device)
        
        modelname ='_'.join(['model', str(args.final_epochs).rjust(3,'0'), '.ckpt'])
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        ts_loss_scaled, ts_loss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_in_dict[d], model, mu, std, device)

        data = data_list[0]
        pred = output_list[0]
        for i in range(1, len(data_list)):
            data = np.concatenate((data, data_list[i]), axis = 0)
            pred = np.concatenate((pred, output_list[i]), axis = 0)
        
        data_c = np.hstack([data, pred.reshape(-1, 1)])
        columns = ['TVD', 'GR', 'Rt', 'RHOB', 'DTS', 'DTS_p']
        pltfig(data_c,columns,log_path,name)

        test_in_mseloss_list.append(ts_loss_scaled)
        test_in_maeloss_list.append(ts_maeloss)
        test_in_len_list.append(len(data_list))

    mseloss_locnode=[]
    maeloss_locnode=[]
    if args.locframe_num != 1:
        test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
        test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
        test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
        for i in range(args.no_models):
            node_datanum = sum(test_in_len_list2[i])
            node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
            node_ts_mseloss = node_unbl_mseloss/node_datanum
            mseloss_locnode.append(node_ts_mseloss)
            node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
            node_ts_maeloss = node_unbl_maeloss/node_datanum
            maeloss_locnode.append(node_ts_maeloss)
    
    test_out_name_list=[]
    test_out_mseloss_list=[]
    test_out_maeloss_list=[]
    test_out_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}/testout'.format(args.global_epochs, str_lr, str_slseed, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)
        
    for j in range(args.testout_num):
        rank = testout_list[j]
        filename=filelist[rank]
        print(filename.split('.')[0])
        name=filename.split('.')[0]
        ##路径，计算loss，绘图
        test_out_name_list.append(name)


        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        model_path = modelpath + '/{}/{}/{}clients/{}frames/fold_{}/model'.format(str_slseed, str_seed,args.no_models,args.locframe_num,args.fold_id)
        model = get_gru2(args).to(device)
        
        modelname ='_'.join(['model', str(args.final_epochs).rjust(3,'0'), '.ckpt'])
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        ts_loss_scaled, ts_loss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_out_dict[j], model, mu, std, device)

        data = data_list[0]
        pred = output_list[0]
        for i in range(1, len(data_list)):
            data = np.concatenate((data, data_list[i]), axis = 0)
            pred = np.concatenate((pred, output_list[i]), axis = 0)
        
        data_c = np.hstack([data, pred.reshape(-1, 1)])
        columns = ['TVD', 'GR', 'Rt', 'RHOB', 'DTS', 'DTS_p']
        pltfig(data_c,columns,log_path,name)

        test_out_mseloss_list.append(ts_loss_scaled)
        test_out_maeloss_list.append(ts_maeloss)
        test_out_len_list.append(len(data_list))

    #记录,做表格
    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_in_mseloss_list[i]
        log_list[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_out_mseloss_list[j]
        log_list[2][id_]=0
    for i in range(36):
        log_list[0][i]=filelist[i]
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list[3][k] = mseloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df = pd.DataFrame(data = log_list)
    df=df.T
    df.rename(columns = columns,inplace=True)
    df.to_csv(os.path.join(arg_path,'mse.csv')) 
    #记录,做表格
    log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_in_maeloss_list[i]
        log_list2[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_out_maeloss_list[j]
        log_list2[2][id_]=0
    for i in range(36):
        log_list2[0][i]=filelist[i]    
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list2[3][k] = maeloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df2 = pd.DataFrame(data = log_list2)
    df2=df2.T
    df2.rename(columns = columns,inplace=True)
    df2.to_csv(os.path.join(arg_path,'mae.csv')) 

def evaluate(args, features, nodein_list, testout_list, data_ts_in_dict, data_ts_out_dict, mu, std):
    #select device
    if torch.cuda.is_available():
        device = torch.device('cuda')
    else:
        device = torch.device('cpu')

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    str_lr = '_'.join(['lr', str(args.lr)])
    str_seed = '_'.join(['seed', str(args.seed)])
    args_dict =vars(args)
    arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models,args.locframe_num, args.fold_id)
    if not os.path.exists(arg_path):
        os.makedirs(arg_path)    
    with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
        for key, value in args_dict.items():
            f.write('{}:{}'.format(key, value))
            f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    fpathlist = [os.path.join(args.dataPath,ff) for ff in filelist if ff.endswith('.csv')]
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]
    test_in_name_list=[]
    test_in_mseloss_list=[]
    test_in_maeloss_list=[]
    test_in_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    for d in range(args.no_models*args.locframe_num):
        rank = test_in_id[d]
        filename=filelist[rank]
        print(filename.split('.')[0])
        name=filename.split('.')[0]
        test_in_name_list.append(name)


        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        model_path = modelpath + '/{}/{}clients/{}frames/fold_{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id)
        model = get_gru2(args).to(device)
        
        modelname ='_'.join(['model', str(args.final_epochs).rjust(3,'0'), '.ckpt'])
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        ts_loss_scaled, ts_loss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_in_dict[d], model, mu, std, device)

        data = data_list[0]
        pred = output_list[0]
        for i in range(1, len(data_list)):
            data = np.concatenate((data, data_list[i]), axis = 0)
            pred = np.concatenate((pred, output_list[i]), axis = 0)
        
        data_c = np.hstack([data, pred.reshape(-1, 1)])
        columns = ['TVD', 'GR', 'Rt', 'RHOB', 'DTS', 'DTS_p']
        pltfig(data_c,columns,log_path,name)

        test_in_mseloss_list.append(ts_loss_scaled)
        test_in_maeloss_list.append(ts_maeloss)
        test_in_len_list.append(len(data_list))

    mseloss_locnode=[]
    maeloss_locnode=[]
    if args.locframe_num != 1:
        test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
        test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
        test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
        for i in range(args.no_models):
            node_datanum = sum(test_in_len_list2[i])
            node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
            node_ts_mseloss = node_unbl_mseloss/node_datanum
            mseloss_locnode.append(node_ts_mseloss)
            node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
            node_ts_maeloss = node_unbl_maeloss/node_datanum
            maeloss_locnode.append(node_ts_maeloss)
    
    test_out_name_list=[]
    test_out_mseloss_list=[]
    test_out_maeloss_list=[]
    test_out_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testout'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)
        
    for j in range(args.testout_num):
        rank = testout_list[j]
        filename=filelist[rank]
        print(filename.split('.')[0])
        name=filename.split('.')[0]
        ##路径，计算loss，绘图
        test_out_name_list.append(name)


        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        model_path = modelpath + '/{}/{}clients/{}frames/fold_{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id)
        model = get_gru2(args).to(device)
        
        modelname ='_'.join(['model', str(args.final_epochs).rjust(3,'0'), '.ckpt'])
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        ts_loss_scaled, ts_loss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_out_dict[j], model, mu, std, device)

        data = data_list[0]
        pred = output_list[0]
        for i in range(1, len(data_list)):
            data = np.concatenate((data, data_list[i]), axis = 0)
            pred = np.concatenate((pred, output_list[i]), axis = 0)
        
        data_c = np.hstack([data, pred.reshape(-1, 1)])
        columns = ['TVD', 'GR', 'Rt', 'RHOB', 'DTS', 'DTS_p']
        pltfig(data_c,columns,log_path,name)

        test_out_mseloss_list.append(ts_loss_scaled)
        test_out_maeloss_list.append(ts_maeloss)
        test_out_len_list.append(len(data_list))

    #记录,做表格
    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_in_mseloss_list[i]
        log_list[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_out_mseloss_list[j]
        log_list[2][id_]=0
    for i in range(36):
        log_list[0][i]=filelist[i]
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list[3][k] = mseloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df = pd.DataFrame(data = log_list)
    df=df.T
    df.rename(columns = columns,inplace=True)
    df.to_csv(os.path.join(arg_path,'mse.csv')) 
    #记录,做表格
    log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_in_maeloss_list[i]
        log_list2[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_out_maeloss_list[j]
        log_list2[2][id_]=0
    for i in range(36):
        log_list2[0][i]=filelist[i]    
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list2[3][k] = maeloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df2 = pd.DataFrame(data = log_list2)
    df2=df2.T
    df2.rename(columns = columns,inplace=True)
    df2.to_csv(os.path.join(arg_path,'mae.csv')) 

def pltfig(data_c,columns,log_path,name):
        df = pd.DataFrame(data = data_c, columns = columns)
        fs=12
        fig, ax = plt.subplots(1, 5, figsize = (5, 6))
        
        d = df['TVD'].values
        gr = df['GR'].values
        rt = df['Rt'].values
        rhob = df['RHOB'].values
        dts = df['DTS'].values
        dtsp = df['DTS_p'].values
        pamlist = [gr, rt, rhob, dts, dtsp]
        colist = ['black','red','blue','green']

        for i in range(4):
            ax[i].plot(pamlist[i], d, linewidth = 1,linestyle = 'solid',color = colist[i], label = columns[1+i])
            ax[i].tick_params(labelsize = fs)
            ax[i].set_yticklabels([])
            ax[i].invert_yaxis()
            ax[i].invert_xaxis()

        ax[4].plot(dts, d, linewidth = 1, linestyle = 'solid',color = 'blue', label = 'DTS')
        ax[4].plot(dtsp, d, linewidth = 1, linestyle = 'dashed',color = 'red', label = 'DTS_p')
        ax[4].tick_params(labelsize = fs)
        ax[4].set_yticklabels([])
        ax[4].invert_yaxis()
        ax[4].invert_xaxis()

        for i in range(5):
            ax[i].set_ylim(d[0], d[-1])

        ax[0].set_ylabel('Depth (m)', fontsize = fs)
        ax[2].set_xlabel('DTS (us/ft)', fontsize = fs)

        # ax[4].legend(loc = 'upper right', fancybox = True, fontsize = fs)
        plt.savefig(log_path+'/'+ name + '.png', dpi=300, bbox_inches='tight')
        plt.close()

        df_sorted = df.sort_values(by = ['TVD'])
        df_sorted.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

def loc_evaluate(args, features, nodein_list, testout_list, data_ts_in_dict, data_ts_out_dict, mu, std):
    #select device
    if torch.cuda.is_available():
        device = torch.device('cuda')
    else:
        device = torch.device('cpu')

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    # str_lr = '_'.join(['lr', str(args.lr)])
    # str_seed = '_'.join(['seed', str(args.seed)])
    # args_dict =vars(args)
    # arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models,args.locframe_num, args.fold_id)
    # if not os.path.exists(arg_path):
    #     os.makedirs(arg_path)    
    # with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
    #     for key, value in args_dict.items():
    #         f.write('{}:{}'.format(key, value))
    #         f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    fpathlist = [os.path.join(args.dataPath,ff) for ff in filelist if ff.endswith('.csv')]
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]

    ##路径，计算loss，绘图
    # log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    # if not os.path.exists(log_path):
    #     os.makedirs(log_path)

    for k in range(args.no_models):
        str_lr = '_'.join(['lr', str(args.lr)])
        str_seed = '_'.join(['seed', str(args.seed)])
        print('**********************************************')

        modelpath = args.logPath + '/lr_{}'.format(args.lr)

        if args.locframe_num==1:
            rank = test_in_id[k]
            filename=filelist[rank]
            print('model filename')
            print(filename.split('.')[0])
            print('')
            Name=filename.split('.')[0]
            model_path = modelpath + '/{}/{}clients/{}frames/{}/model'.format(str_seed,args.no_models,args.locframe_num,Name)
        else:
            Name=k
            print('model filename')
            print(Name)
            print('')
            model_path = modelpath + '/{}/{}clients/{}frames/fold{}/{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id,Name)

        args_dict =vars(args)
        arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models, args.locframe_num, args.fold_id,Name)
        if not os.path.exists(arg_path):
            os.makedirs(arg_path)    
        with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
            for key, value in args_dict.items():
                f.write('{}:{}'.format(key, value))
                f.write('\n')        
        
        test_in_name_list=[]
        test_in_mseloss_list=[]
        test_in_maeloss_list=[]
        test_in_len_list=[]
        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)

        model = get_gru2(args).to(device)
        
        model_list=os.listdir(model_path)
        model_list.sort()
        modelname=model_list[-1]
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        for d in range(args.no_models*args.locframe_num):
            rank = test_in_id[d]
            filename=filelist[rank]
            print(filename.split('.')[0])
            name=filename.split('.')[0]
            test_in_name_list.append(name)

            ts_loss_scaled, ts_loss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_in_dict[d], model, mu, std, device)

            data = data_list[0]
            pred = output_list[0]
            for i in range(1, len(data_list)):
                data = np.concatenate((data, data_list[i]), axis = 0)
                pred = np.concatenate((pred, output_list[i]), axis = 0)
            
            data_c = np.hstack([data, pred.reshape(-1, 1)])
            columns = ['TVD', 'GR', 'Rt', 'RHOB', 'DTS', 'DTS_p']
            pltfig(data_c,columns,log_path,name)

            test_in_mseloss_list.append(ts_loss_scaled)
            test_in_maeloss_list.append(ts_maeloss)
            test_in_len_list.append(len(data_list))

        mseloss_locnode=[]
        maeloss_locnode=[]
        if args.locframe_num != 1:
            test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
            test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
            test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
            for i in range(args.no_models):
                node_datanum = sum(test_in_len_list2[i])
                node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
                node_ts_mseloss = node_unbl_mseloss/node_datanum
                mseloss_locnode.append(node_ts_mseloss)
                node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
                node_ts_maeloss = node_unbl_maeloss/node_datanum
                maeloss_locnode.append(node_ts_maeloss)
        
        test_out_name_list=[]
        test_out_mseloss_list=[]
        test_out_maeloss_list=[]
        test_out_len_list=[]

        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testout'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)
            
        for j in range(args.testout_num):
            rank = testout_list[j]
            filename=filelist[rank]
            print(filename.split('.')[0])
            name=filename.split('.')[0]
            ##路径，计算loss，绘图
            test_out_name_list.append(name)

            ts_loss_scaled, ts_loss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_out_dict[j], model, mu, std, device)

            data = data_list[0]
            pred = output_list[0]
            for i in range(1, len(data_list)):
                data = np.concatenate((data, data_list[i]), axis = 0)
                pred = np.concatenate((pred, output_list[i]), axis = 0)
            
            data_c = np.hstack([data, pred.reshape(-1, 1)])
            columns = ['TVD', 'GR', 'Rt', 'RHOB', 'DTS', 'DTS_p']
            pltfig(data_c,columns,log_path,name)

            test_out_mseloss_list.append(ts_loss_scaled)
            test_out_maeloss_list.append(ts_maeloss)
            test_out_len_list.append(len(data_list))

        #记录,做表格
        filelist = os.listdir(args.dataPath)
        filelist = [ff for ff in filelist if ff.endswith('.csv')]
        filelist.sort()
        log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_in_mseloss_list[i]
            log_list[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_out_mseloss_list[j]
            log_list[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list[3][k] = mseloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df = pd.DataFrame(data = log_list)
        df=df.T
        df.rename(columns = columns,inplace=True)
        df.to_csv(os.path.join(arg_path,'mse.csv')) 
        #记录,做表格
        log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_in_maeloss_list[i]
            log_list2[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_out_maeloss_list[j]
            log_list2[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list2[3][k] = maeloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df2 = pd.DataFrame(data = log_list2)
        df2=df2.T
        df2.rename(columns = columns,inplace=True)
        df2.to_csv(os.path.join(arg_path,'mae.csv')) 