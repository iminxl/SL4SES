import os 
import pandas as pd 
import numpy as np 
import random 
from utils.dataset import SeqDataset3
from models.transformer import get_transformer
import torch 
from torch.autograd import Variable
from scipy import signal
import matplotlib.pyplot as plt

class grid_data:
    def __init__(self,args,nodein_list):
        # hyper parameters
        use_forcast_weather = args.use_forcast_weather # whether to use the forecast data, 1 means True, 0 means False
        delta_weather = args.delta_weather
        use_filter = args.use_filter # filter the dimensionless trend

        use_ratio = args.use_ratio # dimensionless ratio
        use_mean_ratio = args.use_mean_ratio
        use_different_mean_ratio = args.use_different_mean_ratio # this indicates that each district only uses its own dimensionless trend
        use_CV_ratio = args.use_CV_ratio # this indicates that different groups have different dimensionless trends, and the districts within each group use the same dimensionless trend

        # load data
        data_origin = []
        data_list = ['CY','HD','FT','SJS','PG','YZ','CP',
                'MTG','FS','DX','MY','SY'] # Lack of PG, PG weather data has been missing too much，HR and YQ not used 
        for i in range (12):
            if use_ratio == True:
                name = '../data_grid/data/data_day_'+ data_list[i] +'.csv'
            else:
                name = '../data_grid/data/'+ data_list[i] +'.csv'
            #name = 'E:/Research CYT/grid/enlstm_code/ratio/data/data_day_'+ data_list[i] +'.csv'
            df = pd.read_csv(name)
            # print(df.shape)
            data_origin.append(df)
            # print(data_origin[i].shape)
            # exec (script)
            # exec (script2)
            #print(i)
        print('shape of df',np.shape(np.array(df)))
        print(len(data_origin))
        load_mean = np.zeros((12, 4))
        load_std = np.zeros((12, 4))
        load_normal = []
        # generate the mean_ratio_all
        if use_mean_ratio == True:
            # mean_ratio_all, mean_ratio_all_ave, mean_ratio_group = ave_ratio (data_origin, use_filter)
            mean_ratio_all = None
            for i in range (12):
                load = data_origin[i]
                load_raw_array = load.iloc[:, 1]  # 32616 ratio
                input_load = np.array(load_raw_array)
                data_num = np.shape(input_load)[0]
                week_num = int(data_num/168) # calculate the number of weeks
                # reshape loads to (num of hours in one week) * (num of weeks)
                delet_ID = np.arange(week_num*168, data_num)
                input_load_del = np.delete( input_load, delet_ID, 0)# generate integer week results
                input_load_week = input_load_del.reshape(week_num,168) # 168(num of hours in one week) * num of weeks
                # calculate the average ratio in one week 对14个区分别求周平均
                input_load_week_mean = np.mean(input_load_week, axis=0)
                print('original:',np.mean(input_load_week_mean))
                #print('original:',np.max(input_load_week_mean)-np.min(input_load_week_mean))
                if use_filter == True:#滤波
                    # low pass
                    b, a = signal.butter(8, 0.2, 'lowpass')
                    filter_input_load_week_mean = signal.filtfilt(b, a, input_load_week_mean)
                    # Zoom to the scale of the ratio before filtering. Because filtering will reduce the scale of the ratio.
                    filter_input_load_week_mean = (filter_input_load_week_mean-np.min(filter_input_load_week_mean)) / (np.max(filter_input_load_week_mean)-np.min(filter_input_load_week_mean))#标准化的滤波后周平均数据
                    input_load_week_mean = filter_input_load_week_mean * (np.max(input_load_week_mean)-np.min(input_load_week_mean)) + np.min(input_load_week_mean)#滤波后的周平均数据
                    print('filtered:',np.mean(input_load_week_mean))
                # generate the average ratio for the length of data_num
                mean_ratio = None
                for i in range (week_num+1):
                    if mean_ratio is None:
                        mean_ratio = input_load_week_mean
                    else:
                        mean_ratio = np.hstack((mean_ratio, input_load_week_mean))
                delet_ID = np.arange(data_num, np.shape(mean_ratio)[0])
                mean_ratio = np.delete( mean_ratio, delet_ID, 0).reshape(1,-1)
                # save the mean_ratio of all districts
                if mean_ratio_all is None: # mean_ratio_all is the mean_ratio of all the districts
                    mean_ratio_all = mean_ratio
                else:
                    mean_ratio_all = np.vstack((mean_ratio_all, mean_ratio))

            mean_ratio_all_ave = np.mean(mean_ratio_all, axis=0) # mean_ratio_all_ave is the average of mean_ratio_all over 14 districts
            print('the sum of filtered:',np.mean(np.sum(mean_ratio_all, axis=0)))

            uselist = [j for item in nodein_list for j in item]
            alllist = [y for y in range(12)]
            disuselist= list(set(alllist)-set(uselist))

            mean_ratio_group = np.sum(np.delete(mean_ratio_all,disuselist,0), axis=0)/len(uselist)
            print ('shape of mean_ratio_all is:', np.shape(mean_ratio_all))
            print ('shape of mean_ratio_all_ave is:', np.shape(mean_ratio_all_ave))
            #np.savetxt('test.csv',  mean_ratio_group.T, delimiter=',')  

        # generate the whole dataset and normalize a part of it
        # generate the load_normal, include load, weather(tem, rhu, wind)    
        for i in range (12):
            load = data_origin[i]
            load_raw_array = load.iloc[:, 1:2]  
            if use_mean_ratio == True:
                if use_different_mean_ratio == True:
                    load_raw_array = load_raw_array - mean_ratio_all[i,:].reshape(-1,1)
                elif use_CV_ratio == True:
                    load_raw_array = load_raw_array - mean_ratio_group.reshape(-1,1)
                    # load_raw_array = load_raw_array - 1
                else:
                    load_raw_array = load_raw_array - mean_ratio_all_ave.reshape(-1,1)
            weather_raw_array = load.iloc[:, 2:5]
            # calculate the change of weather
            if delta_weather == True:
                weather_raw_array = np.array(weather_raw_array)
                weather_raw_array_pre = np.concatenate((weather_raw_array[0].reshape(1,-1), weather_raw_array[0:-1]), axis=0)
                weather_raw_array = weather_raw_array - weather_raw_array_pre
            # the load and weather
            load_raw_array = np.concatenate((load_raw_array, weather_raw_array), axis=1)
            # normalization
            load_mean[i] = load_raw_array.mean(axis=0)
            load_std[i] = load_raw_array.std(axis=0)
            if use_ratio == True:   
                load_mean[i,0]=0
                load_std[i,0]=1
            load_normal_array = (load_raw_array - load_mean[i])/load_std[i]
            load_normal.append(load_normal_array)  
        # generate the whole dataset (load, weather, rain, Sat, Mon, Date, Weekend)
        data_normal = []
        for i in range (12):
            rain = data_origin[i].iloc[:,5:6] # rainfall
            if delta_weather == True:
                rain = np.array(rain)
                rain_pre = np.concatenate((rain[0].reshape(1,-1), rain[0:-1]), axis=0)
                rain = rain - rain_pre
                #print ('rain shape:', np.shape(rain))
            date = data_origin[i].iloc[:,7:19]
            weekend = data_origin[i].iloc[:,6:7]
            Sat = data_origin[i].iloc[:,19:20]
            Mon = data_origin[i].iloc[:,20:21]
            data_normal_array = np.concatenate((load_normal[i], rain, Sat, Mon,   date, weekend), axis=1)
            #load_normal 0,1,2,3, rain 4, Sat 5, Mon 6,   date 7:18, weekend 19
            data_normal.append(data_normal_array)

        # sliding windows to generate train data
        data_input_list = []
        data_output_list = []
        for k in range(12):
            data = data_normal[k] 
            test_num = data.shape[0] # 
            # date and weekend can be obtained in advance
            next_date = np.zeros((test_num,12))
            next_weekend = np.zeros((test_num,1))
            next_Sat = np.zeros((test_num, 1))
            next_Mon = np.zeros((test_num,1))
            if use_forcast_weather == True:
                next_weather = np.zeros((test_num,4))
            data_output = np.zeros((test_num-24,1)) # 32592
            for i in range (test_num-24):
                next_Sat[i] = data[i + 24, 5]
                next_Mon[i] = data[i + 24, 6]
                next_date[i] = data[i + 24, 7:19]
                next_weekend[i] = data[i + 24, 19]
                if use_forcast_weather == True:
                    next_weather[i] = data[i + 24, 1:5]
            for i in range (24):
                next_Sat[test_num-24+i] = -999 
                next_Mon[test_num-24+i] = -999 
                next_date[test_num - 24 + i] = -999  
                next_weekend[test_num - 24 + i] = -999 
                if use_forcast_weather == True:
                    next_weather[test_num - 24 + i] = -999
            # choose time scale
            if args.use_annual:
                date_info = next_date[:,5:6] + next_date[:,6:7] + next_date[:,7:8] + next_date[:,8:9] #是否夏天
            if args.use_monthly:
                date_info = next_date
            if args.use_quarterly:
                first = next_date[:,0:1] + next_date[:,1:2] + next_date[:,2:3]
                second = next_date[:,3:4] + next_date[:,4:5] + next_date[:,5:6]
                third = next_date[:,6:7] + next_date[:,7:8] + next_date[:,8:9]
                fourth = next_date[:,9:10] + next_date[:,10:11] + next_date[:,11:12]
                date_info = np.hstack((np.hstack((np.hstack((first, second)),third)),fourth))

            # generate the whole dataset
            if use_forcast_weather == True:
                data_input_all = np.concatenate((data, next_weather, next_Sat, next_Mon, date_info, next_weekend),axis=1)
                #load_normal 0,1,2,3, rain 4, Sat 5, Mon 6,   date 7:18, weekend 19
            else:
                data_input_all = np.concatenate((data, next_Sat, next_Mon, date_info, next_weekend),axis=1)           
            # generate data_input
            delet_ID = np.arange(test_num-24,test_num)
            data_input = np.delete( data_input_all,delet_ID,0)
            if use_forcast_weather == True:
                data_input = np.delete( data_input,[1,2,3,4,   5,6,   7,8,9,10,11,12,13,14,15,16,17,18,   19],1)
            else:
                data_input = np.delete( data_input,[5,6,   7,8,9,10,11,12,13,14,15,16,17,18,   19],1)
            # 9 inputs: load, T, Rhu, Wind, Rain, Sat, Mon, date_info, Week
            data_input_list.append(data_input)
            # generate data_output
            for i in range (test_num-24):
                data_output[i] = data[i+24,0]
            data_output_list.append(data_output)
        mean_ratio_all_pred = np.zeros((12, test_num-24))
        mean_ratio_all_ave_pred = np.zeros((test_num-24,1))
        mean_ratio_group_pred = np.zeros((1, test_num-24))

        for i in range (test_num-24):
            if use_mean_ratio == True:
                if use_different_mean_ratio == True:
                    for j in range (12):
                        mean_ratio_all_pred[j,i] = mean_ratio_all[j,i+24]
                elif use_CV_ratio == True:
                    mean_ratio_group_pred[0,i] = mean_ratio_group[i+24]
                else:
                    mean_ratio_all_ave_pred[i] = mean_ratio_all_ave[i+24]

        self.mean_ratio_all_ave_pred = mean_ratio_all_ave_pred
        self.mean_ratio_all_pred = mean_ratio_all_pred
        self.mean_ratio_group_pred = mean_ratio_group_pred       
        self.data_origin = data_origin
        self.data_input_list = data_input_list
        self.data_list = data_list
        self.data_output_list = data_output_list
        self.load_mean = load_mean
        self.load_std = load_std

class grid_data2:
    def __init__(self,args,use_list):
        # hyper parameters
        use_forcast_weather = args.use_forcast_weather # whether to use the forecast data, 1 means True, 0 means False
        delta_weather = args.delta_weather
        use_filter = args.use_filter # filter the dimensionless trend

        use_ratio = args.use_ratio # dimensionless ratio
        use_mean_ratio = args.use_mean_ratio
        use_different_mean_ratio = args.use_different_mean_ratio # this indicates that each district only uses its own dimensionless trend
        use_CV_ratio = args.use_CV_ratio # this indicates that different groups have different dimensionless trends, and the districts within each group use the same dimensionless trend

        # load data
        data_origin = []
        data_list = ['CY','HD','FT','SJS','PG','YZ','CP',
                'MTG','FS','DX','MY','SY'] # Lack of PG, PG weather data has been missing too much，HR and YQ not used 
        for i in range (12):
            if use_ratio == True:
                name = '../data_grid/data/data_day_'+ data_list[i] +'.csv'
            else:
                name = '../data_grid/data/'+ data_list[i] +'.csv'
            #name = 'E:/Research CYT/grid/enlstm_code/ratio/data/data_day_'+ data_list[i] +'.csv'
            df = pd.read_csv(name)
            # print(df.shape)
            data_origin.append(df)
            # print(data_origin[i].shape)
            # exec (script)
            # exec (script2)
            #print(i)
        print('shape of df',np.shape(np.array(df)))
        print(len(data_origin))
        load_mean = np.zeros((12, 4))
        load_std = np.zeros((12, 4))
        load_normal = []
        # generate the mean_ratio_all
        if use_mean_ratio == True:
            # mean_ratio_all, mean_ratio_all_ave, mean_ratio_group = ave_ratio (data_origin, use_filter)
            mean_ratio_all = None
            for i in range (12):
                load = data_origin[i]
                load_raw_array = load.iloc[:, 1]  # 32616 ratio
                input_load = np.array(load_raw_array)
                data_num = np.shape(input_load)[0]
                week_num = int(data_num/168) # calculate the number of weeks
                # reshape loads to (num of hours in one week) * (num of weeks)
                delet_ID = np.arange(week_num*168, data_num)
                input_load_del = np.delete( input_load, delet_ID, 0)# generate integer week results
                input_load_week = input_load_del.reshape(week_num,168) # 168(num of hours in one week) * num of weeks
                # calculate the average ratio in one week 对14个区分别求周平均
                input_load_week_mean = np.mean(input_load_week, axis=0)
                print('original:',np.mean(input_load_week_mean))
                #print('original:',np.max(input_load_week_mean)-np.min(input_load_week_mean))
                if use_filter == True:#滤波
                    # low pass
                    b, a = signal.butter(8, 0.2, 'lowpass')
                    filter_input_load_week_mean = signal.filtfilt(b, a, input_load_week_mean)
                    # Zoom to the scale of the ratio before filtering. Because filtering will reduce the scale of the ratio.
                    filter_input_load_week_mean = (filter_input_load_week_mean-np.min(filter_input_load_week_mean)) / (np.max(filter_input_load_week_mean)-np.min(filter_input_load_week_mean))#标准化的滤波后周平均数据
                    input_load_week_mean = filter_input_load_week_mean * (np.max(input_load_week_mean)-np.min(input_load_week_mean)) + np.min(input_load_week_mean)#滤波后的周平均数据
                    print('filtered:',np.mean(input_load_week_mean))
                # generate the average ratio for the length of data_num
                mean_ratio = None
                for i in range (week_num+1):
                    if mean_ratio is None:
                        mean_ratio = input_load_week_mean
                    else:
                        mean_ratio = np.hstack((mean_ratio, input_load_week_mean))
                delet_ID = np.arange(data_num, np.shape(mean_ratio)[0])
                mean_ratio = np.delete( mean_ratio, delet_ID, 0).reshape(1,-1)
                # save the mean_ratio of all districts
                if mean_ratio_all is None: # mean_ratio_all is the mean_ratio of all the districts
                    mean_ratio_all = mean_ratio
                else:
                    mean_ratio_all = np.vstack((mean_ratio_all, mean_ratio))

            mean_ratio_all_ave = np.mean(mean_ratio_all, axis=0) # mean_ratio_all_ave is the average of mean_ratio_all over 14 districts
            print('the sum of filtered:',np.mean(np.sum(mean_ratio_all, axis=0)))

            uselist = use_list
            alllist = [y for y in range(12)]
            disuselist= list(set(alllist)-set(uselist))

            mean_ratio_group = np.sum(np.delete(mean_ratio_all,disuselist,0), axis=0)/len(uselist)
            print ('shape of mean_ratio_all is:', np.shape(mean_ratio_all))
            print ('shape of mean_ratio_all_ave is:', np.shape(mean_ratio_all_ave))
            #np.savetxt('test.csv',  mean_ratio_group.T, delimiter=',')  

        # generate the whole dataset and normalize a part of it
        # generate the load_normal, include load, weather(tem, rhu, wind)    
        for i in range (12):
            load = data_origin[i]
            load_raw_array = load.iloc[:, 1:2]  
            if use_mean_ratio == True:
                if use_different_mean_ratio == True:
                    load_raw_array = load_raw_array - mean_ratio_all[i,:].reshape(-1,1)
                elif use_CV_ratio == True:
                    load_raw_array = load_raw_array - mean_ratio_group.reshape(-1,1)
                    # load_raw_array = load_raw_array - 1
                else:
                    load_raw_array = load_raw_array - mean_ratio_all_ave.reshape(-1,1)
            weather_raw_array = load.iloc[:, 2:5]
            # calculate the change of weather
            if delta_weather == True:
                weather_raw_array = np.array(weather_raw_array)
                weather_raw_array_pre = np.concatenate((weather_raw_array[0].reshape(1,-1), weather_raw_array[0:-1]), axis=0)
                weather_raw_array = weather_raw_array - weather_raw_array_pre
            # the load and weather
            load_raw_array = np.concatenate((load_raw_array, weather_raw_array), axis=1)
            # normalization
            load_mean[i] = load_raw_array.mean(axis=0)
            load_std[i] = load_raw_array.std(axis=0)
            if use_ratio == True:   
                load_mean[i,0]=0
                load_std[i,0]=1
            load_normal_array = (load_raw_array - load_mean[i])/load_std[i]
            load_normal.append(load_normal_array)  
        # generate the whole dataset (load, weather, rain, Sat, Mon, Date, Weekend)
        data_normal = []
        for i in range (12):
            rain = data_origin[i].iloc[:,5:6] # rainfall
            if delta_weather == True:
                rain = np.array(rain)
                rain_pre = np.concatenate((rain[0].reshape(1,-1), rain[0:-1]), axis=0)
                rain = rain - rain_pre
                #print ('rain shape:', np.shape(rain))
            date = data_origin[i].iloc[:,7:19]
            weekend = data_origin[i].iloc[:,6:7]
            Sat = data_origin[i].iloc[:,19:20]
            Mon = data_origin[i].iloc[:,20:21]
            data_normal_array = np.concatenate((load_normal[i], rain, Sat, Mon,   date, weekend), axis=1)
            #load_normal 0,1,2,3, rain 4, Sat 5, Mon 6,   date 7:18, weekend 19
            data_normal.append(data_normal_array)

        # sliding windows to generate train data
        data_input_list = []
        data_output_list = []
        for k in range(12):
            data = data_normal[k] 
            test_num = data.shape[0] # 
            # date and weekend can be obtained in advance
            next_date = np.zeros((test_num,12))
            next_weekend = np.zeros((test_num,1))
            next_Sat = np.zeros((test_num, 1))
            next_Mon = np.zeros((test_num,1))
            if use_forcast_weather == True:
                next_weather = np.zeros((test_num,4))
            data_output = np.zeros((test_num-24,1)) # 32592
            for i in range (test_num-24):
                next_Sat[i] = data[i + 24, 5]
                next_Mon[i] = data[i + 24, 6]
                next_date[i] = data[i + 24, 7:19]
                next_weekend[i] = data[i + 24, 19]
                if use_forcast_weather == True:
                    next_weather[i] = data[i + 24, 1:5]
            for i in range (24):
                next_Sat[test_num-24+i] = -999 
                next_Mon[test_num-24+i] = -999 
                next_date[test_num - 24 + i] = -999  
                next_weekend[test_num - 24 + i] = -999 
                if use_forcast_weather == True:
                    next_weather[test_num - 24 + i] = -999
            # choose time scale
            if args.use_annual:
                date_info = next_date[:,5:6] + next_date[:,6:7] + next_date[:,7:8] + next_date[:,8:9] #是否夏天
            if args.use_monthly:
                date_info = next_date
            if args.use_quarterly:
                first = next_date[:,0:1] + next_date[:,1:2] + next_date[:,2:3]
                second = next_date[:,3:4] + next_date[:,4:5] + next_date[:,5:6]
                third = next_date[:,6:7] + next_date[:,7:8] + next_date[:,8:9]
                fourth = next_date[:,9:10] + next_date[:,10:11] + next_date[:,11:12]
                date_info = np.hstack((np.hstack((np.hstack((first, second)),third)),fourth))

            # generate the whole dataset
            if use_forcast_weather == True:
                data_input_all = np.concatenate((data, next_weather, next_Sat, next_Mon, date_info, next_weekend),axis=1)
                #load_normal 0,1,2,3, rain 4, Sat 5, Mon 6,   date 7:18, weekend 19
            else:
                data_input_all = np.concatenate((data, next_Sat, next_Mon, date_info, next_weekend),axis=1)           
            # generate data_input
            delet_ID = np.arange(test_num-24,test_num)
            data_input = np.delete( data_input_all,delet_ID,0)
            if use_forcast_weather == True:
                data_input = np.delete( data_input,[1,2,3,4,   5,6,   7,8,9,10,11,12,13,14,15,16,17,18,   19],1)
            else:
                data_input = np.delete( data_input,[5,6,   7,8,9,10,11,12,13,14,15,16,17,18,   19],1)
            # 9 inputs: load, T, Rhu, Wind, Rain, Sat, Mon, date_info, Week
            data_input_list.append(data_input)
            # generate data_output
            for i in range (test_num-24):
                data_output[i] = data[i+24,0]
            data_output_list.append(data_output)
        mean_ratio_all_pred = np.zeros((12, test_num-24))
        mean_ratio_all_ave_pred = np.zeros((test_num-24,1))
        mean_ratio_group_pred = np.zeros((1, test_num-24))

        for i in range (test_num-24):
            if use_mean_ratio == True:
                if use_different_mean_ratio == True:
                    for j in range (12):
                        mean_ratio_all_pred[j,i] = mean_ratio_all[j,i+24]
                elif use_CV_ratio == True:
                    mean_ratio_group_pred[0,i] = mean_ratio_group[i+24]
                else:
                    mean_ratio_all_ave_pred[i] = mean_ratio_all_ave[i+24]

        self.mean_ratio_all_ave_pred = mean_ratio_all_ave_pred
        self.mean_ratio_all_pred = mean_ratio_all_pred
        self.mean_ratio_group_pred = mean_ratio_group_pred       
        self.data_origin = data_origin
        self.data_input_list = data_input_list
        self.data_list = data_list
        self.data_output_list = data_output_list
        self.load_mean = load_mean
        self.load_std = load_std


def getRank(dataset_len,testout_num,testout_rank,locnode_num,locframe_num):
    
    fold_num=dataset_len/testout_num
    all_list=list(range(0,dataset_len))
    testout_list=[all_list[i:i+testout_num] for i in range(0,dataset_len,testout_num)][testout_rank]
    
    in_list=list(set(all_list)-set(testout_list))
    o_list=random.sample(in_list,testout_num)

    in_list=list(set(in_list)-set(o_list))
    nodein_list=[[i] for i in o_list]
    if locframe_num == 1:
        for i in range(testout_num,locnode_num):
            app_list=random.sample(in_list,1)
            in_list=list(set(in_list)-set(app_list))
            nodein_list.append(app_list)
        nodein_list=sorted(nodein_list,key=(lambda x:x[0]))
    else:
        for _ in range(1,locframe_num):
            app_list=random.sample(in_list,locnode_num)
            in_list=list(set(in_list)-set(app_list))
            for i in range(locnode_num):
                nodein_list[i].append(app_list[i])
        nodein_list=sorted(nodein_list,key=(lambda x:x[0]))
        for i in range(locnode_num):
            nodein_list[i]=sorted(nodein_list[i])
    return nodein_list,testout_list

def loadDataSeq_grid(data_id, data_origin, data_in_list, data_out_list, args):
    train_data_input = None
    train_data_output = None
    for k in (data_id):
        # get the k th train date
        table_input = data_in_list [k]
        table_output = data_out_list [k]
        # calcute the length of training set
        len_num = int((data_origin[k].shape[0]/24)-(args.train_len/24))
        
        # generate train_data_input
        train_data_input_temp = np.zeros((len_num, args.train_len, args.input_dim))
        for i in range (len_num):
            for j in range (args.input_dim):
                train_data_input_temp[i,:,j] = table_input[:,j][(i*24):((i*24)+args.train_len)]
        if train_data_input is None:
            train_data_input = train_data_input_temp
        else:
            train_data_input = np.concatenate((train_data_input, train_data_input_temp), axis = 0)
        
        # generate train_data_output
        train_data_output_temp = np.zeros((len_num, args.train_len, args.output_dim)) 
        for i in range (len_num):
            for j in range (args.output_dim):
                train_data_output_temp[i,:,j] = table_output[:,j][(i*24):((i*24)+args.train_len)]
        if train_data_output is None:
            train_data_output = train_data_output_temp
        else:
            train_data_output = np.concatenate((train_data_output, train_data_output_temp), axis = 0)

    return train_data_input, train_data_output 

def loadDataSeq_num(num,data_id, data_origin, data_in_list, data_out_list, args):
    train_data_input = None
    train_data_output = None
    for k in (data_id):
        # get the k th train date
        table_input = data_in_list [k]
        table_output = data_out_list [k]
        # calcute the length of training set
        len_num = int((data_origin[k].shape[0]/24)-(args.train_len/24))
        numlist=[0,len_num-365*2,len_num-365*1,len_num]

        # generate train_data_input
        train_data_input_temp = np.zeros((len_num, args.train_len, args.input_dim))
        for i in range (numlist[num],numlist[num+1]):
            for j in range (args.input_dim):
                train_data_input_temp[i,:,j] = table_input[:,j][(i*24):((i*24)+args.train_len)]
        if train_data_input is None:
            train_data_input = train_data_input_temp
        else:
            train_data_input = np.concatenate((train_data_input, train_data_input_temp), axis = 0)
        
        # generate train_data_output
        train_data_output_temp = np.zeros((len_num, args.train_len, args.output_dim)) 
        for i in range (numlist[num],numlist[num+1]):
            for j in range (args.output_dim):
                train_data_output_temp[i,:,j] = table_output[:,j][(i*24):((i*24)+args.train_len)]
        if train_data_output is None:
            train_data_output = train_data_output_temp
        else:
            train_data_output = np.concatenate((train_data_output, train_data_output_temp), axis = 0)

    return train_data_input, train_data_output 

def getDataset_loc(data_origin, data_in_list, data_out_list, args):
    print('filelist:')
    print(args.model_rank)
    x_tr, y_tr = loadDataSeq_num(0,[args.model_rank], data_origin, data_in_list, data_out_list, args)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr[:, -args.predict_len:, :])) 

    x_vl, y_vl = loadDataSeq_num(1,[args.model_rank], data_origin, data_in_list, data_out_list, args)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl[:, -args.predict_len:, :]))
    
    return data_tr, data_vl

def getDataset_locmulti(nodein_list,data_origin,data_in_list, data_out_list, args):

    uselist=nodein_list[args.model_rank]
    print('uselist:')
    print(uselist)
    x_tr, y_tr = loadDataSeq_num(0,[j for j in uselist], data_origin, data_in_list, data_out_list, args)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr[:, -args.predict_len:, :])) 

    x_vl, y_vl = loadDataSeq_num(1,[j for j in uselist], data_origin, data_in_list, data_out_list, args)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl[:, -args.predict_len:, :])) 

    name=args.model_rank

    return data_tr,data_vl,name

def getDataset_sl_full(dataDir,nodein_list,testout_list,locnode_num,locframe_num, data_origin, data_in_list, data_out_list, args):
    filelist=os.listdir(dataDir)
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    data_tr_dict = {}
    data_ts_dict = {}
    data_ts_in_dict = {}
    data_ts_out_dict = {}

    n_total = 0
    counter=0
    for i in range(locnode_num):
        x_tr, y_tr = loadDataSeq_num(0,[j for j in nodein_list[i]], data_origin, data_in_list, data_out_list, args)
        # x_ts, y_ts, _ = loadData_swprop(2,[fpathlist[j] for j in nodein_list[i]], features, dataset_features, seq_len, step, winsize)

        x_tp = np.asarray(x_tr)
        r1, r2, r3 = x_tp.shape
        n_total += r1 * r2
        #print('r1 * r2: ', r1 * r2)
        tp_tr = np.asarray(x_tr)
        print(' ')
        print(f'id_: {counter}')
        print(f'x_tr.shape: {tp_tr.shape}')
        print(f'y_tr.shape: {np.asarray(y_tr).shape}')
        dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr[:, -args.predict_len:, :]))
        # dataset_ts = SeqDataset3(np.asarray(x_ts), np.asarray(y_ts))

        data_tr_dict[counter] = dataset_tr
        # data_ts_dict[counter] = dataset_ts
        counter+=1
    
    x_tr, y_tr = loadDataSeq_num(0,[j for j in [i for item in nodein_list for i in item]], data_origin, data_in_list, data_out_list, args)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr[:, -args.predict_len:, :])) 

    x_vl, y_vl = loadDataSeq_num(1,[j for j in [i for item in nodein_list for i in item]], data_origin, data_in_list, data_out_list, args)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl[:, -args.predict_len:, :])) 
    
    counter=0
    for i in range(locframe_num * locnode_num):
        rank=[j for item in nodein_list for j in item][i]
        x_ts_in, y_ts_in = loadDataSeq_num(2,[rank], data_origin, data_in_list, data_out_list, args)

        tp_in = np.asarray(x_ts_in)
        print(f'shape of x_ts_in: {tp_in.shape}')

        data_ts_in_dict[counter] = SeqDataset3(np.asarray(x_ts_in), np.asarray(y_ts_in[:, -args.predict_len:, :]))
        counter+=1

    counter=0
    for i in testout_list:
        x_ts_out, y_ts_out = loadDataSeq_grid([i], data_origin, data_in_list, data_out_list, args)

        tp_out = np.asarray(x_ts_out)
        print(f'shape of x_ts_out: {tp_out.shape}')

        data_ts_out_dict[counter] = SeqDataset3(np.asarray(x_ts_out), np.asarray(y_ts_out[:, -args.predict_len:, :]))
        counter+=1

    return data_tr_dict,data_tr,data_vl,data_ts_in_dict,data_ts_out_dict,n_total

def predict(data, args, model_predict=None): # predict 24h each time，and join the predictions to get the final result
    result = []
    input_ = torch.tensor(data)
    input_ = Variable(input_.view(1, len(data), args.input_dim).float()).cuda()
    i = 0
    while i <= len(data) - args.train_len:
        # pred = model_predict(input_[:, i:i+config.train_len, :].transpose(1,2))
        # result.append(pred[:, 0, :])
        pred = model_predict(input_[:, i:i+args.train_len, :])
        # result.append(pred[0])
        # pred = input_[:, i:i+config.train_len, :]
        result.append(pred.reshape(-1,24))
        # print('predicting: {} to {}'.format(i, i + config.train_len))
        i += 24
    return torch.cat(result, dim=1)

def predictcurve(model,args,k,data,num):
    criterion = torch.nn.MSELoss()
    criterion2 = torch.nn.L1Loss()
    data_list = data.data_list
    input_ = data.data_input_list[k] # ->array(data_len * in_dim)
    target = data.data_output_list[k]# ->array(data_len * 1)
    raw_data = pd.read_csv(r"../data_grid/data/{}.csv".format(data_list[k]))
    real_std = raw_data.LOAD.std()
    real_mean = raw_data.LOAD.mean()
    raw = np.array(raw_data.LOAD)[args.predict_len:-args.predict_len]
    pred = predict(input_, args, model_predict=model)
    # add the average trend to get the real ratio
    train_len = args.train_len - 24
    if args.use_mean_ratio == True:
        if args.use_different_mean_ratio == True:
            mean_ratio = data.mean_ratio_all_pred[k,:]
        elif args.use_CV_ratio == True:
            mean_ratio = data.mean_ratio_group_pred[0,:]                
        else:
            mean_ratio = data.mean_ratio_all_ave_pred
        # print('mean_ratio:', mean_ratio)
        # print(pred.shape)
        # print(mean_ratio.reshape(-1, 1)[train_len:].shape)
        pred = pred.cpu().detach().numpy().reshape(-1,1) + mean_ratio.reshape(-1, 1)[train_len:] 
        target = target[train_len:] + mean_ratio.reshape(-1,1)[train_len:]
        loss = criterion(torch.tensor(pred[:, 0]).float(), torch.tensor(target[:, 0]).float())
    else:
        # print(pred.shape)
        pred = pred.cpu().detach().numpy()[0]
        target = target[train_len:]
        loss = criterion(torch.tensor(pred).float(), torch.tensor(target[:, 0]).float())
    # print("ID{}\t test loss: {}".format(k, loss))
    mean = data.load_mean[k][0]
    std = data.load_std[k][0]
    pred_ratio = Regeneralize(np.array(pred[:, 0]), mean, std)
    pred_real = pred_ratio * raw[train_len:]
    # print("pred_real{}".format(pred_real.shape))
    target_ratio = Regeneralize(target, mean, std).reshape(-1,1)
    target_real = target_ratio * raw[train_len:].reshape(-1,1)
    # print("target_real{}".format(target_real.reshape(-1).shape))
    loss_ratio = criterion(torch.tensor(pred_ratio).float(), torch.tensor(target_ratio[:, 0]).float()) #new
    # print("ID{}\t ratio loss: {}".format(k, loss_ratio))
    # make a normalization of real load value:
    loss_relative = np.mean(np.abs(pred_real - target_real.reshape(-1))/target_real.reshape(-1))
    std = 1 * pred_real.std(0)
    pred_normalized = (pred_real - real_mean) / real_std
    target_normalized = (target_real.reshape(-1) - real_mean) / real_std
    mseloss_real = criterion(Variable(torch.tensor(pred_normalized[-num*24:]).float()),
                            Variable(torch.tensor(target_normalized[-num*24:]).float()))
    maeloss_real = criterion2(Variable(torch.tensor(pred_normalized[-num*24:]).float()),
                            Variable(torch.tensor(target_normalized[-num*24:]).float()))
    return np.array(mseloss_real), np.array(maeloss_real), pred_real, target_real.reshape(-1)

def loc_evaluate(args, nodein_list, testout_list, data, device):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    # str_lr = '_'.join(['lr', str(args.lr)])
    # str_seed = '_'.join(['seed', str(args.seed)])
    # args_dict =vars(args)
    # arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models,args.locframe_num, args.fold_id)
    # if not os.path.exists(arg_path):
    #     os.makedirs(arg_path)    
    # with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
    #     for key, value in args_dict.items():
    #         f.write('{}:{}'.format(key, value))
    #         f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = data.data_list
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]


    ##路径，计算loss，绘图
    # log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    # if not os.path.exists(log_path):
    #     os.makedirs(log_path)
    
    for k in range(args.no_models):
        str_lr = '_'.join(['lr', str(args.lr)])
        str_seed = '_'.join(['seed', str(args.seed)])

        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        print('**********************************************')

        if args.locframe_num==1:
            rank = test_in_id[k]
            filename=filelist[rank]
            print('model filename')
            print(filename.split('.')[0])
            print('')
            Name=filename.split('.')[0]
            model_path = modelpath + '/{}/{}clients/{}frames/{}/model'.format(str_seed,args.no_models,args.locframe_num,Name)
        else:
            Name=k
            print('model filename')
            print(Name)
            print('')
            model_path = modelpath + '/{}/{}clients/{}frames/fold{}/{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
 
        args_dict =vars(args)
        arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models, args.locframe_num, args.fold_id,Name)
        if not os.path.exists(arg_path):
            os.makedirs(arg_path)    
        with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
            for key, value in args_dict.items():
                f.write('{}:{}'.format(key, value))
                f.write('\n')
        
        test_in_name_list=[]
        test_in_mseloss_list=[]
        test_in_maeloss_list=[]
        test_in_len_list=[]        
        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)

        model = get_transformer(args).to(device)
        
        model_list=os.listdir(model_path)
        model_list.sort()
        modelname=model_list[-1]
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        for d in range(args.no_models*args.locframe_num):
            rank = test_in_id[d]
            filename=filelist[rank]
            print(filename)
            name=filename
            test_in_name_list.append(name)

            ts_mseloss, ts_maeloss, data_list, output_list = predictcurve(model, args, rank, data, 365)
            test_in_mseloss_list.append(ts_mseloss)
            test_in_maeloss_list.append(ts_maeloss)
            test_in_len_list.append(len(data_list[-365*24:]))
            
            df = dict()
            df['Target'] = output_list
            df['Predict'] = data_list
            df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
            df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

            figplt(data_list[-365*24:],output_list[-365*24:],log_path,name)

        mseloss_locnode=[]
        maeloss_locnode=[]
        if args.locframe_num != 1:
            test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
            test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
            test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
            for i in range(args.no_models):
                node_datanum = sum(test_in_len_list2[i])
                node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
                node_ts_mseloss = node_unbl_mseloss/node_datanum
                mseloss_locnode.append(node_ts_mseloss)
                node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
                node_ts_maeloss = node_unbl_maeloss/node_datanum
                maeloss_locnode.append(node_ts_maeloss)
        
        test_out_name_list=[]
        test_out_mseloss_list=[]
        test_out_maeloss_list=[]
        test_out_len_list=[]

        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testout'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)
            
        for j in range(args.testout_num):
            rank = testout_list[j]
            filename=filelist[rank]
            print(filename)
            name=filename
            ##路径，计算loss，绘图
            test_out_name_list.append(name)

            ts_mseloss, ts_maeloss, data_list, output_list = predictcurve(model, args, rank, data, 0)
            test_out_mseloss_list.append(ts_mseloss)
            test_out_maeloss_list.append(ts_maeloss)
            test_out_len_list.append(len(data_list))

            df = dict()
            df['Target'] = output_list
            df['Predict'] = data_list
            df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
            df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

            figplt(data_list,output_list,log_path,name)

        #记录,做表格
        log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_in_mseloss_list[i]
            log_list[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_out_mseloss_list[j]
            log_list[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list[3][k] = mseloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df = pd.DataFrame(data = log_list)
        df=df.T
        df.rename(columns = columns,inplace=True)
        df.to_csv(os.path.join(arg_path,'mse.csv')) 

                #记录,做表格
        log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_in_maeloss_list[i]
            log_list2[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_out_maeloss_list[j]
            log_list2[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list2[3][k] = maeloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df2 = pd.DataFrame(data = log_list2)
        df2=df2.T
        df2.rename(columns = columns,inplace=True)
        df2.to_csv(os.path.join(arg_path,'mae.csv')) 

def evaluate(args, model, nodein_list, testout_list, data):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    str_lr = '_'.join(['lr', str(args.lr)])
    str_seed = '_'.join(['seed', str(args.seed)])
    args_dict =vars(args)
    arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models,args.locframe_num, args.fold_id)
    if not os.path.exists(arg_path):
        os.makedirs(arg_path)    
    with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
        for key, value in args_dict.items():
            f.write('{}:{}'.format(key, value))
            f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = data.data_list
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]
    test_in_name_list=[]
    test_in_mseloss_list=[]
    test_in_maeloss_list=[]
    test_in_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    for d in range(args.no_models*args.locframe_num):
        rank = test_in_id[d]
        filename=filelist[rank]
        print(filename)
        name=filename
        test_in_name_list.append(name)

        ts_mseloss, ts_maeloss, data_list, output_list = predictcurve(model, args, rank, data, 365)
        test_in_mseloss_list.append(ts_mseloss)
        test_in_maeloss_list.append(ts_maeloss)
        test_in_len_list.append(len(data_list[-365*24:]))
        
        df = dict()
        df['Target'] = output_list[-365*24:]
        df['Predict'] = data_list[-365*24:]
        df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
        df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

        figplt(data_list[-365*24:],output_list[-365*24:],log_path,name)

    mseloss_locnode=[]
    maeloss_locnode=[]
    if args.locframe_num != 1:
        test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
        test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
        test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
        for i in range(args.no_models):
            node_datanum = sum(test_in_len_list2[i])
            node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
            node_ts_mseloss = node_unbl_mseloss/node_datanum
            mseloss_locnode.append(node_ts_mseloss)
            node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
            node_ts_maeloss = node_unbl_maeloss/node_datanum
            maeloss_locnode.append(node_ts_maeloss)
    
    test_out_name_list=[]
    test_out_mseloss_list=[]
    test_out_maeloss_list=[]
    test_out_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testout'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)
        
    for j in range(args.testout_num):
        rank = testout_list[j]
        filename=filelist[rank]
        print(filename)
        name=filename
        ##路径，计算loss，绘图
        test_out_name_list.append(name)

        ts_mseloss, ts_maeloss, data_list, output_list = predictcurve(model, args, rank, data, 0)
        test_out_mseloss_list.append(ts_mseloss)
        test_out_maeloss_list.append(ts_maeloss)
        test_out_len_list.append(len(data_list))

        df = dict()
        df['Target'] = output_list
        df['Predict'] = data_list
        df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
        df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

        figplt(data_list,output_list,log_path,name)

    #记录,做表格
    log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_in_mseloss_list[i]
        log_list[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_out_mseloss_list[j]
        log_list[2][id_]=0
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list[3][k] = mseloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df = pd.DataFrame(data = log_list)
    df=df.T
    df.rename(columns = columns,inplace=True)
    df.to_csv(os.path.join(arg_path,'mse.csv')) 
    
    #记录,做表格
    log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_in_maeloss_list[i]
        log_list2[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_out_maeloss_list[j]
        log_list2[2][id_]=0
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list2[3][k] = maeloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df2 = pd.DataFrame(data = log_list2)
    df2=df2.T
    df2.rename(columns = columns,inplace=True)
    df2.to_csv(os.path.join(arg_path,'mae.csv')) 

def evaluated(args, model, nodein_list, testout_list, data):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    str_lr = '_'.join(['lr', str(args.lr)])
    str_seed = '_'.join(['seed', str(args.seed)])
    str_slseed = '_'.join(['seed', str(args.selseed)])

    args_dict =vars(args)
    arg_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_slseed, str_seed, args.no_models,args.locframe_num, args.fold_id)
    if not os.path.exists(arg_path):
        os.makedirs(arg_path)    
    with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
        for key, value in args_dict.items():
            f.write('{}:{}'.format(key, value))
            f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = data.data_list
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]
    test_in_name_list=[]
    test_in_mseloss_list=[]
    test_in_maeloss_list=[]
    test_in_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_slseed, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    for d in range(args.no_models*args.locframe_num):
        rank = test_in_id[d]
        filename=filelist[rank]
        print(filename)
        name=filename
        test_in_name_list.append(name)

        ts_mseloss, ts_maeloss, data_list, output_list = predictcurve(model, args, rank, data, 365)
        test_in_mseloss_list.append(ts_mseloss)
        test_in_maeloss_list.append(ts_maeloss)
        test_in_len_list.append(len(data_list[-365*24:]))
        
        df = dict()
        df['Target'] = output_list[-365*24:]
        df['Predict'] = data_list[-365*24:]
        df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
        df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

        figplt(data_list[-365*24:],output_list[-365*24:],log_path,name)

    mseloss_locnode=[]
    maeloss_locnode=[]
    if args.locframe_num != 1:
        test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
        test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
        test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
        for i in range(args.no_models):
            node_datanum = sum(test_in_len_list2[i])
            node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
            node_ts_mseloss = node_unbl_mseloss/node_datanum
            mseloss_locnode.append(node_ts_mseloss)
            node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
            node_ts_maeloss = node_unbl_maeloss/node_datanum
            maeloss_locnode.append(node_ts_maeloss)
    
    test_out_name_list=[]
    test_out_mseloss_list=[]
    test_out_maeloss_list=[]
    test_out_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}/testout'.format(args.global_epochs, str_lr, str_slseed, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)
        
    for j in range(args.testout_num):
        rank = testout_list[j]
        filename=filelist[rank]
        print(filename)
        name=filename
        ##路径，计算loss，绘图
        test_out_name_list.append(name)

        ts_mseloss, ts_maeloss, data_list, output_list = predictcurve(model, args, rank, data, 0)
        test_out_mseloss_list.append(ts_mseloss)
        test_out_maeloss_list.append(ts_maeloss)
        test_out_len_list.append(len(data_list))

        df = dict()
        df['Target'] = output_list
        df['Predict'] = data_list
        df = pd.DataFrame.from_dict(df, orient = 'index').transpose()
        df.to_csv(os.path.join(log_path, '{}.csv'.format(name)))

        figplt(data_list,output_list,log_path,name)

    #记录,做表格
    log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_in_mseloss_list[i]
        log_list[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_out_mseloss_list[j]
        log_list[2][id_]=0
    for i in range(12):
        log_list[0][i]=filelist[i]
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list[3][k] = mseloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df = pd.DataFrame(data = log_list)
    df=df.T
    df.rename(columns = columns,inplace=True)
    df.to_csv(os.path.join(arg_path,'mse.csv')) 
    
    #记录,做表格
    log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_in_maeloss_list[i]
        log_list2[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_out_maeloss_list[j]
        log_list2[2][id_]=0
    for i in range(12):
        log_list2[0][i]=filelist[i]
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list2[3][k] = maeloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df2 = pd.DataFrame(data = log_list2)
    df2=df2.T
    df2.rename(columns = columns,inplace=True)
    df2.to_csv(os.path.join(arg_path,'mae.csv')) 

def figplt(pred_real,target_real,logpath,name):
    plt.figure(figsize = (120, 6))
    plt.plot(np.arange(len(pred_real)),pred_real,linewidth=1.5,label='predict')
    plt.plot(np.arange(len(pred_real)),target_real.reshape(-1),linewidth=1.5,label='target')
    plt.xlim(0,len(pred_real))
    plt.legend()
    plt.savefig(logpath+'/'+name+ '_.png', dpi=100, bbox_inches='tight')
    plt.close()    

def Regeneralize (result, mean, std): # 输入的result是个array
    #row_size = result.shape[0]
    mean_matrix = mean
    std_matrix = std
    #mean_matrix = np.tile(mean_matrix, (row_size, 1))
    #std_matrix = np.tile(std_matrix, (row_size, 1))
    result_real_scale = (result * std_matrix) + mean_matrix
    return result_real_scale

if __name__ == '__main__':
    import argparse 
    parser = argparse.ArgumentParser()

    parser.add_argument('--model', type = str, default = 'Transformer') #
    parser.add_argument('--d_model', type = int, default = 12) # Lattent dim
    parser.add_argument('--q', type = int, default = 8) # Query size
    parser.add_argument('--v', type = int, default = 8) # Value size
    parser.add_argument('--h', type = int, default = 2) # Number of heads
    parser.add_argument('--N', type = int, default = 1) # Number of encoder and decoder to stack
    parser.add_argument('--attention_size', type = int, default = None)#12 # Attention window size
    parser.add_argument('--pe', type = str, default = 'regular') # Positional encoding
    parser.add_argument('--chunk_mode', type = str, default = None)
    parser.add_argument('--d_input', type = int, default = 9)  # From dataset
    parser.add_argument('--d_output', type = int, default = 1)  # From dataset
                        
    parser.add_argument('--gru_hid_dim', type = int, default = 5)
    parser.add_argument('--n_layers', type = int, default = 1)
    parser.add_argument('--opt', type = str, default = 'adam')
    parser.add_argument('--opt_scheduler', type=str, default='step')
    parser.add_argument('--opt_restart', type=int, default=0)
    parser.add_argument('--opt_decay_step', type=int, default=2000)
    parser.add_argument('--opt_decay_rate', type=float, default=0.9)
    parser.add_argument('--dropout', type=float, default=0.)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--momentum', type = float, default = 0.9)
    parser.add_argument('--seed', type=int, default=0)    
    parser.add_argument('--dataPath', type = str, default = '../data_grid')
    parser.add_argument('--logPath', type = str, default = '../log_grid/validation/slsm')
    parser.add_argument('--logPathts', type = str, default = '../log_grid/test/slsm')
    
    parser.add_argument('--num_feature', type = int, default = 9)
    parser.add_argument('--batch_size', type = int, default = 512)
    parser.add_argument('--lambda_',type = float, default = 1)

    parser.add_argument('--no_models', type = int, default = 3)#client num
    parser.add_argument('--k', type = int, default = 3)#aggregate num
    parser.add_argument('--local_epochs', type = int, default = 1)
    parser.add_argument('--global_epochs', type = int, default = 3)

    parser.add_argument('--train_len', type = int, default = 96)
    parser.add_argument('--predict_len', type = int, default = 24)
    parser.add_argument('--input_dim', type = int, default = 9)
    parser.add_argument('--output_dim', type = int, default = 1)
    parser.add_argument('--fold_id', type = int, default = 3)

    parser.add_argument('--use_forcast_weather', type = int, default = 1)
    parser.add_argument('--delta_weather', type = int, default = 0)
    parser.add_argument('--use_filter', type = int, default = 1)
    parser.add_argument('--use_ratio', type = int, default = 1)
    parser.add_argument('--use_mean_ratio', type = int, default = 1)
    parser.add_argument('--use_different_mean_ratio', type = int, default = 0)
    parser.add_argument('--use_CV_ratio', type = int, default = 1)

    args = parser.parse_args()
    args.use_annual = 1
    args.use_quarterly = 0
    args.use_monthly = 0 
    nodein_list,testout_list=getRank(12,4,0,8,1)
    grid_data(args,nodein_list)
