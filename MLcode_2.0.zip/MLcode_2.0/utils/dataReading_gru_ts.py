import torch 
import os 
import pandas as pd 
import numpy as np 
import random 
from utils.dataset import SeqDataset3, SeqDataset4
from sklearn.preprocessing import StandardScaler, MinMaxScaler 


def combineData(filePathList):
    data = pd.DataFrame()
    for filepath in filePathList:
        df = pd.read_csv(filepath)
        data = pd.concat([data, df], ignore_index = True)

    return data 

def getDataset_sep(dataDir, id_, features, seq_len, step, scaler):
    #features = ['GR', 'NPHI', 'RHOB', 'DTC', 'DTS']

    data_str = '_'.join(['data', str(id_)])
    dir_tr = os.path.join(dataDir, 'training', data_str)

    flist_tr = [ff for ff in os.listdir(dir_tr) if ff.endswith('.csv')]
    filePath_tr = [os.path.join(dir_tr, ff) for ff in flist_tr]

    dir_vl = os.path.join(dataDir, 'validation')
    dir_ts = os.path.join(dataDir, 'testing')
    filePathList_vl = []
    filePathList_ts = []

    for id_ in range(5):
        data_str = '_'.join(['data', str(id_)])

        fdir_vl = os.path.join(dir_vl, data_str)
        flist_vl = [ff for ff in os.listdir(fdir_vl) if ff.endswith('.csv')]
        filePath_vl = [os.path.join(fdir_vl, ff) for ff in flist_vl]
        filePathList_vl += filePath_vl

        fdir_ts = os.path.join(dir_ts, data_str)
        flist_ts = [ff for ff in os.listdir(fdir_ts) if ff.endswith('.csv')]
        filePath_ts = [os.path.join(fdir_ts, ff) for ff in flist_ts]
        filePathList_ts += filePath_ts


    data_tr = combineData(filePath_tr)

    data_tr_s= data_tr[features].values 
    scaler.fit(data_tr_s)

    x_tr, y_tr = loadDataSeq(filePath_tr, features, seq_len, step, scaler)
    x_vl, y_vl = loadDataSeq(filePathList_vl, features, seq_len, step, scaler)
    x_ts, y_ts = loadDataSeq(filePathList_ts, features, seq_len, step, scaler)

    dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr))
    dataset_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl))
    dataset_ts = SeqDataset3(np.asarray(x_ts), np.asarray(y_ts))

    return dataset_tr, dataset_vl, dataset_ts

def getDataset_sep2(dataDir, features, id_, seq_len, step, scaler):
    
    data_str = '_'.join(['data', str(id_)])
    dir_tr = os.path.join(dataDir, 'training', data_str)

    flist_tr = [ff for ff in os.listdir(dir_tr) if ff.endswith('.csv')]
    filePath_tr = [os.path.join(dir_tr, ff) for ff in flist_tr]
    #print('filePath_tr: ', filePath_tr)

    dir_vl = os.path.join(dataDir, 'validation', data_str)
    flist_vl = [ff for ff in os.listdir(dir_vl) if ff.endswith('.csv')]
    filePath_vl = [os.path.join(dir_vl, ff) for ff in flist_vl]


    dir_ts = os.path.join(dataDir, 'testing', data_str)
    flist_ts = [ff for ff in os.listdir(dir_ts) if ff.endswith('.csv')]
    filePath_ts = [os.path.join(dir_ts, ff) for ff in flist_ts]

    data_tr = combineData(filePath_tr)

    data_tr_s= data_tr[features].values 
    scaler.fit(data_tr_s)

    x_tr, y_tr = loadDataSeq(filePath_tr, features, seq_len, step, scaler)
    x_vl, y_vl = loadDataSeq(filePath_vl, features, seq_len, step, scaler)
    
    dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr))
    dataset_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl))
    #print('filePath_tr: ', filePath_tr)
    #print('filePath_vl: ', filePath_vl)
    #print('filePath_ts: ', filePath_ts)
    if (len(filePath_ts) > 0):

        x_ts, y_ts = loadDataSeq(filePath_ts, features, seq_len, step, scaler)
        dataset_ts = SeqDataset3(np.asarray(x_ts), np.asarray(y_ts))
        return dataset_tr, dataset_vl, dataset_ts
    else:
        return dataset_tr, dataset_vl, dataset_vl
        
def getDataset_entire_predictCurve(dataDir, filePath,features, seq_len, step, scaler):
    dir_tr = os.path.join(dataDir, 'training')

    filePathList_tr = []

    for id_ in range(5):
        data_str = '_'.join(['data', str(id_)])

        fdir_tr = os.path.join(dir_tr, data_str)
        flist_tr = [ff for ff in os.listdir(fdir_tr) if ff.endswith('.csv')]
        filePath_tr = [os.path.join(fdir_tr, ff) for ff in flist_tr]
        filePathList_tr += filePath_tr
    
    data_tr = combineData(filePathList_tr)

    data_tr_s = data_tr[features].values
    
    features2 = ['DEPT']+features

    scaler.fit(data_tr_s)

    df = pd.read_csv(filePath)
    df_s = df[features]
    data = df_s.values
    data_scaled = scaler.transform(data)

    data2 = df[features2].values

    x_list = []
    y_list = []
    data_list = []

    nrow, ncol = data_scaled.shape
    for i in range(0, nrow, step):
        i_end = i  + seq_len
        if(i_end > nrow):
            break

        data_s = data_scaled[i: i_end]
        data2_s = data2[i: i_end]
        #skip if any of the element is nan
        if(np.isnan(data_s).any()):
            continue

        i_s = 3 #index of DTS

        x = data_s[:, 0:3]
        y = data_s[:, 3]

        depthdts = data2_s[:,0:2]

        x_list.append(x)
        y_list.append(y)
        data_list.append(depthdts)

    dataset_ts = SeqDataset4(np.asarray(x_list), np.asarray(y_list), np.asarray(data_list))

    return dataset_ts

def getDataset_entire(dataDir, features, seq_len, step, scaler):
    #features = ['GR', 'NPHI', 'RHOB', 'DTC', 'DTS']

    # datadir is '../data'

    dir_tr = os.path.join(dataDir, 'training')
    dir_vl = os.path.join(dataDir, 'validation')
    dir_ts = os.path.join(dataDir, 'testing')

    filePathList_tr = []
    filePathList_vl = []
    filePathList_ts = []

    for id_ in range(5):
        data_str = '_'.join(['data', str(id_)])

        fdir_tr = os.path.join(dir_tr, data_str)
        flist_tr = [ff for ff in os.listdir(fdir_tr) if ff.endswith('.csv')]
        filePath_tr = [os.path.join(fdir_tr, ff) for ff in flist_tr]
        filePathList_tr += filePath_tr

        fdir_vl = os.path.join(dir_vl, data_str)
        flist_vl = [ff for ff in os.listdir(fdir_vl) if ff.endswith('.csv')]
        filePath_vl = [os.path.join(fdir_vl, ff) for ff in flist_vl]
        filePathList_vl += filePath_vl

        fdir_ts = os.path.join(dir_ts, data_str)
        flist_ts = [ff for ff in os.listdir(fdir_ts) if ff.endswith('.csv')]
        filePath_ts = [os.path.join(fdir_ts, ff) for ff in flist_ts]
        filePathList_ts += filePath_ts

    data_tr = combineData(filePathList_tr)

    data_tr_s= data_tr[features].values 

    scaler.fit(data_tr_s)

    x_tr, y_tr = loadDataSeq(filePathList_tr, features, seq_len, step, scaler)
    x_vl, y_vl = loadDataSeq(filePathList_vl, features, seq_len, step, scaler)
    x_ts, y_ts = loadDataSeq(filePathList_ts, features, seq_len, step, scaler)

    dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr))
    dataset_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl))
    dataset_ts = SeqDataset3(np.asarray(x_ts), np.asarray(y_ts))

    return dataset_tr, dataset_vl, dataset_ts

def loadDataSeq(filePathList, features, seq_len, step, scaler):
    xx_list = []
    yy_list = []

    for filePath in filePathList:
        df = pd.read_csv(filePath)
        df_s = df[features]

        data = df_s.values
        data_scaled = scaler.transform(data)

        x_list, y_list = genSeq(data_scaled, seq_len, step)

        xx_list += x_list
        yy_list += y_list 

    return xx_list, yy_list 

def loadDataSeq2(filePathList, features, seq_len, step, mu, std):
    """
    mu is the overall mean of all the groups
    std is the overall std of all the groups

    also, mu can be min, and std can be max if MinMaxScaler is used
    """
    xx_list = []
    yy_list = []

    for filePath in filePathList:
        df = pd.read_csv(filePath)
        df_s = df[features]

        data = df_s.values
        x_list, y_list = genSeq2(data, seq_len, step, mu, std)

        xx_list += x_list
        yy_list += y_list 

    return xx_list, yy_list 

def genSeq2(data, seq_len, step, mu, std):
    x_list = []
    y_list = []
    nrow, ncol = data.shape
    for i in range(0, nrow, step):
        i_end = i  + seq_len
        if(i_end > nrow):
            break

        data_s = data[i: i_end]
        #skip if any of the element is nan
        if(np.isnan(data_s).any()):
            continue

        i_s = 3 #index of DTS

        data_scaled = (data_s - mu)/std
        x = data_scaled[:, 0:3]
        y = data_scaled[:, 3]

        x_list.append(x)
        y_list.append(y)

    return x_list, y_list

def genSeq(data, seq_len, step):
    x_list = []
    y_list = []
    nrow, ncol = data.shape
    for i in range(0, nrow, step):
        i_end = i  + seq_len
        if(i_end > nrow):
            break

        data_s = data[i: i_end]
        #skip if any of the element is nan
        if(np.isnan(data_s).any()):
            continue

        i_s = 3 #index of DTS

        x = data_s[:, 0:3]
        y = data_s[:, 3]

        x_list.append(x)
        y_list.append(y)

    return x_list, y_list
    
def getDataset_mulstdScaler_fl(dataDir, features, seq_len, step):
    """
    scalername is a string type
    """
    scaler_list = []
    fpathlist_tr = []

    for id_ in range(5):

        data_str = '_'.join(['data', str(id_)])
        tr_dir = os.path.join(dataDir, 'training')
        fdir = os.path.join(tr_dir, data_str)
        fpathlist = [os.path.join(fdir, ff) for ff in os.listdir(fdir) if ff.endswith('.csv')]
        if(len(fpathlist) == 0):
            continue

        fpathlist_tr += fpathlist

        data = combineData(fpathlist)
        data_s = data[features].values

        scaler = StandardScaler()

        scaler.fit(data_s)
        scaler_list.append(scaler)


    std_denominator = np.array([0.0, 0.0, 0.0, 0.0])
    std_numerator =  np.array([0.0, 0.0, 0.0, 0.0])
    mean_denominator =  np.array([0.0, 0.0, 0.0, 0.0])
    mean_numerator =  np.array([0.0, 0.0, 0.0, 0.0])

    for e in scaler_list:
        mu = e.mean_
        std = e.scale_
        var = e.var_
        nn = e.n_samples_seen_

        mean_numerator += mu * nn
        mean_denominator += nn

        nn_1 = nn - np.array([1.0, 1.0, 1.0, 1.0])
        std_denominator += nn_1

        std_numerator += nn_1 * var

    std_overall = np.sqrt(std_numerator*1.0 /std_denominator)
    mu_overall = mean_numerator*1.0 / mean_denominator


    data_tr_dict = {}

    x_vl_list = []
    y_vl_list = []

    x_ts_list = []
    y_ts_list = []

    n_total = 0

    for id_ in range(5):
        data_str = '_'.join(['data', str(id_)])

        tr_dir = os.path.join(dataDir, 'training')
        fdir = os.path.join(tr_dir, data_str)
        fpathlist = [os.path.join(fdir, ff) for ff in os.listdir(fdir)  if ff.endswith('.csv')]

        #x_tr, y_tr = loadDataSeq(fpathlist, features, seq_len, step, scaler)

        x_tr, y_tr = loadDataSeq2(fpathlist, features, seq_len, step, mu_overall, std_overall)
        x_tp = np.asarray(x_tr)
        r1, r2, r3 = x_tp.shape
        n_total += r1 * r2
        #print('r1 * r2: ', r1 * r2)

        dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr))
        
        data_tr_dict[id_] = dataset_tr

        #validation
        dir_vl = os.path.join(dataDir, 'validation')
        fdir_vl = os.path.join(dir_vl, data_str)

        fpathlist_vl = [os.path.join(fdir_vl, ff) for ff in os.listdir(fdir_vl) if ff.endswith('.csv')]

        if(len(fpathlist_vl) > 0):
            x_vl, y_vl = loadDataSeq2(fpathlist_vl, features, seq_len, step, mu_overall, std_overall)
            x_vl_list += x_vl
            y_vl_list += y_vl

        #testing
        dir_ts = os.path.join(dataDir, 'testing')
        fdir_ts = os.path.join(dir_ts, data_str)

        fpathlist_ts = [os.path.join(fdir_ts, ff) for ff in os.listdir(fdir_ts) if ff.endswith('.csv')]


        if(len(fpathlist_ts) > 0):
            x_ts, y_ts = loadDataSeq2(fpathlist_ts, features, seq_len, step, mu_overall, std_overall)
            x_ts_list += x_ts 
            y_ts_list += y_ts 


    dataset_vl = SeqDataset3(np.asarray(x_vl_list), np.asarray(y_vl_list))
    dataset_ts = SeqDataset3(np.asarray(x_ts_list), np.asarray(y_ts_list))

    return data_tr_dict, dataset_vl, dataset_ts, mu_overall, std_overall, n_total

def getDataset_oneScaler_fl(dataDir, features, seq_len, step):

    """
    scaler is MinMaxScaler
    """
    #features = ['NPHI', 'RHOB', 'DTC', 'DTS']

    #get the range of the dataset



    range_list = []
    for id_ in range(5):

        data_str = '_'.join(['data', str(id_)])

        tr_dir = os.path.join(dataDir, 'training')
        fdir = os.path.join(tr_dir, data_str)
        fpathlist = [os.path.join(fdir, ff) for ff in os.listdir(fdir)  if ff.endswith('.csv')]
        #print('fpathlist of the training set: ', fpathlist)
        if(len(fpathlist) == 0):
            continue
        
        data = combineData(fpathlist)
        data_s = data[features].values 

        scaler1 = MinMaxScaler()
        scaler1.fit(data_s)
        data_max = scaler1.data_max_
        data_min = scaler1.data_min_
        
        range_list.append(data_max)
        range_list.append(data_min)

    range_array = np.asarray(range_list)
    #print('range_array: ', range_array)

    scaler = MinMaxScaler()
    scaler.fit(range_array)
    #print(dir(scaler))
    #print('data_max_: ', scaler.data_max_)
    #print('data_min_: ', scaler.data_min_)

    data_min = scaler.data_min_
    data_max = scaler.data_max_

    data_tr_dict = {}

    x_vl_list = []
    y_vl_list = []

    x_ts_list = []
    y_ts_list = []

    for id_ in range(5):
        data_str = '_'.join(['data', str(id_)])

        tr_dir = os.path.join(dataDir, 'training')
        fdir = os.path.join(tr_dir, data_str)
        fpathlist = [os.path.join(fdir, ff) for ff in os.listdir(fdir)  if ff.endswith('.csv')]

        #x_tr, y_tr = loadDataSeq(fpathlist, features, seq_len, step, scaler)

        x_tr, y_tr = loadDataSeq2(fpathlist, features, seq_len, step, data_min, data_max)
        dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr))
        
        #print('  ')
        #print('  ')
        #print('id_: ', id_)
        #print('length of dataset_tr: ')
        #print(len(dataset_tr))
        
        data_tr_dict[id_] = dataset_tr

        #validation
        dir_vl = os.path.join(dataDir, 'validation')
        fdir_vl = os.path.join(dir_vl, data_str)

        fpathlist_vl = [os.path.join(fdir_vl, ff) for ff in os.listdir(fdir_vl) if ff.endswith('.csv')]

        #print('fpathlist_vl: ', fpathlist_vl)
        if(len(fpathlist_vl) > 0):
            x_vl, y_vl = loadDataSeq2(fpathlist_vl, features, seq_len, step, data_min, data_max)
            x_vl_list += x_vl
            y_vl_list += y_vl

        #testing
        dir_ts = os.path.join(dataDir, 'testing')
        fdir_ts = os.path.join(dir_ts, data_str)

        fpathlist_ts = [os.path.join(fdir_ts, ff) for ff in os.listdir(fdir_ts) if ff.endswith('.csv')]
        #print('fpathlist_ts: ', fpathlist_ts)

        if(len(fpathlist_ts) > 0):
            x_ts, y_ts = loadDataSeq2(fpathlist_ts, features, seq_len, step, data_min, data_max)
            x_ts_list += x_ts 
            y_ts_list += y_ts 

    dataset_vl = SeqDataset3(np.asarray(x_vl_list), np.asarray(y_vl_list))
    dataset_ts = SeqDataset3(np.asarray(x_ts_list), np.asarray(y_ts_list))
    #print('length of dataset_vl: ', len(dataset_vl))
    #print('length of dataset_ts: ', len(dataset_ts))
    return data_tr_dict, dataset_vl, dataset_ts, data_min, data_max




