import paramiko
from scp import SCPClient
# class Client():
#     def __init__(self, ip, usr, pwd):
#         self.hostname = ip
#         self.username = usr
#         self.password = pwd
#         self.client = self._get_connect()
    
#     def _get_connect(self):
#         client = paramiko.SSHClient()
#         client.set_missing_host_key_policy(paramiko.AutoAddPolicy)
#         client.connect(hostname=self.hostname, username=self.username, password=self.password)
#         return client

#     def ssh_cmd(self,str,ifprint = 0):
#         ssh = self._get_connect()
#         stdin,stdout,stderr = ssh.exec_command(str)




def ssh_cmd(str,ifprint = 0,hostname = "192.168.100.6",port = 22,username = "xulei",password = "Ladiesman"):
#创建一个ssh的客户端，用来连接服务器
    ssh = paramiko.SSHClient()
    #创建一个ssh的白名单
    know_host = paramiko.AutoAddPolicy()
    #加载创建的白名单
    ssh.set_missing_host_key_policy(know_host)
    #连接服务器
    ssh.connect(
        hostname,
        port,
        username,
        password
    )
     
    #执行命令
    stdin,stdout,stderr = ssh.exec_command(str)
    stdout.channel.set_combine_stderr(True)
    output=stdout.readlines()
    #stdin  标准格式的输入，是一个写权限的文件对象
    #stdout 标准格式的输出，是一个读权限的文件对象
    #stderr 标准格式的错误，是一个写权限的文件对象
    if ifprint == True:
        # print(stdout.read().decode())
        print(output)
    ssh.close()

def ssh_put(put_file,target,hostname = "192.168.100.6",port = 22,name="xulei", passwd="Ladiesman"):
    # #上传下载文件
    # # 连接虚拟机centos上的ip及端口
    # transport = paramiko.Transport((hostname, port))
    # transport.connect(username=name, password=passwd)
    # # 将实例化的Transport作为参数传入SFTPClient中
    # sftp = paramiko.SFTPClient.from_transport(transport)
    # # 将“calculator.py”上传到filelist文件夹中
    # sftp.put(put_file,target)
    # transport.close()
    ssh = paramiko.SSHClient()
    #创建一个ssh的白名单
    know_host = paramiko.AutoAddPolicy()
    #加载创建的白名单
    ssh.set_missing_host_key_policy(know_host)
    #连接服务器
    ssh.connect(
        hostname,
        port,
        name,
        passwd
    )
    scp= SCPClient(ssh.get_transport())

    scp.put(put_file,target)
    ssh.close()

def ssh_del(file,hostname = "192.168.100.6",port = 22,name="xulei", passwd="Ladiesman"):
    ssh = paramiko.SSHClient()
    #创建一个ssh的白名单
    know_host = paramiko.AutoAddPolicy()
    #加载创建的白名单
    ssh.set_missing_host_key_policy(know_host)
    #连接服务器
    ssh.connect(
        hostname,
        port,
        name,
        passwd
    )
    sftp = ssh.open_sftp()
    sftp.remove(file)
    sftp.close()
    ssh.close()

def ssh_get(get_file,target,hostname = "192.168.100.6",port = 22,name="xulei", passwd="Ladiesman"):
    # #上传下载文件
    # # 连接虚拟机centos上的ip及端口
    # transport = paramiko.Transport((hostname, port))
    # transport.connect(username=name, password=passwd)
    # # 将实例化的Transport作为参数传入SFTPClient中
    # sftp = paramiko.SFTPClient.from_transport(transport)
    # # 将centos中的aaa.txt文件下载到桌面
    # sftp.get(get_file,target)
    # transport.close()
    ssh = paramiko.SSHClient()
    #创建一个ssh的白名单
    know_host = paramiko.AutoAddPolicy()
    #加载创建的白名单
    ssh.set_missing_host_key_policy(know_host)
    #连接服务器
    ssh.connect(
        hostname,
        port,
        name,
        passwd
    )
    scp= SCPClient(ssh.get_transport())
    scp.get(get_file,target)
    ssh.close()    

if __name__=="__main__":
    filepath="client0.csv"
    str_0="cd fisco;bash nodes/127.0.0.1/start_all.sh;"\
            "cd ~/fisco/swarm-app-main/dist;"\
            "bash swarm_run.sh renew /Users/xulei/Desktop/Jiang_FL/code_NorthDakota/code_NorthDakota/"+filepath+" 0"
    ssh_cmd(str_0)
    upfile,target1='C:/Users/iminx/Desktop/1.csv', '/Users/xulei/Desktop/1.csv'
    ssh_put(upfile,target1)
    getfile,target2='/Users/xulei/Desktop/test.txt', 'C:/Users/iminx/Desktop/test.txt'
    ssh_get(getfile,target2)


    