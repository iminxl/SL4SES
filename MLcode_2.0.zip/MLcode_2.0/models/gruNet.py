import torch
import torch.nn as nn
import torch.nn.functional as F

def get_gru(args):
    # build model
    input_dim = args.num_node_feature
    if(args.use_stra):
        input_dim += args.num_stra_feature
    
    model = GRUNet(input_dim, args.hidden_dim, args.n_class,
                     args.n_layers, args.batch_first,
                     args.bidirectional,
                     args.dropout)
    return model

class GRUNet(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, n_layers, batch_first, bidirectional, dropout):
        super(GRUNet, self).__init__()
        self.hidden_dim = hidden_dim
        self.n_layers = n_layers
        self.batch_first = batch_first
        self.bidirectional = bidirectional
        
        self.gru = nn.GRU(input_dim, hidden_dim, n_layers,
                         batch_first = batch_first,
                         bidirectional = bidirectional,
                         dropout = dropout)
        
        self.fc = nn.Linear(hidden_dim * 2 if bidirectional else hidden_dim, output_dim)
        
    def forward(self, x):
            batch_index = 0 if self.batch_first else 1
            
            h_0 = torch.zeros(self.n_layers * 2 if self.bidirectional else self.n_layers, x.size(batch_index), self.hidden_dim, dtype = x.dtype).to(x.device)
            
            output, h_n = self.gru(x, h_0)
            outputs = output.reshape(output.size(0) * output.size(1), output.size(2))
            
            label_space = self.fc(outputs)
            label_score = F.log_softmax(label_space, dim = 1)
            return label_score


def get_gru2(args):
    # build model
    input_dim = args.num_feature
    hidden_dim = args.gru_hid_dim 
    n_layers = args.n_layers
    output_dim = 1

    model = GRUNet2(input_dim, hidden_dim, n_layers, output_dim, args.dropout)

    return model


class GRUNet2(nn.Module):
    def __init__(self, input_dim, hidden_dim, n_layers, output_dim, dropout):
        super(GRUNet2, self).__init__()

        #self.hidden_dim = hidden_dim 
        #self.n_layers =  n_layers 
        
        #gru layers
        self.gru = nn.GRU(input_dim, hidden_dim, n_layers, batch_first = True, bidirectional = True, dropout = dropout)

        # fully connected layer
        self.fc = nn.Linear(hidden_dim * 2, output_dim)

    def forward(self, x):
        output, h_n = self.gru(x)

        outputs = output.reshape(output.size(0) * output.size(1), output.size(2))
            
        out = self.fc(outputs)
        return out
    
def get_gru3(args):
    # build model
    input_dim = args.num_feature
    hidden_dim = args.gru_hid_dim 
    n_layers = args.n_layers
    output_dim = 1

    model = GRUNet3(input_dim, hidden_dim, n_layers, output_dim, args.dropout)

    return model


class GRUNet3(nn.Module):
    def __init__(self, input_dim, hidden_dim, n_layers, output_dim, dropout):
        super(GRUNet3, self).__init__()

        #self.hidden_dim = hidden_dim 
        #self.n_layers =  n_layers 
        
        #gru layers
        self.gru = nn.GRU(input_dim, hidden_dim, n_layers, batch_first = True, bidirectional = False, dropout = dropout)

        # fully connected layer
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        output, h_n = self.gru(x)
        outputs = output[:,-1,:]
        # print("output tensor shape",output.shape)
        # outputs = output.reshape(output.size(0) * output.size(1), output.size(2))
            
        out = self.fc(outputs)
        return out