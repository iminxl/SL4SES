## 导入必要的库
import argparse
import torch
import numpy as np

def arr(model):
    
    parm={}
    parmlist=[]
    parmshp=[]
    parmlen=[]
    for name,parameters in model.items():
        # print(name,':',parameters.size())
        parm[name]=parameters.cpu().detach().numpy()
        parmshp.append(list(parameters.cpu().detach().numpy().shape))
        parmlen.extend(list(parameters.cpu().flatten().detach().numpy().shape))
        parmlist.extend(parameters.cpu().flatten().detach().numpy().tolist())
        parmarray=np.array(parmlist)
        n=8
        parmarray=np.around(parmarray*10**n)

    return parmarray,parmlen

def downloadparm(array,model,num,parmlen,precision,lam=1):
    
    parmarray2=array/10**precision
    flag=0
    counter=0
    lambda_=lam

    for name2, data in model.state_dict().items():

        # print('  ')
        # print(f'name: {name2}')
        # print(f'data: {data}')

        update_per_layer=parmarray2[counter:counter+parmlen[flag]]*lambda_
        counter+=parmlen[flag]
        flag+=1

        update_per_layer=torch.from_numpy(update_per_layer*num)
        update_per_layer=update_per_layer.reshape_as(data)
        # print(f'update_per_layer: {update_per_layer}')
        #print(dir(data))
        if data.type() != update_per_layer.type():
            data.copy_(update_per_layer.to(torch.float32))
        else:
            data.copy_(update_per_layer)
    return model

## 参数存入parm字典中，同时tensor类型变量转换成numpy array
def saveparm(model,filepath):
    
    parm={}
    parmlist=[]
    parmshp=[]
    parmlen=[]
    for name,parameters in model.items():
        # print(name,':',parameters.size())
        parm[name]=parameters.cpu().detach().numpy()
        parmshp.append(list(parameters.cpu().detach().numpy().shape))
        parmlen.extend(list(parameters.cpu().flatten().detach().numpy().shape))
        parmlist.extend(parameters.cpu().flatten().detach().numpy().tolist())
        parmarray=np.array(parmlist)
        n=8
        parmarray=np.around(parmarray*10**n)
    # print(f'parameter array: {parmarray}')
    # np.savetxt(filepath,parmarray,fmt="%i",delimiter=',')
    with open(filepath,'w') as f:
        for i in parmarray:
            f.write(str(int(i))+'\n')
            f.flush()
    return parmlen

#参数读取
def loadparm(filepath,model,num,parmlen,precision,lam=1):
    
    parmarray2=np.loadtxt(filepath)/10**precision
    flag=0
    counter=0
    lambda_=lam

    for name2, data in model.state_dict().items():

        # print('  ')
        # print(f'name: {name2}')
        # print(f'data: {data}')

        update_per_layer=parmarray2[counter:counter+parmlen[flag]]*lambda_
        counter+=parmlen[flag]
        flag+=1

        update_per_layer=torch.from_numpy(update_per_layer*num)
        update_per_layer=update_per_layer.reshape_as(data)
        # print(f'update_per_layer: {update_per_layer}')
        #print(dir(data))
        if data.type() != update_per_layer.type():
            data.copy_(update_per_layer.to(torch.float32))
        else:
            data.copy_(update_per_layer)
    return model


if __name__ == '__main__':
    from gruNet import get_gru2
    parser = argparse.ArgumentParser()

    parser.add_argument('--gru_hid_dim', type = int, default = 5)
    parser.add_argument('--num_feature', type = int, default = 3)
    parser.add_argument('--n_layers', type = int, default = 1)
    parser.add_argument('--dropout', type=float, default=0.)
    args = parser.parse_args()
    model = get_gru2(args)
    filepath="client1.csv"

    parmlen=saveparm(model.state_dict(),filepath)
    model=loadparm("array.txt",model,1,parmlen,8)
    print(model.state_dict())