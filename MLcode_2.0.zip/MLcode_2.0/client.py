from ckks.ckks_parameters import CKKSParameters
from ckks.ckks_key_generator_c import CKKSKeyGenerator_c
from ckks.ckks_encoder import CKKSEncoder
from ckks.ckks_encryptor import CKKSEncryptor
from ckks.ckks_evaluator import CKKSEvaluator
from ckks.ckks_decryptor_c import CKKSDecryptor_c

from util.public_key import PublicKey
from util.ciphertext import Ciphertext

import torch 
import copy 
from models.gruNet import get_gru2 
from utils.utils import build_optimizer 

import pandas as pd 
import numpy as np 
import os 

class Client(object):
    def __init__(self, args, id_ = -1, device = torch.device('cpu')):
        self.local_model = get_gru2(args).to(device)
        self.client_id = id_
        self.device = device 
        self.args = args 

    def local_train(self, lr, model, dataLoader, mu, std, n_total):
        for name, param in model.state_dict().items():
            self.local_model.state_dict()[name].copy_(param.clone())

        opt = torch.optim.Adam(self.local_model.parameters(), lr = lr, weight_decay = self.args.weight_decay)
        self.local_model.train()

        loss_a = []

        n_k = 0
        for e in range(self.args.local_epochs):
            train_loss = 0
            n_k = 0
            for batch_idx, (data, target) in enumerate(dataLoader):

                data = data.float().to(self.device)
                target = target.float().to(self.device)

                opt.zero_grad()
                y_output = self.local_model(data)

                target_ = target.view(len(y_output), -1)

                loss = torch.nn.functional.mse_loss(y_output, target_)
                loss.backward()
                opt.step()

                r1, r2, r3 = data.size()

                data_r = data.reshape(r1 * r2, r3)
                target_r = target.reshape(r1 * r2, -1)

                data_r_n = data_r.cpu().detach().numpy()
                target_r_n = target_r.cpu().detach().numpy()

                y_output_n = y_output.cpu().detach().numpy()

                data_xy = np.concatenate((data_r_n, target_r_n), axis = 1)

                data_xy_p = np.concatenate((data_r_n, y_output_n), axis = 1)
                
                #print('shape of data_xy: ', data_xy.shape)
                #print('shape of data_r_n: ', data_r_n.shape)
                #print('shape of target_r_n: ', target_r_n.shape)
                #print('shape of mu: ', mu.shape)
                #print('shape of std: ', std.shape)
                #data_xy_i = scaler.inverse_transform(data_xy)

                data_xy_i = data_xy * std + mu

                #data_xy_p_i = scaler.inverse_transform(data_xy_p)
                data_xy_p_i = data_xy_p * std + mu

                label_i = data_xy_i[:, 5]
                pred_i = data_xy_p_i[:, 5]

                loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_i), torch.tensor(label_i))
                train_loss += loss_i.item()

                n_k += r1 * r2
 

            loss_a.append(train_loss / len(dataLoader))  
        tp = n_k * 1.0/n_total
        #print('n_k: ', n_k)
        #print('n_total: ', n_total)
        #print('tp: ', tp)
        diff = dict()
        for name, data in self.local_model.state_dict().items():
            diff[name] = tp *(data - model.state_dict()[name])

        return diff, loss_a[-1]

class Client_t(object):
    def __init__(self, args, params, id_ = -1, p1 = None, device = torch.device('cpu')):
        self.local_model = get_gru2(args).to(device)   #checked
        self.client_id = id_   #checked
        self.device = device    #checked
        self.args = args    #checked
        self.params = params   #checked

        #generate secret key and public key

        key_generator = CKKSKeyGenerator_c(params, p1)   #checked
        self.public_key = key_generator.public_key   #checked
        self.secret_key = key_generator.secret_key   #checked
        self.encoder = CKKSEncoder(params)        #checked
        self.decryptor = CKKSDecryptor_c(params, self.secret_key) #checked   


    def update_public_key_p0(self, p0):  #checked
        #here p0 is the sum of p0 from all the clients
        p1 = self.public_key.p1
        self.public_key = PublicKey(p0, p1)

    def generateEncryptor(self):  #checked
        self.encryptor = CKKSEncryptor(self.params, self.public_key, self.secret_key)

    def encrypt(self, m): 
        plaintext = self.encoder.encode(m, self.params.scaling_factor)
        
        self.ciphertext = self.encryptor.encrypt(plaintext)

    def updateC1(self, c1):
        c0 = self.ciphertext.c0
        self.ciphertext =  Ciphertext(c0, c1, self.ciphertext.scaling_factor, self.ciphertext.modulus)
        
    def decrypt(self):
        decrypted = self.decryptor.decrypt_c(self.ciphertext)
        #return self.encoder.decode(decrypted)
        return decrypted

    def decode(self, decrypted):
        return self.encoder.decode(decrypted)


class Client_HE(object):
    def __init__(self, args, params, id_ = -1, p1 = None, device = torch.device('cpu')):
        self.local_model = get_gru2(args).to(device)   #checked
        self.client_id = id_   #checked
        self.device = device    #checked
        self.args = args    #checked
        self.params = params   #checked
        self.ln = params.poly_degree//2
        self.encryptedDiff = dict()

        #generate secret key and public key

        key_generator = CKKSKeyGenerator_c(params, p1)   #checked
        self.public_key = key_generator.public_key   #checked
        self.secret_key = key_generator.secret_key   #checked
        self.encoder = CKKSEncoder(params)        #checked
        self.decryptor = CKKSDecryptor_c(params, self.secret_key)   #checked


    def update_public_key_p0(self, p0):  #checked
        #here p0 is the sum of p0 from all the clients
        p1 = self.public_key.p1
        self.public_key = PublicKey(p0, p1)

    def generateEncryptor(self):  #checked
        self.encryptor = CKKSEncryptor(self.params, self.public_key, self.secret_key)

    def encrypt(self, m): #checked, return ciphertext 
        plaintext = self.encoder.encode(m, self.params.scaling_factor)
        
        return self.encryptor.encrypt(plaintext)

    def updateC1(self, sum_c1): #checked
        """
        sum_c1 is dictionary with the same keys as global_model.state_dict().items()
        """
        for name, params in sum_c1.items():
            ciphertext = self.encryptedDiff[name]
            self.encryptedDiff[name] = Ciphertext(ciphertext.c0, params, ciphertext.scaling_factor, ciphertext.modulus)


    def decrypt(self):
        decrypted = dict()
        for name, params in self.encryptedDiff.items():
            decrypted[name] = self.decryptor.decrypt_c(params)

        return decrypted

    def decode(self, decrypted):
        return self.encoder.decode(decrypted)


    def local_train(self, lr, model, dataLoader, mu, std, n_total):  #checked
        for name, param in model.state_dict().items():
            self.local_model.state_dict()[name].copy_(param.clone())

        opt = torch.optim.Adam(self.local_model.parameters(), lr = lr, weight_decay = self.args.weight_decay)
        self.local_model.train()

        loss_a = []

        n_k = 0
        for e in range(self.args.local_epochs):
            train_loss = 0
            n_k = 0
            for batch_idx, (data, target) in enumerate(dataLoader):

                data = data.float().to(self.device)
                target = target.float().to(self.device)

                opt.zero_grad()
                y_output = self.local_model(data)

                target_ = target.view(len(y_output), -1)

                loss = torch.nn.functional.mse_loss(y_output, target_)
                loss.backward()
                opt.step()

                r1, r2, r3 = data.size()

                data_r = data.reshape(r1 * r2, r3)
                target_r = target.reshape(r1 * r2, -1)

                data_r_n = data_r.cpu().detach().numpy()
                target_r_n = target_r.cpu().detach().numpy()

                y_output_n = y_output.cpu().detach().numpy()

                data_xy = np.concatenate((data_r_n, target_r_n), axis = 1)

                data_xy_p = np.concatenate((data_r_n, y_output_n), axis = 1)
                
                #print('shape of data_xy: ', data_xy.shape)
                #print('shape of data_r_n: ', data_r_n.shape)
                #print('shape of target_r_n: ', target_r_n.shape)
                #print('shape of mu: ', mu.shape)
                #print('shape of std: ', std.shape)
                #data_xy_i = scaler.inverse_transform(data_xy)

                data_xy_i = data_xy * std + mu

                #data_xy_p_i = scaler.inverse_transform(data_xy_p)
                data_xy_p_i = data_xy_p * std + mu

                label_i = data_xy_i[:, 5]
                pred_i = data_xy_p_i[:, 5]

                loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_i), torch.tensor(label_i))
                train_loss += loss_i.item()

                n_k += r1 * r2
 
            loss_a.append(train_loss / len(dataLoader))  
        tp = n_k * 1.0/n_total
        #print('n_k: ', n_k)
        #print('n_total: ', n_total)
        #print('tp: ', tp)
        self.encryptedDiff = dict()
        for name, data in self.local_model.state_dict().items():
            data_t = tp *(data - model.state_dict()[name])
            
            #convert 2D torch tensor to 1D torch tensor
            data_r = data_t.reshape(-1,)
            #print(' ')
            #print(' ')
            #print(f'length of ln: {self.ln}')
            #print(f'length of data_r: {len(data_r)}')

            #convert torch tensor to list
            data_list = data_r.tolist()
            print(' ')
            print(f'name: {name}')
            print(f'data_list: {data_list}')
            
            #extend the length of data_list to poly_degree //2
            data_list = data_list + (self.ln- len(data_list))*[0]

            #print(f'length of data_list after packing 0s: {len(data_list)}')
            #print(f'data_list: {data_list}')
            self.encryptedDiff[name] = self.encrypt(data_list)

        return self.encryptedDiff, loss_a[-1]

