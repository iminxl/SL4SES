"""A module to generate public and private keys for the CKKS scheme."""

from util.polynomial import Polynomial
from util.public_key import PublicKey
#from util.rotation_key import RotationKey
from util.secret_key import SecretKey
from util.random_sample import sample_triangle, sample_uniform, sample_hamming_weight_vector

class CKKSKeyGenerator_c:

    """An instance to generate a public/secret key pair and relinearization keys.

    The secret key s is generated randomly, and the public key is the
    pair (-as + e, a). The relinearization keys are generated, as
    specified in the CKKS paper.

    Attributes:
        params (Parameters): Parameters including polynomial degree, plaintext,
            and ciphertext modulus.
        secret_key (Polynomial): secret key randomly generated from R_q.
        public_key (tuple of Polynomials): public key generated from
            secret key.
        relin_key (tuple of Polynomials): relinearization key generated
            from secret key.
    """

    def __init__(self, params, p1 = None):
        """Generates secret/public key pair for CKKS scheme.

        Args:
            params (Parameters): Parameters including polynomial degree,
                plaintext, and ciphertext modulus.
            p1: second element of a public key
        """
        self.params = params
        self.secret_key = self.generate_secret_key()
        #print(f'after generating secret_key...')

        if p1 is None:
            p1 = self.generate_public_key_p1()
            #print(f'after generating p1....')

        p0 = self.generate_public_key_p0(p1)
        #print(f'after generating p0')
        
        self.public_key = PublicKey(p0, p1)

    def update_public_key_p0(self, p0):
        """
        replace p0 with a new p0
        """
        p1 = self.public_key.p1
        self.public_key = PublicKey(p0, p1)

    def generate_secret_key(self):
        """Generates a secret key for CKKS scheme.
        """
        key = sample_hamming_weight_vector(self.params.poly_degree, self.params.hamming_weight)
        #self.secret_key = SecretKey(Polynomial(self.params.poly_degree, key))
        return SecretKey(Polynomial(self.params.poly_degree, key))

    def generate_public_key_p1(self):
        """
        Generate p1 (public key) for CKKS scheme
        """
        mod = self.params.big_modulus

        return Polynomial(self.params.poly_degree, sample_uniform(0, mod, self.params.poly_degree))

    def generate_public_key_p0(self, p1):
        """
        Generate p0 given p1
        """

        mod = self.params.big_modulus
        #print(f'mod: {mod}')
        #print(f'secret_key: {self.secret_key.s}')

        pk_error = Polynomial(self.params.poly_degree, sample_triangle(self.params.poly_degree))
        #print(f'pk_error: {pk_error}')
        p0 = p1.multiply(self.secret_key.s, mod)
        #print(f'p0: {p0}')
        p0 = p0.scalar_multiply(-1, mod)
        p0 = p0.add(pk_error, mod)
        #print(f'p0: {p0}')
        return p0


    def generate_public_key(self):
        """Generates a public key for CKKS scheme.

        Args:
            params (Parameters): Parameters including polynomial degree,
                plaintext, and ciphertext modulus.
        """
        mod = self.params.big_modulus

        pk_coeff = Polynomial(self.params.poly_degree, sample_uniform(0, mod, self.params.poly_degree))
        pk_error = Polynomial(self.params.poly_degree, sample_triangle(self.params.poly_degree))
        p0 = pk_coeff.multiply(self.secret_key.s, mod)
        p0 = p0.scalar_multiply(-1, mod)
        p0 = p0.add(pk_error, mod)
        p1 = pk_coeff
        self.public_key = PublicKey(p0, p1)



