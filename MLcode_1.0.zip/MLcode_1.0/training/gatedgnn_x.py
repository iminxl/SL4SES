import os
import numpy as np
import pandas as pd

import torch
import torch.nn.functional as F

from models.gatedgnn_model import get_gatedgnn
from utils.plot_utils import plot_curve, plot_sample
from utils.utils import build_optimizer

def train_gatedgnn_cv_x(args, trainLoader, valLoader, log_path, scaler, device = torch.device('cpu')):
    #model_log_path = os.path.join(log_path, 'model')
    #if not os.path.exists(model_log_path):
    #    os.makedirs(model_log_path)

    model = get_gatedgnn(args, device).to(device)

    trainable_parameters = list(model.parameters())

    scheduler, opt = build_optimizer(args, trainable_parameters)

    Train_loss = []
    Evaluate_loss = []
    Lr = []

    for epoch in range(args.epochs):
        train_loss = train(args, trainLoader, model, opt, scaler, device)
        
        eval_loss = evaluate(args, valLoader, model, scaler, device)

        Train_loss.append(train_loss)
        Evaluate_loss.append(eval_loss)

        if scheduler is not None:
            scheduler.step()
        for param_group in opt.param_groups:
            Lr.append(param_group['lr'])

        #model_name = '_'.join(['model', str(epoch), '.ckpt'])
        #torch.save(model.state_dict(), os.path.join(model_log_path, model_name))

        print('epoch: {}, train_loss: {:7.4f}, eval_loss: {:7.4f}'.format(epoch, train_loss, eval_loss))

    obj= dict()
    obj['args'] = args
    obj['curves'] = dict()
    obj['curves']['train_loss'] = Train_loss
    obj['curves']['eval_loss'] = Evaluate_loss
    obj['lr'] = Lr

    plot_curve(obj['curves'], log_path + 'curves.png', keys = None, 
                clip = True, label_min = False, label_end = False)
    plot_curve(obj, log_path + 'lr.png',keys = ['lr'], 
                clip = False, label_min = False, label_end = False)

    df_out = dict()
    df_out['train_loss'] = Train_loss

    df_out['eval_loss'] = Evaluate_loss

    df = pd.DataFrame.from_dict(df_out, orient = 'index').transpose()
    df.to_csv(os.path.join(log_path, 'result.csv'))

def train_gatedgnn_x(args, trainLoader, log_path, device = torch.device('cpu')):
    model_log_path = os.path.join(log_path, 'model')
    if not os.path.exists(model_log_path):
        os.makedirs(model_log_path)

    model = get_gatedgnn(args, device).to(device)

    trainable_parameters = list(model.parameters())

    scheduler, opt = build_optimizer(args, trainable_parameters)

    Train_loss = []
    Lr = []

    for epoch in range(args.epochs):
        train_loss = train(args, trainLoader, model, opt, device)
        
        Train_loss.append(train_loss)

        if scheduler is not None:
            scheduler.step()
        for param_group in opt.param_groups:
            Lr.append(param_group['lr'])

        model_name = '_'.join(['model', str(epoch), '.ckpt'])
        torch.save(model.state_dict(), os.path.join(model_log_path, model_name))

    df_out = dict()
    df_out['train_loss'] = Train_loss

    df = pd.DataFrame.from_dict(df_out, orient = 'index').transpose()
    df.to_csv(os.path.join(log_path, 'result.csv'))

def testing_gatedgnn_x(args, testLoader, log_path, model_path, device = torch.device('cpu')):
    model = get_gatedgnn(args, device).to(device)
    modelName = '_'.join(['model', str(args.epoch), '.ckpt'])
    modelPath = os.path.join(model_path, modelName)
    model.load_state_dict(torch.load(modelPath))

    eval_loss = evaluate(args, testLoader, model, device)

    Evaluate_loss = []

    Evaluate_loss.append(eval_loss)

    df_out = dict()
    df_out['test_loss'] = Evaluate_loss

    df = pd.DataFrame.from_dict(df_out, orient = 'index').transpose()
    df.to_csv(os.path.join(log_path, 'result.csv'))

def prediction_curve(args, dataLoader, log_path, model_path, scaler, feature_index, device = torch.device('cpu')):
    model = get_gatedgnn(args, device).to(device)
    modelName = '_'.join(['model', str(args.epoch), '.ckpt'])
    modelPath = os.path.join(model_path, modelName)
    model.load_state_dict(torch.load(modelPath))

    eval_loss = 0
    model.eval()
    output_list = []
    data_list = []
    mask_vl_list = []
    count = 0

    with torch.no_grad():
        for batch_idx, (data, _, _, data_copy, mask_tr, mask_vl) in enumerate(dataLoader):
            data = data.float().to(device)
            mask_tr = mask_tr.bool().to(device)
            mask_vl = mask_vl.bool().to(device)

            x_output = model(data, mask_tr)
            r1, r2, r3 = x_output.size()
            x_output_r = x_output.reshape(r1 * r2, r3)
            output_list.append(x_output_r)

            c1, c2, c3 = data_copy.size()
            data_copy_r = data_copy.reshape(c1 * c2, c3)
            data_list.append(data_copy_r)

            #print('size of mask_vl: ', mask_vl.size())
            a1, a2, a3 = mask_vl.size()
            mask_vl_r = mask_vl.reshape(a1 * a2, a3)
            mask_vl_list.append(mask_vl_r)


            eval_pred = x_output[mask_vl]
            eval_label = data[mask_vl]

            """
            print('data_copy.size(): ', data_copy.size())
            print('x_output.size(): ', x_output.size())
            print('eval_pred.size(): ',eval_pred.size())
            print('eval_label.size(): ', eval_label.size())
            [batch_size, seq_len, n_feature]
            """
            

            loss = F.mse_loss(eval_pred, eval_label)

            if ~torch.isnan(loss).any():
                eval_loss += loss.item()
                count +=1
    
    Evaluate_loss = []

    Evaluate_loss.append(eval_loss / count)

    df_out = dict()
    df_out['test_loss'] = Evaluate_loss

    df = pd.DataFrame.from_dict(df_out, orient = 'index').transpose()
    df.to_csv(os.path.join(log_path, 'result.csv'))

    #print('length of data_list: ', len(data_list))
    
    data_stacked = data_list[-1]
    if(len(data_list) > 1):
        data_tmp = torch.stack(data_list[0: -1])
        c1 , c2, c3 = data_tmp.size()
        data_tmp_r = data_tmp.reshape(c1 * c2, c3)
        data_stacked = torch.vstack((data_tmp_r, data_stacked))
    """
    data_stacked = torch.stack(data_list)

    c1, c2, c3 = data_stacked.size()
    data_stacked_r = data_stacked.reshape(c1 * c2, c3)
    """

    """
    columns in data_stacked_r is 
    columns = ['DEPT(m)','GR(gAPI)', 'GR_scaled','SP_scaled', 'PEF(b/e)',
               'NPHI(m3/m3)','DPHI(m3/m3)', 'RHOB(g/cm3)', 'DTC(us/ft)',
               'DTS(us/ft)', 'log10RDEP', 'log10RMED', 'log10RSHA']
    """

    output_stacked = output_list[-1]
    if(len(output_list) > 1):
        output_tmp = torch.stack(output_list[0: -1])
        r1, r2, r3 = output_tmp.size()
        output_tmp_r = output_tmp.reshape(r1 * r2, r3)
        output_stacked = torch.vstack((output_tmp_r, output_stacked))
        
    """
    output_stacked = torch.stack(output_list)
    r1, r2, r3 = output_stacked.size()
    output_stacked_r = output_stacked.reshape(r1 * r2, r3)
    """

    #print('data_stacked_r.size(): ', data_stacked_r.size())
    #print('output_stacked_r.size(): ', output_stacked_r.size())
    #data_stacked_r.size():  torch.Size([8787, 13])
    #output_stacked_r.size():  torch.Size([8787, 12])
    
    output_inversed = scaler.inverse_transform(output_stacked)

    mask_vl_stacked = mask_vl_list[-1]
    if(len(mask_vl_list) > 1):
        mask_vl_tmp = torch.stack(mask_vl_list[0: -1])
        a1, a2, a3 = mask_vl_tmp.size()
        mask_vl_tmp_r = mask_vl_tmp.reshape(a1 * a2, a3)
        mask_vl_stacked = torch.vstack((mask_vl_tmp_r, mask_vl_stacked))
    
    output_inversed_t = torch.tensor(output_inversed)
    output_inversed_t[~mask_vl_stacked] = np.nan
    ####

    
    #print('type of output_inversed: ', type(output_inversed))
    # type of output_inversed is <class 'numpy.ndarray'>
    #print('output_inversed.shape: ', output_inversed.shape)
    # output_inversed.shape:  (8787, 12)
    """
    columns for output_inversed is 
    ['GR(gAPI)', 'GR_scaled','SP_scaled', 'PEF(b/e)',
               'NPHI(m3/m3)','DPHI(m3/m3)', 'RHOB(g/cm3)', 'DTC(us/ft)',
               'DTS(us/ft)', 'log10RDEP', 'log10RMED', 'log10RSHA']
    """
    
    r1, _ = data_stacked.size()
    columns_ = ['DEPT(m)', 'DTS', 'DTS_p']
    data_new = np.zeros((r1, 3), dtype = float)
    data_new[:, 0] = data_stacked[:, 0].cpu().detach().numpy()
    data_new[:, 1] = data_stacked[:, 5].cpu().detach().numpy()
    data_new[:, 2] = output_inversed_t[:, 4].cpu().detach().numpy()

    df_predicted = pd.DataFrame(data_new, columns = columns_)
    df_predicted_sorted = df_predicted.sort_values(by = ['DEPT(m)'])
    df_predicted_sorted.to_csv(os.path.join(log_path, 'curves.csv'))

def train(args, dataLoader, model, opt, scaler, device):
    model.train()

    train_loss = 0

    for batch_idx, (data, mask_tr, mask_vl) in enumerate(dataLoader):
        data = data.float().to(device)
        mask_tr = mask_tr.bool().to(device)
        mask_vl = mask_vl.bool().to(device)

        opt.zero_grad()
        x_output = model(data, mask_tr)

        #x1 = torch.sum(mask_tr).item()
        #x2 = torch.sum(mask_vl).item()
        #print('number of true values in mask_tr: ', x1)
        #print('number of true values in mask_vl: ', x2)
        # number of true values in mask_tr:  95842, tr_rate: 0.8
        # number of true values in mask_tr:  89720, tr_rate: 0.75

        # number of true values in mask_tr:  83656, tr_rate: 0.7
        # number of true values in mask_vl:  24098

        # number of true values in mask_tr:  77598, tr_rate: 0.65
        # number of true values in mask_vl:  24098

        #number of true values in mask_tr:  71549, tr_rate: 0.6
        # number of true values in mask_vl:  24098

        # number of true values in mask_tr:  65581, tr_rate: 0.55
        # number of true values in mask_vl:  24098

        #print('size of x_output: ', x_output.size())
        
        # size of x_output:  torch.Size([128, 101, 12])
        #size of x_output: [batch_size, seq_len, n_features]

        #print('size of mask_tr: ', mask_tr.size())
        #print('size of mask_vl: ', mask_vl.size())

        # size of mask_tr:  torch.Size([128, 101, 12])
        # size of mask_vl:  torch.Size([128, 101, 12])

        train_pred = x_output[mask_vl]
        train_label = data[mask_vl]
        #print('size of train_pred: ', train_pred.size())
        #print('size of train_label: ', train_label.size())

        # size of train_pred:  torch.Size([24098])
        # size of train_label:  torch.Size([24098])

        loss = torch.nn.functional.mse_loss(train_pred, train_label)
        loss.backward()
        opt.step()

        
        r1, r2, r3 = x_output.size()
        x_output_r = x_output.reshape(r1 * r2, r3)

        data_r = data.reshape(r1 * r2, r3)
        
        x_output_i = scaler.inverse_transform(x_output_r.cpu().detach().numpy())

        data_i = scaler.inverse_transform(data_r.cpu().detach().numpy())
        
        #print('shape of x_output_i: ', x_output_i.shape)
        #print('shape of data_i: ', data_i.shape)
                
        mask_vl_r = mask_vl.reshape(r1 * r2, r3)


        train_pred_i = x_output_i[mask_vl_r]
        train_label_i = data_i[mask_vl_r]     

        #print('type of train_pred_i: ', type(train_pred_i))
        #print('type of train_label_i: ', type(train_label_i))

        loss_i = torch.nn.functional.mse_loss(torch.tensor(train_pred_i), torch.tensor(train_label_i))

        train_loss += loss_i.item()
    
    return train_loss / len(dataLoader)

def evaluate(args, dataLoader, model, scaler, device):
    model.eval()
    eval_loss = 0
    count = 0

    with torch.no_grad():
        for batch_idx, (data, mask_tr, mask_vl) in enumerate(dataLoader):
            data = data.float().to(device)
            mask_tr = mask_tr.bool().to(device)
            mask_vl = mask_vl.bool().to(device)

            x_output = model(data, mask_tr)

            eval_pred = x_output[mask_vl]
            eval_label = data[mask_vl]

            #loss = torch.nn.functional.mse_loss(eval_pred, eval_label)
            #eval_loss += loss.item()

            
            r1, r2, r3 = x_output.size()
            x_output_r = x_output.reshape(r1 * r2, r3)
            
            data_r = data.reshape(r1 * r2, r3)
            
            x_output_i = scaler.inverse_transform(x_output_r.cpu().detach().numpy())
            
            data_i = scaler.inverse_transform(data_r.cpu().detach().numpy())
            
            #print('shape of x_output_i: ', x_output_i.shape)
            #print('shape of data_i: ', data_i.shape)
            
            mask_vl_r = mask_vl.reshape(r1 * r2, r3)
            
            eval_pred_i = x_output_i[mask_vl_r]
            eval_label_i = data_i[mask_vl_r]     

            #print('type of train_pred_i: ', type(train_pred_i))
            #print('type of train_label_i: ', type(train_label_i))

            loss_i = torch.nn.functional.mse_loss(torch.tensor(eval_pred_i), torch.tensor(eval_label_i))
            eval_loss += loss_i.item()


    return eval_loss / len(dataLoader)


