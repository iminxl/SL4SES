import torch 
import copy 
from models.gruNet import get_gru2, get_gru3
from models.transformer import get_transformer2
from utils.utils import build_optimizer 

import pandas as pd 
import numpy as np 
import os 

class Client(object):
    def __init__(self, args, id_ = -1, device = torch.device('cpu')):

        if args.model == "Transformer":
            self.local_model = get_transformer2(args).to(device)
        elif args.model == "grusw":
            self.local_model = get_gru3(args).to(device)
        self.client_id = id_
        self.device = device 
        self.args = args 

    def local_train(self, lr, model, dataLoader, mu, std, n_total):
        #print(' ')
        #print(' ')
        #print(' ')
        #print('###############local_train################')
        for name, param in model.state_dict().items():
            self.local_model.state_dict()[name].copy_(param.clone())
            #print(f'name: {name}')
            #print(f'param: {param}')

        opt = torch.optim.Adam(self.local_model.parameters(), lr = lr, weight_decay = self.args.weight_decay)
        self.local_model.train()

        loss_a = []

        n_k = 0
        for e in range(self.args.local_epochs):
            train_loss = 0
            n_k = 0
            for batch_idx, (data, target) in enumerate(dataLoader):

                data = data.float().to(self.device)
                # print(f'input shape:{data.shape}')
                # print(f'target shape:{target.shape}')
                target = target.float().to(self.device)

                opt.zero_grad()
                y_output = self.local_model(data)
                y_output = y_output.reshape(-1,24,1)
                y_output = y_output[:,-self.args.predict_len:, :].reshape(-1,1)
                                # print(f'output shape:{y_output.shape,len(y_output)}')
                target_ = target.view(len(y_output), -1)

                loss = torch.nn.functional.mse_loss(y_output, target_)
                loss.backward()
                opt.step()

                r1, r2, r3 = data.size()
                if target.dim() == 3:
                    r11,r22,r33 = target.size()
                elif target.dim() == 2:
                    r11,r22 = target.size()
                data_r = data[:,-r22:,:].reshape(r1 * r22, r3)
                target_r = target.reshape(r11 * r22, -1)
                y_output = y_output.reshape(r11 * r22, -1)

                data_r_n = data_r.cpu().detach().numpy()
                target_r_n = target_r.cpu().detach().numpy()
                y_output_n = y_output.cpu().detach().numpy()

                data_xy = np.concatenate((data_r_n, target_r_n), axis = 1)

                data_xy_p = np.concatenate((data_r_n, y_output_n), axis = 1)
                
                #print('shape of data_xy: ', data_xy.shape)
                #print('shape of data_r_n: ', data_r_n.shape)
                #print('shape of target_r_n: ', target_r_n.shape)
                #print('shape of mu: ', mu.shape)
                #print('shape of std: ', std.shape)
                #data_xy_i = scaler.inverse_transform(data_xy)

                data_xy_i = data_xy * std + mu

                #data_xy_p_i = scaler.inverse_transform(data_xy_p)
                data_xy_p_i = data_xy_p * std + mu

                label_i = data_xy_i[:, self.args.num_feature]
                pred_i = data_xy_p_i[:, self.args.num_feature]

                loss_i = torch.nn.functional.mse_loss(torch.tensor(pred_i), torch.tensor(label_i))
                train_loss += loss_i.item()

                n_k += r11 * r2
 
            loss_a.append(train_loss / len(dataLoader))  
        tp = n_k * 1.0/n_total
        #print('n_k: ', n_k)
        #print('n_total: ', n_total)
        # print('tp: ', tp)
        diff = dict()
        for name, data in self.local_model.state_dict().items():
            #diff[name] = tp *(data - model.state_dict()[name])
            diff[name] = tp * data
            #print(' ')
            #print(f'name: {name}')
            #print(f'data_t: {diff[name]}')
            

        return diff, loss_a[-1]