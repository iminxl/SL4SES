#example of CKKS multiplication

from ckks.ckks_decryptor import CKKSDecryptor
from ckks.ckks_encoder import CKKSEncoder
from ckks.ckks_encryptor import CKKSEncryptor 
from ckks.ckks_evaluator import CKKSEvaluator 
from ckks.ckks_key_generator_c import CKKSKeyGenerator_c 
from ckks.ckks_parameters import CKKSParameters 

def main():
    #poly_degree = 8
    poly_degree = 8  # should be the vector length *2, also it should be the power of 2. for example, if we want to encrypt [0.1, 0.1, 0.1, 0.1]
    #ciph_modulus = 2**600
    ciph_modulus = 1 << 600

    #big_modulus = 2**1200
    big_modulus = 1 << 600

    #scaling_factor = 2**30
    scaling_factor = 1 << 30
    print('  ++++++++++++++++++++++++++++++++++++ ')

    params = CKKSParameters(poly_degree = poly_degree,
                            ciph_modulus = ciph_modulus,
                            big_modulus = big_modulus,
                            scaling_factor = scaling_factor)

    print('  hahaha    ')

    key_generator = CKKSKeyGenerator_c(params, None)
    public_key = key_generator.public_key
    secret_key = key_generator.secret_key

    print(f'type of public_key: {type(public_key)}')
    print(f'type of secret_key: {type(secret_key)}')
    p0 = public_key.p0
    p1 = public_key.p1
    s = secret_key.s

    print(f'type of p0: {type(p0)}')
    print(f'type of p1: {type(p1)}')

    print('=========================================')
    encoder = CKKSEncoder(params)
    encryptor = CKKSEncryptor(params, public_key, secret_key)
    decryptor = CKKSDecryptor(params, secret_key)
    evaluator = CKKSEvaluator(params)

    #message1 = [0.5, 0.3, 0.8]
    #message2 = [0.2, 0.1, 0.4]
    message1 = 4 * [0.8]
    message2 = 4 * [0.2]
    plain1 = encoder.encode(message1, scaling_factor)
    plain2 = encoder.encode(message2, scaling_factor)

    poly1 = plain1.poly
    poly2 = plain2.poly

    ciph1 = encryptor.encrypt(plain1)
    ciph2 = encryptor.encrypt(plain2)

    #print(f'type of plain1: {type(plain1)}')
    #print(f'type of poly1: {type(poly1)}')
    #print(poly1)
    #print(poly2)

    ciph_add = evaluator.add(ciph1, ciph2)
    ciph_sub = evaluator.subtract(ciph1, ciph2)
    #ciph_mulplain = evaluator.multiply_plain(ciph1, 5)

    decrypted_add = decryptor.decrypt(ciph_add)
    decrypted_sub = decryptor.decrypt(ciph_sub)
    #decrypted_mulplain = decryptor.decrypt(ciph_mulplain)
    print(f'decrypted_add: {encoder.decode(decrypted_add)}')
    print(f'decrypted_sub: {encoder.decode(decrypted_sub)}')
    #print(f'decrypted_mulplain: {decrypted_mulplain}')

if __name__ == '__main__':
    main()