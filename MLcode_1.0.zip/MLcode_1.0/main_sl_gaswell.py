import time 
import argparse 
import os 
os.environ['CUBLAS_WORKSPACE_CONFIG']=':16:8'
import numpy as  np 
import torch 
torch.use_deterministic_algorithms(True) 
import pandas as pd 
import random 
from concurrent.futures import ThreadPoolExecutor
# import threading
# import matplotlib.pyplot as plt

from utils.dataReading_gaswell import getDataset_sl_full,getRank,evaluate
from models.model_output import loadparm,downloadparm,arr
from utils.ssh_tool import ssh_cmd,ssh_get,ssh_put
from client_gaswell import Client
from utils.plot_utils import plot_curve
from models.gruNet import get_gru3

def main():
    # T1=time.perf_counter()
    # args
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type = str, default = 'grusw')
    parser.add_argument('--gru_hid_dim', type = int, default = 20)
    parser.add_argument('--n_layers', type = int, default = 1)
    parser.add_argument('--opt', type = str, default = 'adam')
    parser.add_argument('--opt_scheduler', type=str, default='step')
    parser.add_argument('--opt_restart', type=int, default=0)
    parser.add_argument('--opt_decay_step', type=int, default=2000)
    parser.add_argument('--opt_decay_rate', type=float, default=0.9)
    parser.add_argument('--dropout', type=float, default=0.)
    parser.add_argument('--weight_decay', type=float, default=0.)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--momentum', type = float, default = 0.9)
    parser.add_argument('--seed', type=int, default=0)    
    parser.add_argument('--dataPath', type = str, default = '../data_gaswell/PG')
    parser.add_argument('--logPath', type = str, default = '../log_gaswell/validation/sl')
    parser.add_argument('--logPath_ts', type = str, default = '../log_gaswell/testing/sl')
    
    parser.add_argument('--length', type = int, default = 7)
    parser.add_argument('--step', type = int, default = 1)
    parser.add_argument('--feature', type=str, default='TP,Mpa;CP,Mpa;DW,m3perd;PT,h;normal production;DHG,104m3perd')
    parser.add_argument('--dataset_features', type=str, default='TP,Mpa;CP,Mpa;PT,h;normal production;diff_DWperday;diff_DHGperday')
    parser.add_argument('--dataframes', type = int, default = 24)
    parser.add_argument('--testout_num', type = int, default = 4)
    parser.add_argument('--num_feature', type = int, default = 6)
    parser.add_argument('--winsize',type = float, default = 1)
    parser.add_argument('--batch_size', type = int, default = 256)
    parser.add_argument('--lambda_',type = float, default = 1)

    parser.add_argument('--no_models', type = int, default = 20)
    parser.add_argument('--k', type = int, default = 0)
    parser.add_argument('--locframe_num', type = int, default = 1)
    parser.add_argument('--fold_id', type = int, default = 0)

    parser.add_argument('--crit',type = float, default = 0.5)
    parser.add_argument('--local_epochs', type = int, default = 1)
    parser.add_argument('--global_epochs', type = int, default = 100)

    args = parser.parse_args()

    #select device
    if torch.cuda.is_available():
        device = torch.device('cuda')
    else:
        device = torch.device('cpu')

    seed = args.seed 
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # feature and dataloader
    features = args.feature.split(";")
    dataset_features = args.dataset_features.split(";")

    nodein_list,testout_list = getRank(args.dataframes,args.testout_num,args.fold_id,args.no_models,args.locframe_num)

    data_tr_dict,data_tr,data_vl,data_ts_in_dict,data_ts_out_dict,n_total = getDataset_sl_full(args.dataPath, nodein_list, testout_list, args.no_models, args.locframe_num, features, dataset_features, args.length, args.step, args.winsize)
    #print(f'type of data_tr_dict: {data_tr_dict}')

    trainDataLoader_dict = {}
    for name, param in data_tr_dict.items():
        trainDataLoader_dict[name] = torch.utils.data.DataLoader(param, batch_size = args.batch_size, shuffle = False)
    
    trainDataLoader = torch.utils.data.DataLoader(data_tr, batch_size = args.batch_size, shuffle = False)

    evalDataLoader = torch.utils.data.DataLoader(data_vl, batch_size = args.batch_size, shuffle = False)
    
    testinDataLoader_dict = {}
    for name, param in data_ts_in_dict.items():
        testinDataLoader_dict[name] = torch.utils.data.DataLoader(param, batch_size = args.batch_size, shuffle = False)

    testoutDataLoader_dict = {}
    for name, param in data_ts_out_dict.items():
        testoutDataLoader_dict[name] = torch.utils.data.DataLoader(param, batch_size = args.batch_size, shuffle = False)

    #log&model path
    str_lr = '_'.join(['lr', str(args.lr)])
    str_seed = '_'.join(['seed', str(args.seed)])

    log_path = args.logPath + '/{}/{}/{}clients/{}frames/fold_{}/'.format(str_lr, str_seed, args.no_models, args.locframe_num, args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    model_path = log_path + '/model'
    if not os.path.exists(model_path):
        os.makedirs(model_path)
    
    # args record -> log path
    args_dict = vars(args)
    with open(os.path.join(log_path, 'args.txt'), 'w') as f:
        for key, value in args_dict.items():
            f.write('{}:{}'.format(key, value))
            f.write('\n')
    
    #create server and clients
    global_model=get_gru3(args)

    parmlist = []
    for name,parameters in global_model.state_dict().items():

        parmlist.extend(parameters.cpu().flatten().detach().numpy().tolist())
        parmarray=np.array(parmlist)
    L=len(parmarray)
    clients = []
    time_array=np.zeros(args.no_models+1)
    for c in range(args.no_models):
        clients.append(Client(args, c, device))
    
    Train_loss = []
    Eval_loss = []
    epoch_ = []
    lr_ = []
    lr = args.lr
    
    command_start="cd fisco;bash nodes/127.0.0.1/start_all.sh;"
    command_0 = "cd ~/fisco/swarm-app-main/dist;"
    command_deploy = "bash swarm_run.sh deploy {} /Users/xulei/Desktop/java_io/name.txt;".format(L)
    ssh_cmd(command_start,1)
    ssh_cmd(command_0+command_deploy,1)
    command_merge="bash swarm_run.sh merge;"
    mgd_file="array.txt"
    getfile,tar2="/Users/xulei/Desktop/java_io/"+mgd_file,\
            'C:/Users/iminx/Desktop/sl_sm/code/'+mgd_file
    # global loop
    T1=time.perf_counter()
    for e in range(args.global_epochs):

        # ssh_put('./0.txt',getfile)
        if args.k ==0:
            candidates=clients
        else:
            candidates = random.sample(clients, args.k)
            candidates = sorted(candidates,key=(lambda x:x.client_id))
        total_loss = 0.0

        par_arr_accumulator = np.zeros_like(parmarray)

        pool=ThreadPoolExecutor(max_workers=args.no_models)

        # local loop需要分别计时
        work=[0]*args.no_models
        for c in candidates:
            work[c.client_id]=pool.submit(local_train,c,seed,lr,global_model,trainDataLoader_dict,n_total)
            # exec("work"+str(c.client_id)+"=pool.submit(local_train,c,seed,lr,server,trainDataLoader_dict,mu,std,n_total)")
            
        pool.shutdown()

        # parmlen=work[0].result()[3]
        for i_ in range(args.no_models):
            time_array[i_]+=work[i_].result()[0]
            # exec("time_array[i_]+=work"+str(i_)+".result()[0]")
            
            # ctime=time.perf_counter()
            # id_ = c.client_id
            # #print(' ')
            # #print(' ')
            # #print(f'id_: {id_}') 
            
            # random.seed(seed)
            # np.random.seed(seed)
            # torch.manual_seed(seed)
            # diff, loss_a = c.local_train(lr, server.global_model, trainDataLoader_dict[id_], mu, std, n_total)
            loc_diff=work[i_].result()[1]
            loc_par_arr,parmlen=arr(loc_diff)
            par_arr_accumulator+=loc_par_arr
            total_loss+=work[i_].result()[2]
            # exec("total_loss=work"+str(i_)+".result()[2]",globals())
            #weight  select

        # aggregate and evaluate需要通讯计时
        stime=time.perf_counter()
        par_arr_accumulator/=args.no_models
        agg_par_arr = np.floor(par_arr_accumulator)
        ssh_cmd(command_0+command_merge)

        # #写while，先拿过来，判断长度，长度不等sleep 1s
        # Flag = 0
        # while Flag == 0:
        #     ssh_get(getfile,tar2)
        #     arr=np.loadtxt(tar2)
        #     if arr.size==L:
        #         Flag = 1
        #     else:
        #         print(arr.size/L)
        #         time.sleep(1)

        ssh_get(getfile,tar2)
        # #sshdelete array.txt
        # ssh_del(getfile)
        
        global_model=loadparm(mgd_file,global_model,args.no_models,parmlen,8)
        # global_model=downloadparm(agg_par_arr,global_model,args.no_models,parmlen,8)
        loss = model_eval(global_model,evalDataLoader, device)

        # for ii in range(20):
        #     print(model_eval(global_model,trainDataLoader_dict[ii], device))

        time_array[-1]+=time.perf_counter()-stime
        
        # print("Epoch %d, training_loss: %f, eval_loss: %f" % (e, total_loss/len(candidates), loss))
        # #print(' ')
        # #print(' ')

        Train_loss.append(total_loss /len(candidates))
        Eval_loss.append(loss)
        epoch_.append(e)
        lr_.append(lr)

        ##early stopping
        min_vl_loss = min(Eval_loss)
        criteria = 100*(Eval_loss[-1]/min_vl_loss-1)
        print("Epoch %d, training_loss: %f, eval_loss: %f, stopping_criteria: %f" % (e, Train_loss[-1], Eval_loss[-1],criteria))
        args.final_epochs = e
            
        #lr adjust
        if(e != 0 and e %args.opt_decay_step == 0):
            lr = lr * args.opt_decay_rate
        
        #save model
        modelname = '_'.join(['model', str(e).rjust(3,'0'), '.ckpt'])
        torch.save(global_model.state_dict(), os.path.join(model_path, modelname))

    # df -> logpath
    df_out = dict()
    df_out['epoch'] = epoch_
    df_out['train_loss'] = Train_loss
    df_out['eval_loss'] = Eval_loss

    obj = dict()
    obj['args']= args 
    obj['curves'] = dict()
    obj['curves']['train_loss'] = Train_loss
    obj['curves']['eval_loss'] = Eval_loss
    obj['lr'] = lr_
    
    plot_curve(obj, log_path + 'lr.png', keys = ['lr'], clip = False, label_min = False, label_end = False)
    
    plot_curve(obj['curves'], log_path + 'curves.png', keys = None, clip = True, label_min = False, label_end = False)

    df = pd.DataFrame.from_dict(df_out, orient = 'index').transpose()
    df.to_csv(os.path.join(log_path, 'result.csv'))
        
    T2=time.perf_counter()
    TT=T2-T1
    print('Program execution time:%s second'%(TT))
    for i_ in range(args.no_models):
        print('Program execution time of client %s :%s second'%(i_,time_array[i_]))
    print('Program execution time of server :%s second'%(time_array[-1]))
    with open(os.path.join(log_path, 'args.txt'), 'a') as f:
        f.write('Program execution time:{}'.format(TT))
        for i_ in range(args.no_models):
            f.write('Program execution time of client %s :%s second'%(i_,time_array[i_]))
            f.write('\n')
        f.write('Program execution time of server :%s second'%(time_array[-1]))

    # evaluate(args, features, dataset_features, nodein_list, testout_list, testinDataLoader_dict, testoutDataLoader_dict, device)

def local_train(c,seed,lr,global_model,trainDataLoader_dict,n_total):
    ctime=time.perf_counter()
    id_ = c.client_id
    filepath="client"+str(id_)+".csv"
    #print(' ')
    #print(' ')
    #print(f'id_: {id_}') 
    
    # random.seed(seed)
    # np.random.seed(seed)
    # torch.manual_seed(seed)
    diff, loss_a = c.local_train(lr, global_model, trainDataLoader_dict[id_], n_total)
    # parmlen=saveparm(diff,filepath)
    upfile,tar1='C:/Users/iminx/Desktop/sl_sm/code/'+filepath,\
        "/Users/xulei/Desktop/Jiang_FL/code_NorthDakota/code_NorthDakota/"+filepath
    ssh_put(upfile,tar1)
    command_renew ="bash swarm_run.sh renew /Users/xulei/Desktop/Jiang_FL/code_NorthDakota/code_NorthDakota/"+filepath+" "+str(id_)
    command_0 = "cd ~/fisco/swarm-app-main/dist;"
    str1=command_0+command_renew
    ssh_cmd(str1)
    loacltime=time.perf_counter()-ctime
    return loacltime,diff,loss_a
        
def model_eval(global_model,eval_loader, device):
    global_model.to(device)
    global_model.eval()
    total_loss = 0.0

    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(eval_loader):
            data = data.float().to(device)
            target = target.float().to(device)

            y_output = global_model(data)
            target_ = target.view(len(y_output), -1)
            loss = torch.nn.functional.mse_loss(y_output, target_)
            loss_i = loss
            total_loss += loss_i.item()

    return total_loss / len(eval_loader)

if __name__ == '__main__':
    main()

