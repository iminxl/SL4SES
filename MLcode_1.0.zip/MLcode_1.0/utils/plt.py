import seaborn as sns
import os
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from matplotlib.colors import ListedColormap

from dataReading import combineData, loadDataSeq

def getDataforPlt(dir, seq_len, step):

    #features = ['GR', 'NPHI', 'RHOB', 'DTC', 'DTS']
    
    data_tr_list = []
    data_vl_list = []
    data_ts_list = []

    for id_ in range(5):
        data_str = '_'.join(['data', str(id_)])
        tr_dir = os.path.join(dir, 'training')
        fdir = os.path.join(tr_dir, data_str)
        flist = [ff for ff in os.listdir(fdir) if ff.endswith('.csv')]
        if (len(flist) > 0):
            data_tr, _, _, _ = loadDataSeq(tr_dir, id_, seq_len, step)
            data_tr_list+= data_tr

        val_dir = os.path.join(dir, 'validation')
        
        fdir = os.path.join(val_dir, data_str)
        flist = [ff for ff in os.listdir(fdir) if ff.endswith('.csv')]
        if (len(flist) > 0):
            #print('validation: ')
            data_vl, _, _, _ = loadDataSeq(val_dir, id_, seq_len, step)
            data_vl_list += data_vl


        ts_dir = os.path.join(dir, 'testing')
        fdir = os.path.join(ts_dir, data_str)
        flist = [ff for ff in os.listdir(fdir) if ff.endswith('.csv')]

        if (len(flist) > 0):
            #print('testing: ')
            data_ts, _, _, _ = loadDataSeq(ts_dir, id_, seq_len, step)
            data_ts_list += data_ts   

    print('length of data_tr_list: ', len(data_tr_list))   


def pairplot_feature():
    fsize= 12
    fdir = '../read_out/DTS'
    getDataforPlt(fdir, 100, 101)

def main():
    pairplot_feature()


if __name__ == '__main__':
    main()

