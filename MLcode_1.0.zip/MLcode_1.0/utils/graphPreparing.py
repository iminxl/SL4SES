import numpy as np
import pandas as pd
import torch

def prepare_data(x, node_mode, edge_mask):
    # type of x is torch.tensor
    # size of x is [num_node, num_feature]
    # edge_mask is torch.tensor
    # size of edge_mask is [num_node * num_feature, 1]
    
    edge_start, edge_end = create_edge(x)
    edge_index = torch.tensor([edge_start, edge_end], dtype = int)
    #print('edge_index: ', edge_index.size())

    edge_attr = torch.tensor(create_edge_attr(x), dtype = torch.float)
    #print('edge_attr: ', edge_attr.size())

    node_init = create_node(x, node_mode)
    xx = torch.tensor(node_init, dtype = torch.float)
    #print('size of xx: ', xx.size())

    #edge_mask = mask.flatten()
    #print('size of edge_mask: ', edge_mask.size())

    double_edge_mask = torch.cat((edge_mask, edge_mask), dim = 0)
    #print('size of double_edge_mask: ', double_edge_mask.size())

    masked_edge_index, masked_edge_attr = mask_edge(edge_index, edge_attr, double_edge_mask, True)

    return xx, edge_index, masked_edge_index, masked_edge_attr
    
def create_node(x, mode):
    # type of x is torch.tensor
    # size of x is [num_node, num_feature]
    if mode == 0: # onehot feature node, all 1 sample node
        nrow, ncol = x.size()
        feature_ind = np.array(range(ncol))
        feature_node = np.zeros((ncol,ncol))
        feature_node[np.arange(ncol), feature_ind] = 1
        sample_node = [[1]*ncol for i in range(nrow)]
        node = sample_node + feature_node.tolist()
    elif mode == 1: # onehot sample and feature node
        nrow, ncol = x.size()
        feature_ind = np.array(range(ncol))
        feature_node = np.zeros((ncol,ncol+1))
        feature_node[np.arange(ncol), feature_ind+1] = 1
        sample_node = np.zeros((nrow,ncol+1))
        sample_node[:,0] = 1
        node = sample_node.tolist() + feature_node.tolist()
    return node

def create_edge(x):
    # type of x is torch.tensor
    # size of x is [num_node, num_feature]

    n_row, n_col = x.size()
    edge_start = []
    edge_end = []
    for x in range(n_row):
        edge_start = edge_start + [x] * n_col # obj
        edge_end = edge_end + list(n_row + np.arange(n_col)) # att

    edge_start_new = edge_start + edge_end
    edge_end_new = edge_end + edge_start
    return (edge_start_new, edge_end_new)

def create_edge_attr(x):
    # type of x is torch.tensor
    # size of x is [num_node, num_feature]

    if isinstance(x, pd.core.frame.DataFrame):
        x = torch.tensor(x.values, dtype = torch.float)
    
    nrow, ncol = x.size()
    edge_attr = []
    for i in range(nrow):
        for j in range(ncol):
            edge_attr.append([float(x[i, j])])
    edge_attr = edge_attr + edge_attr
    return edge_attr

def mask_edge(edge_index, edge_attr, mask, remove_edge):
    edge_index = edge_index.clone().detach()
    edge_attr = edge_attr.clone().detach()
    if remove_edge:
        edge_index = edge_index[:, mask]
        edge_attr = edge_attr[mask]
    else:
        edge_attr[~mask] = 0.
    return edge_index, edge_attr













    

