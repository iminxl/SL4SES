import subprocess

def run_cmd(str):
    # CMD命令
    # 执行CMD命令
    process = subprocess.Popen(str, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # process2 = subprocess.Popen(cmd_command2, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # 获取命令执行的结果
    stdout, stderr = process.communicate()
    # 标准输出
    # print(stdout.decode("gbk"))
    # 标准错误
    # print(stderr.decode("gbk") == "")
    if process.returncode != 0:
        print(f'Error occurred: {stderr.decode()}')
    else:
        print(stdout.decode("gbk"))

if __name__=="__main__":
    # filepath="client0.csv"
    # cmd_command = "cd ~/fisco/swarm-app-main/dist;" # 这只是一个例子，你可以替换成你需要的任何CMD命令
    # cmd_command2 ="bash swarm_run.sh renew /Users/xulei/Desktop/Jiang_FL/code_NorthDakota/code_NorthDakota/"+filepath+" 0"
    # str=cmd_command+cmd_command2
    str="ssh xulei@192.168.101.2;exit"
    run_cmd(str)