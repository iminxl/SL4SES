import os 
import pandas as pd 
import numpy as np 
import random 
import torch
from utils.dataset import SeqDataset3
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
from training.gru_x_gaswell import predictCurve2 
from models.gruNet import get_gru3

def getRank(dataset_len,testout_num,testout_rank,locnode_num,locframe_num):
    
    fold_num=dataset_len/testout_num
    all_list=list(range(0,dataset_len))
    testout_list=[all_list[i:i+testout_num] for i in range(0,dataset_len,testout_num)][testout_rank]
    
    in_list=list(set(all_list)-set(testout_list))
    o_list=random.sample(in_list,testout_num)

    in_list=list(set(in_list)-set(o_list))
    nodein_list=[[i] for i in o_list]
    if locframe_num == 1:
        for i in range(testout_num,locnode_num):
            app_list=random.sample(in_list,1)
            in_list=list(set(in_list)-set(app_list))
            nodein_list.append(app_list)
        nodein_list=sorted(nodein_list,key=(lambda x:x[0]))
    else:
        for _ in range(1,locframe_num):
            app_list=random.sample(in_list,locnode_num)
            in_list=list(set(in_list)-set(app_list))
            for i in range(locnode_num):
                nodein_list[i].append(app_list[i])
        nodein_list=sorted(nodein_list,key=(lambda x:x[0]))
        for i in range(locnode_num):
            nodein_list[i]=sorted(nodein_list[i])
    return nodein_list,testout_list

def getDataset_loc(dataDir,rank,features, dataset_features, seq_len, step, winsize):

    filelist=os.listdir(dataDir)
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    fpathlist.sort()
    print('filelist:')
    print(fpathlist)
    print(fpathlist[rank])

    x_tr, y_tr, _ = loadData_swprop(0,[fpathlist[rank]], features, dataset_features, seq_len, step, winsize)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr)) 

    x_vl, y_vl, _ = loadData_swprop(1,[fpathlist[rank]], features, dataset_features, seq_len, step, winsize)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl)) 

    name=str(filelist[rank]).split(".")[0]

    return data_tr,data_vl,name

def getDataset_loc_entry(dataDir,rank,features, dataset_features, seq_len, step, winsize, nyear):

    filelist=os.listdir(dataDir)
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    fpathlist.sort()
    print('filelist:')
    print(fpathlist)
    print(fpathlist[rank])

    x_tr, y_tr, _ = loadData_swprop_entry(0,[fpathlist[rank]], features, dataset_features, seq_len, step, winsize, nyear)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr)) 

    x_vl, y_vl, _ = loadData_swprop_entry(1,[fpathlist[rank]], features, dataset_features, seq_len, step, winsize, nyear)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl)) 

    name=str(filelist[rank]).split(".")[0]

    return data_tr,data_vl,name

def getDataset_locmulti(dataDir,nodein_list,rank,features, dataset_features, seq_len, step, winsize):

    filelist=os.listdir(dataDir)
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    fpathlist.sort()
    uselist=nodein_list[rank]
    print('filelist:')
    print(fpathlist)
    print('uselist:')
    print(uselist)
    x_tr, y_tr, _ = loadData_swprop(0,[fpathlist[j] for j in uselist], features, dataset_features, seq_len, step, winsize)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr)) 

    x_vl, y_vl, _ = loadData_swprop(1,[fpathlist[j] for j in uselist], features, dataset_features, seq_len, step, winsize)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl)) 

    name=rank

    return data_tr,data_vl,name

def getDataset_sl_full(dataDir,nodein_list,testout_list,locnode_num,locframe_num,features, dataset_features, seq_len, step, winsize):
    filelist=os.listdir(dataDir)
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    fpathlist.sort()
    data_tr_dict = {}
    data_ts_dict = {}
    data_ts_in_dict = {}
    data_ts_out_dict = {}

    n_total = 0
    counter=0
    for i in range(locnode_num):
        x_tr, y_tr, _ = loadData_swprop(0,[fpathlist[j] for j in nodein_list[i]], features, dataset_features, seq_len, step, winsize)
        # x_ts, y_ts, _ = loadData_swprop(2,[fpathlist[j] for j in nodein_list[i]], features, dataset_features, seq_len, step, winsize)

        x_tp = np.asarray(x_tr)
        r1, r2, r3 = x_tp.shape
        n_total += r1 * r2
        #print('r1 * r2: ', r1 * r2)
        tp_tr = np.asarray(x_tr)
        print(' ')
        print(f'id_: {counter}')
        print(f'x_tr.shape: {tp_tr.shape}')
        print(f'y_tr.shape: {np.asarray(y_tr).shape}')
        dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr))
        # dataset_ts = SeqDataset3(np.asarray(x_ts), np.asarray(y_ts))

        data_tr_dict[counter] = dataset_tr
        # data_ts_dict[counter] = dataset_ts
        counter+=1
    
    x_tr, y_tr, _ = loadData_swprop(0,[fpathlist[j] for j in [i for item in nodein_list for i in item]], features, dataset_features, seq_len, step, winsize)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr)) 

    x_vl, y_vl, _ = loadData_swprop(1,[fpathlist[j] for j in [i for item in nodein_list for i in item]], features, dataset_features, seq_len, step, winsize)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl)) 
    
    counter=0
    for i in range(locframe_num * locnode_num):
        rank=[j for item in nodein_list for j in item][i]
        x_ts_in, y_ts_in, _ = loadData_swprop(2,[fpathlist[rank]], features, dataset_features, seq_len, step, winsize)

        tp_in = np.asarray(x_ts_in)
        print(f'shape of x_ts_in: {tp_in.shape}')

        data_ts_in_dict[counter] = SeqDataset3(np.asarray(x_ts_in), np.asarray(y_ts_in))
        counter+=1

    counter=0
    for i in testout_list:
        x_ts_out, y_ts_out, _ = loadDataSeq_sw([fpathlist[i]], features, dataset_features, seq_len, step, winsize)

        tp_out = np.asarray(x_ts_out)
        print(f'shape of x_ts_out: {tp_out.shape}')

        data_ts_out_dict[counter] = SeqDataset3(np.asarray(x_ts_out), np.asarray(y_ts_out))
        counter+=1

    return data_tr_dict,data_tr,data_vl,data_ts_in_dict,data_ts_out_dict,n_total

def getDataset_sl_full_entry(dataDir,nodein_list,testout_list,locnode_num,locframe_num,features, dataset_features, seq_len, step, winsize, nyear):
    filelist=os.listdir(dataDir)
    fpathlist = [os.path.join(dataDir,ff)for ff in os.listdir(dataDir) if ff.endswith('.csv')]
    fpathlist.sort()
    data_tr_dict = {}
    data_ts_dict = {}
    data_ts_in_dict = {}
    data_ts_out_dict = {}

    n_total = 0
    counter=0
    for i in range(locnode_num):
        x_tr, y_tr, _ = loadData_swprop_entry(0,[fpathlist[j] for j in nodein_list[i]], features, dataset_features, seq_len, step, winsize, nyear)
        # x_ts, y_ts, _ = loadData_swprop(2,[fpathlist[j] for j in nodein_list[i]], features, dataset_features, seq_len, step, winsize)

        x_tp = np.asarray(x_tr)
        r1, r2, r3 = x_tp.shape
        n_total += r1 * r2
        #print('r1 * r2: ', r1 * r2)
        tp_tr = np.asarray(x_tr)
        print(' ')
        print(f'id_: {counter}')
        print(f'x_tr.shape: {tp_tr.shape}')
        print(f'y_tr.shape: {np.asarray(y_tr).shape}')
        dataset_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr))
        # dataset_ts = SeqDataset3(np.asarray(x_ts), np.asarray(y_ts))

        data_tr_dict[counter] = dataset_tr
        # data_ts_dict[counter] = dataset_ts
        counter+=1
    
    x_tr, y_tr, _ = loadData_swprop_entry(0,[fpathlist[j] for j in [i for item in nodein_list for i in item]], features, dataset_features, seq_len, step, winsize, nyear)
    data_tr = SeqDataset3(np.asarray(x_tr), np.asarray(y_tr)) 

    x_vl, y_vl, _ = loadData_swprop_entry(1,[fpathlist[j] for j in [i for item in nodein_list for i in item]], features, dataset_features, seq_len, step, winsize, nyear)
    data_vl = SeqDataset3(np.asarray(x_vl), np.asarray(y_vl)) 
    
    counter=0
    for i in range(locframe_num * locnode_num):
        rank=[j for item in nodein_list for j in item][i]
        x_ts_in, y_ts_in, _ = loadData_swprop(2,[fpathlist[rank]], features, dataset_features, seq_len, step, winsize)

        tp_in = np.asarray(x_ts_in)
        print(f'shape of x_ts_in: {tp_in.shape}')

        data_ts_in_dict[counter] = SeqDataset3(np.asarray(x_ts_in), np.asarray(y_ts_in))
        counter+=1

    counter=0
    for i in testout_list:
        x_ts_out, y_ts_out, _ = loadDataSeq_sw([fpathlist[i]], features, dataset_features, seq_len, step, winsize)

        tp_out = np.asarray(x_ts_out)
        print(f'shape of x_ts_out: {tp_out.shape}')

        data_ts_out_dict[counter] = SeqDataset3(np.asarray(x_ts_out), np.asarray(y_ts_out))
        counter+=1

    return data_tr_dict,data_tr,data_vl,data_ts_in_dict,data_ts_out_dict,n_total

def loadData_swprop(num,filePathList, features, dataset_features, seq_len, step, winsize):
    """
    mu is the overall mean of all the groups
    std is the overall std of all the groups

    also, mu can be min, and std can be max if MinMaxScaler is used
    """
    proplist=[0,.7,.9,1]
    xx_list = []
    yy_list = []
    scalar_list = []
    for filePath in filePathList:
        # print(filePath)
        df = pd.read_csv(filePath)
        df=df[features]
        df = df.fillna(method='pad')
        df = df.fillna(0)
        # print(df.describe())
        #print(' ')
        #print(f'filePath: {filePath}')
        scaler = MinMaxScaler()
        # scaler.fit(df)
        df_scaler = (df - df.min()) / (df.max()-df.min())
        data = dataProcess(df_scaler,features)        
        # data = dataProcess(df,features)
        df_s = data[dataset_features]
        # df_s_max = (df_s > 1000)
        # print(df_s_max.sum())
        data = df_s.values
        print(f'{filePath},shape:{data.shape},{num}set len:{np.floor(proplist[num+1]*len(data))-np.floor(proplist[num]*len(data))}')
        if num==2:
            data=data[int(np.floor(proplist[num]*len(data))):-1,:]
        else:
            data=data[int(np.floor(proplist[num]*len(data))):int(np.floor(proplist[num+1]*len(data))),:]

        # scaler = MinMaxScaler()
        # scaler.fit(df_s)
        # data = scaler.fit_transform(df_s)
        scalar_list.append(scaler)

        x_list, y_list = genSeq2_sw(data, seq_len, step, winsize)

        xx_list += x_list
        yy_list += y_list 

    return xx_list, yy_list, scalar_list

def loadData_swprop_entry(num,filePathList, features, dataset_features, seq_len, step, winsize, nyear):
    """
    mu is the overall mean of all the groups
    std is the overall std of all the groups

    also, mu can be min, and std can be max if MinMaxScaler is used
    """
    proplist=[0,.7,.9,1]
    xx_list = []
    yy_list = []
    scalar_list = []
    for filePath in filePathList:
        # print(filePath)
        df = pd.read_csv(filePath)
        df=df[features]
        df = df.fillna(method='pad')
        df = df.fillna(0)
        # print(df.describe())
        #print(' ')
        #print(f'filePath: {filePath}')
        scaler = MinMaxScaler()
        # scaler.fit(df)
        df_scaler = (df - df.min()) / (df.max()-df.min())
        data = dataProcess(df_scaler,features)        
        # data = dataProcess(df,features)
        df_s = data[dataset_features]
        # df_s_max = (df_s > 1000)
        # print(df_s_max.sum())
        data = df_s.values
        if num == 2:
            print(f'{filePath},shape:{data.shape},{num}set len:{np.floor(proplist[num+1]*len(data))-np.floor(proplist[num]*len(data))}')
        elif num == 0:
            flg=min(int(np.floor(proplist[num+1]*len(data))),nyear*30)
            print(f'{filePath},shape:{data.shape},{num}set len:{flg-np.floor(proplist[num]*len(data))}')
        elif num == 1:
            flg=min(int(np.floor(proplist[num+1]*len(data))),nyear*30)
            print(f'{filePath},shape:{data.shape},{num}set len:{np.floor(flg/7*2)}')
        
        if num==2:
            data=data[int(np.floor(proplist[num]*len(data))):-1,:]
        elif num ==0 :
            data=data[int(np.floor(proplist[num]*len(data))):flg,:]
        else:
            print(flg)
            data=data[flg:int(np.floor(flg/7*2))+flg,:]

        # scaler = MinMaxScaler()
        # scaler.fit(df_s)
        # data = scaler.fit_transform(df_s)
        scalar_list.append(scaler)

        x_list, y_list = genSeq2_sw(data, seq_len, step, winsize)

        xx_list += x_list
        yy_list += y_list 

    return xx_list, yy_list, scalar_list

def dataProcess(df, features):
    data=df[features]
    data = data.fillna(method='pad')
    data = data.fillna(0)
    # print(data.describe())
    data['DWperday']=data['DW,m3perd']/data['PT,h']*24
    data['DHGperday']=data['DHG,104m3perd']/data['PT,h']*24
    data = data.replace(np.inf,np.nan)
    data = data.fillna(method='pad')
    data = data.fillna(0)
    # print(data.describe())
    diff_DWperday=np.array(data['DWperday'][1:])-np.array(data['DWperday'][:-1])
    diff_DHGperday=np.array(data['DHGperday'][1:])-np.array(data['DHGperday'][:-1])
    final_features=['TP,Mpa','CP,Mpa','PT,h','normal production','DWperday','DHGperday']
    
    f=data[final_features][1:]
    f['diff_DWperday']=diff_DWperday
    f['diff_DHGperday']=diff_DHGperday
    # print(f.describe())
    return f

def loadDataSeq_sw(filePathList, features, dataset_features, seq_len, step, winsize):
    """
    mu is the overall mean of all the groups
    std is the overall std of all the groups

    also, mu can be min, and std can be max if MinMaxScaler is used
    """
    xx_list = []
    yy_list = []
    scalar_list = []
    for filePath in filePathList:
        # print(filePath)
        df = pd.read_csv(filePath)
        df=df[features]
        df = df.fillna(method='pad')
        df = df.fillna(0)
        # print(df.describe())
        #print(' ')
        #print(f'filePath: {filePath}')
        scaler = MinMaxScaler()
        # scaler.fit(df)
        df_scaler = (df - df.min()) / (df.max()-df.min())
        data = dataProcess(df_scaler,features)        
        # data = dataProcess(df,features)
        df_s = data[dataset_features]
        # df_s_max = (df_s > 1000)
        # print(df_s_max.sum())
        data = df_s.values
        # scaler = MinMaxScaler()
        # scaler.fit(df_s)
        # data = scaler.fit_transform(df_s)
        scalar_list.append(scaler)

        x_list, y_list = genSeq2_sw(data, seq_len, step, winsize)

        xx_list += x_list
        yy_list += y_list 

    return xx_list, yy_list, scalar_list

def genSeq2_sw(data, seq_len, step, winsize):
    x_list = []
    y_list = []
    nrow, ncol = data.shape
    for i in range(0, nrow, step):
        i_end = i  + seq_len
        if(i_end+1 > nrow):
            break

        data_s = data[i: i_end+winsize]
        #skip if any of the element is nan
        if(np.isnan(data_s).any()):
            continue

        i_s = ncol #index of DTS

        data_scaled = data_s
        x = data_scaled[:-winsize, :]
        y = data_scaled[-winsize:, ncol-1]

        x_list.append(x)
        y_list.append(y)

    return x_list, y_list

#按照node个数作evaluate
def evaluate(args, features, dataset_features, nodein_list, testout_list, data_ts_in_dict, data_ts_out_dict, device):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    str_lr = '_'.join(['lr', str(args.lr)])
    str_seed = '_'.join(['seed', str(args.seed)])
    args_dict =vars(args)
    arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models,args.locframe_num, args.fold_id)
    if not os.path.exists(arg_path):
        os.makedirs(arg_path)    
    with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
        for key, value in args_dict.items():
            f.write('{}:{}'.format(key, value))
            f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    fpathlist = [os.path.join(args.dataPath,ff) for ff in filelist if ff.endswith('.csv')]
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]
    test_in_name_list=[]
    test_in_mseloss_list=[]
    test_in_maeloss_list=[]
    test_in_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    for d in range(args.no_models*args.locframe_num):
        rank = test_in_id[d]
        filename=filelist[rank]
        print(filename.split('.')[0])
        name=filename.split('.')[0]
        test_in_name_list.append(name)


        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        model_path = modelpath + '/{}/{}clients/{}frames/fold_{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id)
        model = get_gru3(args).to(device)
        
        modelname ='_'.join(['model', str(args.final_epochs).rjust(3,'0'), '.ckpt'])
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        df0 = pd.read_csv(args.dataPath+'\\'+name+'.csv')
        data = dataProcess(df0,features)
        DHGperday = data['DHGperday']
        DHGperday=DHGperday[int(np.floor(0.9*len(data))):-1]
        PT = data['PT,h'][int(np.floor(0.9*len(data))):-1]

        _ ,ts_mseloss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_in_dict[d], model, device, PT, DHGperday)
        test_in_mseloss_list.append(ts_mseloss)
        test_in_maeloss_list.append(ts_maeloss)
        test_in_len_list.append(len(data_list))

        data_c = np.hstack([np.array(data_list).reshape(-1,1), np.array(output_list).reshape(-1,1)])
        data_c = data_c.reshape(-1,2)
        columns = ['DHG', 'DHG_p']
        df = pd.DataFrame(data = data_c, columns = columns)
        df.to_csv(os.path.join(log_path,'{}.csv'.format(name)))

        figplt(60,6,data_list,output_list,log_path,name)

    mseloss_locnode=[]
    maeloss_locnode=[]
    if args.locframe_num != 1:
        test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
        test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
        test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
        for i in range(args.no_models):
            node_datanum = sum(test_in_len_list2[i])
            node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
            node_ts_mseloss = node_unbl_mseloss/node_datanum
            mseloss_locnode.append(node_ts_mseloss)
            node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
            node_ts_maeloss = node_unbl_maeloss/node_datanum
            maeloss_locnode.append(node_ts_maeloss)
    
    test_out_name_list=[]
    test_out_mseloss_list=[]
    test_out_maeloss_list=[]
    test_out_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testout'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)
        
    for j in range(args.testout_num):
        rank = testout_list[j]
        filename=filelist[rank]
        print(filename.split('.')[0])
        name=filename.split('.')[0]
        ##路径，计算loss，绘图
        test_out_name_list.append(name)


        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        model_path = modelpath + '/{}/{}clients/{}frames/fold_{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id)
        model = get_gru3(args).to(device)
        
        modelname ='_'.join(['model', str(args.final_epochs).rjust(3,'0'), '.ckpt'])
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        df0 = pd.read_csv(args.dataPath+'\\'+name+'.csv')
        data = dataProcess(df0,features)
        DHGperday = data['DHGperday']
        PT = data['PT,h']

        _ ,ts_mseloss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_out_dict[j], model, device, PT, DHGperday)
        test_out_mseloss_list.append(ts_mseloss)
        test_out_maeloss_list.append(ts_maeloss)
        test_out_len_list.append(len(data_list))

        data_c = np.hstack([np.array(data_list).reshape(-1,1), np.array(output_list).reshape(-1,1)])
        data_c = data_c.reshape(-1,2)
        columns = ['DHG', 'DHG_p']
        df = pd.DataFrame(data = data_c, columns = columns)
        df.to_csv(os.path.join(log_path,'{}.csv'.format(name)))

        figplt(60,6,data_list,output_list,log_path,name)

    #记录,做表格
    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_in_mseloss_list[i]
        log_list[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_out_mseloss_list[j]
        log_list[2][id_]=0
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list[3][k] = mseloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df = pd.DataFrame(data = log_list)
    df=df.T
    df.rename(columns = columns,inplace=True)
    df.to_csv(os.path.join(arg_path,'mse.csv'))   
    
    #记录,做表格
    log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_in_maeloss_list[i]
        log_list2[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_out_maeloss_list[j]
        log_list2[2][id_]=0
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list2[3][k] = maeloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df2 = pd.DataFrame(data = log_list2)
    df2=df2.T
    df2.rename(columns = columns,inplace=True)
    df2.to_csv(os.path.join(arg_path,'mae.csv'))  

def evaluateentry(args, features, dataset_features, nodein_list, testout_list, data_ts_in_dict, data_ts_out_dict, device):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    str_lr = '_'.join(['lr', str(args.lr)])
    str_seed = '_'.join(['seed', str(args.seed)])
    args_dict =vars(args)
    arg_path = args.logPath_ts + '{}/_{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.nyear, args.global_epochs, str_lr, str_seed, args.no_models,args.locframe_num, args.fold_id)
    if not os.path.exists(arg_path):
        os.makedirs(arg_path)    
    with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
        for key, value in args_dict.items():
            f.write('{}:{}'.format(key, value))
            f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    fpathlist = [os.path.join(args.dataPath,ff) for ff in filelist if ff.endswith('.csv')]
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]
    test_in_name_list=[]
    test_in_mseloss_list=[]
    test_in_maeloss_list=[]
    test_in_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '{}/_{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.nyear, args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    for d in range(args.no_models*args.locframe_num):
        rank = test_in_id[d]
        filename=filelist[rank]
        print(filename.split('.')[0])
        name=filename.split('.')[0]
        test_in_name_list.append(name)


        modelpath = args.logPath + '/{}/lr_{}'.format(args.nyear, args.lr)
        model_path = modelpath + '/{}/{}clients/{}frames/fold_{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id)
        model = get_gru3(args).to(device)
        
        modelname ='_'.join(['model', str(args.final_epochs).rjust(3,'0'), '.ckpt'])
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        df0 = pd.read_csv(args.dataPath+'\\'+name+'.csv')
        data = dataProcess(df0,features)
        DHGperday = data['DHGperday']
        DHGperday=DHGperday[int(np.floor(0.9*len(data))):-1]
        PT = data['PT,h'][int(np.floor(0.9*len(data))):-1]

        _ ,ts_mseloss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_in_dict[d], model, device, PT, DHGperday)
        test_in_mseloss_list.append(ts_mseloss)
        test_in_maeloss_list.append(ts_maeloss)
        test_in_len_list.append(len(data_list))

        data_c = np.hstack([np.array(data_list).reshape(-1,1), np.array(output_list).reshape(-1,1)])
        data_c = data_c.reshape(-1,2)
        columns = ['DHG', 'DHG_p']
        df = pd.DataFrame(data = data_c, columns = columns)
        df.to_csv(os.path.join(log_path,'{}.csv'.format(name)))

        figplt(60,6,data_list,output_list,log_path,name)

    mseloss_locnode=[]
    maeloss_locnode=[]
    if args.locframe_num != 1:
        test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
        test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
        test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
        for i in range(args.no_models):
            node_datanum = sum(test_in_len_list2[i])
            node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
            node_ts_mseloss = node_unbl_mseloss/node_datanum
            mseloss_locnode.append(node_ts_mseloss)
            node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
            node_ts_maeloss = node_unbl_maeloss/node_datanum
            maeloss_locnode.append(node_ts_maeloss)
    
    test_out_name_list=[]
    test_out_mseloss_list=[]
    test_out_maeloss_list=[]
    test_out_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '{}/_{}/{}/{}/{}clients/{}frames/fold_{}/testout'.format(args.nyear, args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)
        
    for j in range(args.testout_num):
        rank = testout_list[j]
        filename=filelist[rank]
        print(filename.split('.')[0])
        name=filename.split('.')[0]
        ##路径，计算loss，绘图
        test_out_name_list.append(name)


        modelpath = args.logPath + '/{}/lr_{}'.format(args.nyear, args.lr)
        model_path = modelpath + '/{}/{}clients/{}frames/fold_{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id)
        model = get_gru3(args).to(device)
        
        modelname ='_'.join(['model', str(args.final_epochs).rjust(3,'0'), '.ckpt'])
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        df0 = pd.read_csv(args.dataPath+'\\'+name+'.csv')
        data = dataProcess(df0,features)
        DHGperday = data['DHGperday']
        PT = data['PT,h']

        _ ,ts_mseloss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_out_dict[j], model, device, PT, DHGperday)
        test_out_mseloss_list.append(ts_mseloss)
        test_out_maeloss_list.append(ts_maeloss)
        test_out_len_list.append(len(data_list))

        data_c = np.hstack([np.array(data_list).reshape(-1,1), np.array(output_list).reshape(-1,1)])
        data_c = data_c.reshape(-1,2)
        columns = ['DHG', 'DHG_p']
        df = pd.DataFrame(data = data_c, columns = columns)
        df.to_csv(os.path.join(log_path,'{}.csv'.format(name)))

        figplt(60,6,data_list,output_list,log_path,name)

    #记录,做表格
    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_in_mseloss_list[i]
        log_list[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_out_mseloss_list[j]
        log_list[2][id_]=0
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list[3][k] = mseloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df = pd.DataFrame(data = log_list)
    df=df.T
    df.rename(columns = columns,inplace=True)
    df.to_csv(os.path.join(arg_path,'mse.csv'))   
    
    #记录,做表格
    log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_in_maeloss_list[i]
        log_list2[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_out_maeloss_list[j]
        log_list2[2][id_]=0
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list2[3][k] = maeloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df2 = pd.DataFrame(data = log_list2)
    df2=df2.T
    df2.rename(columns = columns,inplace=True)
    df2.to_csv(os.path.join(arg_path,'mae.csv')) 

def evaluated(args, features, dataset_features, nodein_list, testout_list, data_ts_in_dict, data_ts_out_dict, device):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    str_lr = '_'.join(['lr', str(args.lr)])
    str_seed = '_'.join(['seed', str(args.seed)])
    str_slseed = '_'.join(['seed', str(args.selseed)])

    args_dict =vars(args)
    arg_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_slseed, str_seed, args.no_models,args.locframe_num, args.fold_id)
    if not os.path.exists(arg_path):
        os.makedirs(arg_path)    
    with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
        for key, value in args_dict.items():
            f.write('{}:{}'.format(key, value))
            f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    fpathlist = [os.path.join(args.dataPath,ff) for ff in filelist if ff.endswith('.csv')]
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]
    test_in_name_list=[]
    test_in_mseloss_list=[]
    test_in_maeloss_list=[]
    test_in_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_slseed, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    for d in range(args.no_models*args.locframe_num):
        rank = test_in_id[d]
        filename=filelist[rank]
        print(filename.split('.')[0])
        name=filename.split('.')[0]
        test_in_name_list.append(name)


        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        model_path = modelpath + '/{}/{}/{}clients/{}frames/fold_{}/model'.format(str_slseed, str_seed,args.no_models,args.locframe_num,args.fold_id)
        model = get_gru3(args).to(device)
        
        modelname ='_'.join(['model', str(args.final_epochs).rjust(3,'0'), '.ckpt'])
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        df0 = pd.read_csv(args.dataPath+'\\'+name+'.csv')
        data = dataProcess(df0,features)
        DHGperday = data['DHGperday']
        DHGperday=DHGperday[int(np.floor(0.9*len(data))):-1]
        PT = data['PT,h'][int(np.floor(0.9*len(data))):-1]

        _ ,ts_mseloss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_in_dict[d], model, device, PT, DHGperday)
        test_in_mseloss_list.append(ts_mseloss)
        test_in_maeloss_list.append(ts_maeloss)
        test_in_len_list.append(len(data_list))

        data_c = np.hstack([np.array(data_list).reshape(-1,1), np.array(output_list).reshape(-1,1)])
        data_c = data_c.reshape(-1,2)
        columns = ['DHG', 'DHG_p']
        df = pd.DataFrame(data = data_c, columns = columns)
        df.to_csv(os.path.join(log_path,'{}.csv'.format(name)))

        figplt(60,6,data_list,output_list,log_path,name)

    mseloss_locnode=[]
    maeloss_locnode=[]
    if args.locframe_num != 1:
        test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
        test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
        test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
        for i in range(args.no_models):
            node_datanum = sum(test_in_len_list2[i])
            node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
            node_ts_mseloss = node_unbl_mseloss/node_datanum
            mseloss_locnode.append(node_ts_mseloss)
            node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
            node_ts_maeloss = node_unbl_maeloss/node_datanum
            maeloss_locnode.append(node_ts_maeloss)
    
    test_out_name_list=[]
    test_out_mseloss_list=[]
    test_out_maeloss_list=[]
    test_out_len_list=[]

    ##路径，计算loss，绘图
    log_path = args.logPath_ts + '_{}/{}/{}/{}/{}clients/{}frames/fold_{}/testout'.format(args.global_epochs, str_lr, str_slseed, str_seed,args.no_models,args.locframe_num,args.fold_id)
    if not os.path.exists(log_path):
        os.makedirs(log_path)
        
    for j in range(args.testout_num):
        rank = testout_list[j]
        filename=filelist[rank]
        print(filename.split('.')[0])
        name=filename.split('.')[0]
        ##路径，计算loss，绘图
        test_out_name_list.append(name)


        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        model_path = modelpath + '/{}/{}/{}clients/{}frames/fold_{}/model'.format(str_slseed,str_seed,args.no_models,args.locframe_num,args.fold_id)
        model = get_gru3(args).to(device)
        
        modelname ='_'.join(['model', str(args.final_epochs).rjust(3,'0'), '.ckpt'])
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))

        df0 = pd.read_csv(args.dataPath+'\\'+name+'.csv')
        data = dataProcess(df0,features)
        DHGperday = data['DHGperday']
        PT = data['PT,h']

        _ ,ts_mseloss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_out_dict[j], model, device, PT, DHGperday)
        test_out_mseloss_list.append(ts_mseloss)
        test_out_maeloss_list.append(ts_maeloss)
        test_out_len_list.append(len(data_list))

        data_c = np.hstack([np.array(data_list).reshape(-1,1), np.array(output_list).reshape(-1,1)])
        data_c = data_c.reshape(-1,2)
        columns = ['DHG', 'DHG_p']
        df = pd.DataFrame(data = data_c, columns = columns)
        df.to_csv(os.path.join(log_path,'{}.csv'.format(name)))

        figplt(60,6,data_list,output_list,log_path,name)

    #记录,做表格
    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_in_mseloss_list[i]
        log_list[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list[0][id_]=filelist[id_]
        log_list[1][id_]=test_out_mseloss_list[j]
        log_list[2][id_]=0
    for i in range(24):
        log_list[0][i]=filelist[i]
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list[3][k] = mseloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df = pd.DataFrame(data = log_list)
    df=df.T
    df.rename(columns = columns,inplace=True)
    df.to_csv(os.path.join(arg_path,'mse.csv'))   
    
    #记录,做表格
    log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
    for i in range(args.no_models*args.locframe_num):
        id_ = test_in_id[i]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_in_maeloss_list[i]
        log_list2[2][id_]=int(i/args.locframe_num+1)
    for j in range(args.testout_num):
        id_ = testout_list[j]
        log_list2[0][id_]=filelist[id_]
        log_list2[1][id_]=test_out_maeloss_list[j]
        log_list2[2][id_]=0
    for i in range(24):
        log_list2[0][i]=filelist[i]
    if args.locframe_num != 1:
        for k in range(args.no_models):
            log_list2[3][k] = maeloss_locnode[k]
    columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
    df2 = pd.DataFrame(data = log_list2)
    df2=df2.T
    df2.rename(columns = columns,inplace=True)
    df2.to_csv(os.path.join(arg_path,'mae.csv'))  

def figplt(l,w,data_list,output_list,log_path,name):
    plt.figure(figsize = (l, w))
    plt.plot(np.arange(len(data_list)),data_list,linewidth=1.5,label='DHG')
    plt.plot(np.arange(len(data_list)),output_list,linewidth=1.5,label='DHG_p')
    plt.xlim(0,len(data_list))
    plt.legend()
    plt.savefig(log_path+'/'+ name + '.png', dpi=300, bbox_inches='tight')
    plt.close()

def loc_evaluate(args, features, dataset_features, nodein_list, testout_list, data_ts_in_dict, data_ts_out_dict, device):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    # str_lr = '_'.join(['lr', str(args.lr)])
    # str_seed = '_'.join(['seed', str(args.seed)])
    # args_dict =vars(args)
    # arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models, args.locframe_num, args.fold_id)
    # if not os.path.exists(arg_path):
    #     os.makedirs(arg_path)    
    # with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
    #     for key, value in args_dict.items():
    #         f.write('{}:{}'.format(key, value))
    #         f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    fpathlist = [os.path.join(args.dataPath,ff) for ff in filelist if ff.endswith('.csv')]
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]


    # ##路径，计算loss，绘图
    # log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    # if not os.path.exists(log_path):
    #     os.makedirs(log_path)

    for k in range(args.no_models):
        str_lr = '_'.join(['lr', str(args.lr)])
        str_seed = '_'.join(['seed', str(args.seed)])
        modelpath = args.logPath + '/lr_{}'.format(args.lr)
        print('**********************************************')
        if args.locframe_num==1:
            rank = test_in_id[k]
            filename=filelist[rank]
            print('model filename')
            print(filename.split('.')[0])
            print('')
            Name=filename.split('.')[0]
            model_path = modelpath + '/{}/{}clients/{}frames/{}/model'.format(str_seed,args.no_models,args.locframe_num,Name)
        else:
            Name=k
            print('model filename')
            print(Name)
            print('')
            model_path = modelpath + '/{}/{}clients/{}frames/fold{}/{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        
        args_dict =vars(args)
        arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models, args.locframe_num, args.fold_id,Name)
        if not os.path.exists(arg_path):
            os.makedirs(arg_path)    
        with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
            for key, value in args_dict.items():
                f.write('{}:{}'.format(key, value))
                f.write('\n')
        
        test_in_name_list=[]
        test_in_mseloss_list=[]
        test_in_maeloss_list=[]
        test_in_len_list=[]
        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)

        model = get_gru3(args).to(device)
        
        model_list=os.listdir(model_path)
        model_list.sort()
        modelname=model_list[-1]
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))
    
        for d in range(args.no_models*args.locframe_num):
            rank = test_in_id[d]
            filename=filelist[rank]
            print(filename.split('.')[0])
            name=filename.split('.')[0]
            test_in_name_list.append(name)

            df0 = pd.read_csv(args.dataPath+'\\'+name+'.csv')
            data = dataProcess(df0,features)
            DHGperday = data['DHGperday']
            DHGperday=DHGperday[int(np.floor(0.9*len(data))):-1]
            PT = data['PT,h'][int(np.floor(0.9*len(data))):-1]

            _ ,ts_mseloss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_in_dict[d], model, device, PT, DHGperday)
            test_in_mseloss_list.append(ts_mseloss)
            test_in_maeloss_list.append(ts_maeloss)
            test_in_len_list.append(len(data_list))

            data_c = np.hstack([np.array(data_list).reshape(-1,1), np.array(output_list).reshape(-1,1)])
            data_c = data_c.reshape(-1,2)
            columns = ['DHG', 'DHG_p']
            df = pd.DataFrame(data = data_c, columns = columns)
            df.to_csv(os.path.join(log_path,'{}.csv'.format(name)))

            figplt(60,6,data_list,output_list,log_path,name)

        mseloss_locnode=[]
        maeloss_locnode=[]
        if args.locframe_num != 1:
            test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
            test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
            test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
            for i in range(args.no_models):
                node_datanum = sum(test_in_len_list2[i])
                node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
                node_ts_mseloss = node_unbl_mseloss/node_datanum
                mseloss_locnode.append(node_ts_mseloss)
                node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
                node_ts_maeloss = node_unbl_maeloss/node_datanum
                maeloss_locnode.append(node_ts_maeloss)
        
        test_out_name_list=[]
        test_out_mseloss_list=[]
        test_out_maeloss_list=[]
        test_out_len_list=[]

        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testout'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)
            
        for j in range(args.testout_num):
            rank = testout_list[j]
            filename=filelist[rank]
            print(filename.split('.')[0])
            name=filename.split('.')[0]
            ##路径，计算loss，绘图
            test_out_name_list.append(name)

            df0 = pd.read_csv(args.dataPath+'\\'+name+'.csv')
            data = dataProcess(df0,features)
            DHGperday = data['DHGperday']
            PT = data['PT,h']

            _ ,ts_mseloss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_out_dict[j], model, device, PT, DHGperday)
            test_out_mseloss_list.append(ts_mseloss)
            test_out_maeloss_list.append(ts_maeloss)
            test_out_len_list.append(len(data_list))

            data_c = np.hstack([np.array(data_list).reshape(-1,1), np.array(output_list).reshape(-1,1)])
            data_c = data_c.reshape(-1,2)
            columns = ['DHG', 'DHG_p']
            df = pd.DataFrame(data = data_c, columns = columns)
            df.to_csv(os.path.join(log_path,'{}.csv'.format(name)))

            figplt(60,6,data_list,output_list,log_path,name)

        #记录,做表格
        filelist = os.listdir(args.dataPath)
        filelist = [ff for ff in filelist if ff.endswith('.csv')]
        filelist.sort()
        log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_in_mseloss_list[i]
            log_list[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_out_mseloss_list[j]
            log_list[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list[3][k] = mseloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df = pd.DataFrame(data = log_list)
        df=df.T
        df.rename(columns = columns,inplace=True)
        df.to_csv(os.path.join(arg_path,'mse.csv'))   
        
        #记录,做表格
        log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_in_maeloss_list[i]
            log_list2[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_out_maeloss_list[j]
            log_list2[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list2[3][k] = maeloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df2 = pd.DataFrame(data = log_list2)
        df2=df2.T
        df2.rename(columns = columns,inplace=True)
        df2.to_csv(os.path.join(arg_path,'mae.csv')) 

def loc_evaluate_entry(args, features, dataset_features, nodein_list, testout_list, data_ts_in_dict, data_ts_out_dict, device):

    ######################################################
    ###                path to save result             ###
    ###                                                ###
    ######################################################
    # str_lr = '_'.join(['lr', str(args.lr)])
    # str_seed = '_'.join(['seed', str(args.seed)])
    # args_dict =vars(args)
    # arg_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}'.format(args.global_epochs, str_lr, str_seed, args.no_models, args.locframe_num, args.fold_id)
    # if not os.path.exists(arg_path):
    #     os.makedirs(arg_path)    
    # with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
    #     for key, value in args_dict.items():
    #         f.write('{}:{}'.format(key, value))
    #         f.write('\n')
    
    ######################################################
    ###               2 loop to evaluate               ###
    ###                                                ###
    ######################################################

    filelist = os.listdir(args.dataPath)
    filelist = [ff for ff in filelist if ff.endswith('.csv')]
    filelist.sort()
    fpathlist = [os.path.join(args.dataPath,ff) for ff in filelist if ff.endswith('.csv')]
    print(filelist)

    test_in_id = [i for item in nodein_list for i in item]


    # ##路径，计算loss，绘图
    # log_path = args.logPath_ts + '_{}/{}/{}/{}clients/{}frames/fold_{}/testin'.format(args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id)
    # if not os.path.exists(log_path):
    #     os.makedirs(log_path)

    for k in range(args.no_models):
        str_lr = '_'.join(['lr', str(args.lr)])
        str_seed = '_'.join(['seed', str(args.seed)])
        modelpath = args.logPath + '/{}/lr_{}'.format(args.nyear, args.lr)
        print('**********************************************')
        if args.locframe_num==1:
            rank = test_in_id[k]
            filename=filelist[rank]
            print('model filename')
            print(filename.split('.')[0])
            print('')
            Name=filename.split('.')[0]
            model_path = modelpath + '/{}/{}clients/{}frames/{}/model'.format(str_seed,args.no_models,args.locframe_num,Name)
        else:
            Name=k
            print('model filename')
            print(Name)
            print('')
            model_path = modelpath + '/{}/{}clients/{}frames/fold{}/{}/model'.format(str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        
        args_dict =vars(args)
        arg_path = args.logPath_ts + '{}/_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}'.format(args.nyear, args.global_epochs, str_lr, str_seed, args.no_models, args.locframe_num, args.fold_id,Name)
        if not os.path.exists(arg_path):
            os.makedirs(arg_path)    
        with open(os.path.join(arg_path, 'args.txt'), 'w') as f:
            for key, value in args_dict.items():
                f.write('{}:{}'.format(key, value))
                f.write('\n')
        
        test_in_name_list=[]
        test_in_mseloss_list=[]
        test_in_maeloss_list=[]
        test_in_len_list=[]
        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '{}/_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testin'.format(args.nyear, args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)

        model = get_gru3(args).to(device)
        
        model_list=os.listdir(model_path)
        model_list.sort()
        modelname=model_list[-1]
        modelPath = os.path.join(model_path, modelname)
        model.load_state_dict(torch.load(modelPath))
    
        for d in range(args.no_models*args.locframe_num):
            rank = test_in_id[d]
            filename=filelist[rank]
            print(filename.split('.')[0])
            name=filename.split('.')[0]
            test_in_name_list.append(name)

            df0 = pd.read_csv(args.dataPath+'\\'+name+'.csv')
            data = dataProcess(df0,features)
            DHGperday = data['DHGperday']
            DHGperday=DHGperday[int(np.floor(0.9*len(data))):-1]
            PT = data['PT,h'][int(np.floor(0.9*len(data))):-1]

            _ ,ts_mseloss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_in_dict[d], model, device, PT, DHGperday)
            test_in_mseloss_list.append(ts_mseloss)
            test_in_maeloss_list.append(ts_maeloss)
            test_in_len_list.append(len(data_list))

            data_c = np.hstack([np.array(data_list).reshape(-1,1), np.array(output_list).reshape(-1,1)])
            data_c = data_c.reshape(-1,2)
            columns = ['DHG', 'DHG_p']
            df = pd.DataFrame(data = data_c, columns = columns)
            df.to_csv(os.path.join(log_path,'{}.csv'.format(name)))

            figplt(60,6,data_list,output_list,log_path,name)

        mseloss_locnode=[]
        maeloss_locnode=[]
        if args.locframe_num != 1:
            test_in_len_list2=[test_in_len_list[i:i+args.locframe_num] for i in range(0,len(test_in_len_list),args.locframe_num)]
            test_in_mseloss_list2=[test_in_mseloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_mseloss_list),args.locframe_num)]
            test_in_maeloss_list2=[test_in_maeloss_list[i:i+args.locframe_num] for i in range(0,len(test_in_maeloss_list),args.locframe_num)]
            for i in range(args.no_models):
                node_datanum = sum(test_in_len_list2[i])
                node_unbl_mseloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_mseloss_list2[i])])
                node_ts_mseloss = node_unbl_mseloss/node_datanum
                mseloss_locnode.append(node_ts_mseloss)
                node_unbl_maeloss = sum([a*b for a,b in zip(test_in_len_list2[i],test_in_maeloss_list2[i])])
                node_ts_maeloss = node_unbl_maeloss/node_datanum
                maeloss_locnode.append(node_ts_maeloss)
        
        test_out_name_list=[]
        test_out_mseloss_list=[]
        test_out_maeloss_list=[]
        test_out_len_list=[]

        ##路径，计算loss，绘图
        log_path = args.logPath_ts + '{}/_{}/{}/{}/{}clients/{}frames/fold_{}/name_{}/testout'.format(args.nyear, args.global_epochs, str_lr, str_seed,args.no_models,args.locframe_num,args.fold_id,Name)
        if not os.path.exists(log_path):
            os.makedirs(log_path)
            
        for j in range(args.testout_num):
            rank = testout_list[j]
            filename=filelist[rank]
            print(filename.split('.')[0])
            name=filename.split('.')[0]
            ##路径，计算loss，绘图
            test_out_name_list.append(name)

            df0 = pd.read_csv(args.dataPath+'\\'+name+'.csv')
            data = dataProcess(df0,features)
            DHGperday = data['DHGperday']
            PT = data['PT,h']

            _ ,ts_mseloss, ts_maeloss, data_list, output_list = predictCurve2(args, data_ts_out_dict[j], model, device, PT, DHGperday)
            test_out_mseloss_list.append(ts_mseloss)
            test_out_maeloss_list.append(ts_maeloss)
            test_out_len_list.append(len(data_list))

            data_c = np.hstack([np.array(data_list).reshape(-1,1), np.array(output_list).reshape(-1,1)])
            data_c = data_c.reshape(-1,2)
            columns = ['DHG', 'DHG_p']
            df = pd.DataFrame(data = data_c, columns = columns)
            df.to_csv(os.path.join(log_path,'{}.csv'.format(name)))

            figplt(60,6,data_list,output_list,log_path,name)

        #记录,做表格
        filelist = os.listdir(args.dataPath)
        filelist = [ff for ff in filelist if ff.endswith('.csv')]
        filelist.sort()
        log_list=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_in_mseloss_list[i]
            log_list[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list[0][id_]=filelist[id_]
            log_list[1][id_]=test_out_mseloss_list[j]
            log_list[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list[3][k] = mseloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df = pd.DataFrame(data = log_list)
        df=df.T
        df.rename(columns = columns,inplace=True)
        df.to_csv(os.path.join(arg_path,'mse.csv'))   
        
        #记录,做表格
        log_list2=[[None for _ in range(args.dataframes)]for _ in range(4)]
        for i in range(args.no_models*args.locframe_num):
            id_ = test_in_id[i]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_in_maeloss_list[i]
            log_list2[2][id_]=int(i/args.locframe_num+1)
        for j in range(args.testout_num):
            id_ = testout_list[j]
            log_list2[0][id_]=filelist[id_]
            log_list2[1][id_]=test_out_maeloss_list[j]
            log_list2[2][id_]=0
        if args.locframe_num != 1:
            for k in range(args.no_models):
                log_list2[3][k] = maeloss_locnode[k]
        columns = {0:'name',1:'ts_loss', 2:'ifin',3:'ts_nodeloss'}
        df2 = pd.DataFrame(data = log_list2)
        df2=df2.T
        df2.rename(columns = columns,inplace=True)
        df2.to_csv(os.path.join(arg_path,'mae.csv'))