#!/bin/bash 

function usage() 
{
    echo " Usage : "
    echo "   bash swarm_run.sh deploy parameter_len individual_list_address "
    echo "   bash swarm_run.sh append append_individual_list_address "
    echo "   bash swarm_run.sh merge "
    echo "   bash swarm_run.sh renew swarm_parameter_address individual_rank "
    echo " "
    echo " "
    echo "examples : "
    echo "   bash swarm_run.sh deploy 100 C:\\Users\\Administrator\\Desktop\\01.txt "
    echo "   bash swarm_run.sh append  C:\\Users\\Administrator\\Desktop\\01.txt "
    echo "   bash swarm_run.sh renew  C:\\Users\\Administrator\\Desktop\\01.txt  0 "
    echo "   bash swarm_run.sh merge "
    exit 0
}

    case $1 in
    deploy)
            [ $# -lt 3 ] && { usage; }
            ;;
    append)
            [ $# -lt 2 ] && { usage; }
            ;;
    merge)
            [ $# -lt 1 ] && { usage; }
            ;;
    renew)
            [ $# -lt 3 ] && { usage; }
            ;;
    *)
        usage
            ;;
    esac

    java -Djdk.tls.namedGroups="secp256k1" -cp 'apps/*:conf/:lib/*' org.fisco.bcos.swarm.client.SwarmClient $@

