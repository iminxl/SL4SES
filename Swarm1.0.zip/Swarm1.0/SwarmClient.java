package org.fisco.bcos.swarm.client;

import java.io.*;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.fisco.bcos.swarm.contract.Swarm;
import org.fisco.bcos.sdk.v3.BcosSDK;
import org.fisco.bcos.sdk.v3.client.Client;
import org.fisco.bcos.sdk.v3.codec.datatypes.generated.tuples.generated.Tuple2;
import org.fisco.bcos.sdk.v3.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.v3.model.TransactionReceipt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class SwarmClient {

    static Logger logger = LoggerFactory.getLogger(SwarmClient.class);

    private BcosSDK bcosSDK;
    private Client client;
    private CryptoKeyPair cryptoKeyPair;

    public void initialize() {
        @SuppressWarnings("resource")
        ApplicationContext context =
                new ClassPathXmlApplicationContext("classpath:applicationContext.xml");

        
        bcosSDK = context.getBean(BcosSDK.class);
        client = bcosSDK.getClient();
        cryptoKeyPair = client.getCryptoSuite().getCryptoKeyPair();
        client.getCryptoSuite().setCryptoKeyPair(cryptoKeyPair);
        logger.debug("create client for group, account address is {}", cryptoKeyPair.getAddress());
    }

    public static List<String> readFile(String address) throws IOException {
        File file = new File(address);
        BufferedReader in = new BufferedReader(new FileReader(file)); //
        String line; // 一行数据
        List<String> myList = new ArrayList<String>();
        StringBuilder sb1 = new StringBuilder();// 定义一个字符串缓存，将字符串存放缓存中
        while ((line = in.readLine()) != null) {// 逐行读取文件内容，不读取换行符和末尾的空格
            myList.add(line);
            sb1.append(line + "\n");// 将读取的字符串添加换行符后累加存放在缓存中
            System.out.println(line);
        }
        in.close();

        // 显示读出的字符串
        String str1 = sb1.toString();
        System.out.println(str1);
        return myList;
    }

    public static List<BigInteger> readFile(String address, Integer num) throws IOException {
        File file = new File(address);
        BufferedReader in = new BufferedReader(new FileReader(file)); //
        String line; // 一行数据
        int n = num;
        int[] arr2 = new int[n]; // 读取出的数组
        int row = 0;
        // 逐行读取，并将每个数组放入到数组中
        while ((line = in.readLine()) != null) {
            String[] temp = line.split("\t");
            for (int j = 0; j < temp.length; j++) {
                // Integer.parseInt() Double.parseDouble(
                arr2[row] = Integer.parseInt(temp[j]);
            }
            row++;
        }
        in.close();

        // 显示读取出的数组
        for (int i = 0; i < n; i++) {
            
            System.out.print(arr2[i] + "\t");
            
            System.out.println();
        }

        List<BigInteger> list = new ArrayList<BigInteger>();
        int flag = 0;
        for(int a:arr2){
            BigInteger i=BigInteger.valueOf(a);
            list.add(flag,i);
            flag+=1;
        }
        return list;
    }

    public static void writeFile(String address, int[][] arr) throws IOException {
        int num = arr.length;
        int wid = arr[0].length;
        File file = new File(address);
        FileWriter out = new FileWriter(file);
        // 将数组中的数据写入到文件中。每行各数据之间TAB间隔
        for (int i = 0; i < num; i++) {
            for (int j = 0; j < wid; j++) {
                out.write(arr[i][j] + "\t");
            }
            out.write("\r\n");
        }
        out.flush();
        out.close();
    }
    
    public static byte[] str2byte(String str) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        char[] charArray = str.toCharArray();
        for (char c : charArray) {
            String charToHex = Integer.toHexString(c);
            stringBuilder.append(charToHex);
        }
        System.out.println("Converted Hex from String: "+stringBuilder.toString());
        byte[] bytes=new byte[(int)64];
        for(int ijk=0;ijk<stringBuilder.toString().length();ijk ++){
            bytes[ijk]=(byte) stringBuilder.toString().charAt(ijk);
        };
        return bytes;
    }

    public static List<byte[]> generaListBytes(Integer num,Integer len) throws IOException {
        //list<byte[]>
        List<byte[]> elementListPre = new ArrayList<byte[]>();
        // 初始化elementList数据
        for (int ij = 0; ij < num; ij ++) {

            // 将byte[]放在里面，修改的时候才不会出现一个改全部变的情况
            byte[] byt = new byte[len];
            elementListPre.add(ij, byt);

        }
        return elementListPre;
    }
    public void deploySwarmAndRecordAddr(BigInteger num, String address) {

        try {
            //这个地方先把用户列表txt读进来，address代表地址
            //read txt
            List<String> myList = readFile(address);
            List<byte[]> individualNames = generaListBytes(myList.size(), 64);
            for (int ij = 0; ij < myList.size(); ij++) {
                individualNames.set(ij, str2byte(myList.get(ij)));
            }
            System.out.println("indiv"+individualNames);
            System.out.println("num"+num);
            System.out.println(individualNames.getClass().getName());
            //创建账户
            Swarm swarm = Swarm.deploy(client, cryptoKeyPair, myList, num);
            System.out.println(
                    " deploy Swarm success, contract address is " + swarm.getContractAddress());
            recordSwarmAddr(swarm.getContractAddress());
        } catch (Exception e) {
            System.out.println(" deploy Swarm contract failed, error message is  " + e.getMessage());
        }
    }

    public void recordSwarmAddr(String address) throws IOException {
        Properties prop = new Properties();
        prop.setProperty("address", address);
        final Resource contractResource = new ClassPathResource("contract.properties");
        try (FileOutputStream fileOutputStream = new FileOutputStream(contractResource.getFile())) {
            prop.store(fileOutputStream, "contract address");
        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
        }
    }

    public String loadSwarmAddr() throws Exception {
        // load Swarm contact address from contract.properties
        Properties prop = new Properties();
        final Resource contractResource = new ClassPathResource("contract.properties");
        prop.load(contractResource.getInputStream());

        String contractAddress = prop.getProperty("address");
        if (contractAddress == null || contractAddress.trim().equals("")) {
            throw new Exception(" load Swarm contract address failed, please deploy it first. ");
        }
        logger.info(" load Swarm address from contract.properties, address is {}", contractAddress);
        return contractAddress;
    }

    public void appendSwarmIndiv(String swarmIndivAddr) {
        try {
            String contractAddress = loadSwarmAddr();
            Swarm swarm = Swarm.load(contractAddress, client, cryptoKeyPair);
            //读取swarm用户
            List<String> myList = readFile(swarmIndivAddr);
            List<byte[]> swarmIndiv = generaListBytes(myList.size(), 64);
            for (int ij = 0; ij < myList.size(); ij++) {
                swarmIndiv.set(ij, str2byte(myList.get(ij)));
            }
            TransactionReceipt receipt = swarm.append(myList);

        } catch (Exception e) {
            logger.error(" appendSwarmIndiv exception, error message is {}", e.getMessage());

            System.out.printf(" append swarm indiv failed, error message is %s%n", e.getMessage());
        }
    }

    public void mergeSwarmPara() {
        try {
            String contractAddress = loadSwarmAddr();
            Swarm swarm = Swarm.load(contractAddress, client, cryptoKeyPair);
            TransactionReceipt receipt = swarm.merge();
            Tuple2<BigInteger, List<BigInteger>> result = swarm.getMergeOutput(receipt);
            //不确定是不是这样写
            List<BigInteger> merdpara=result.getValue2();
            int n = merdpara.size();
            int m = 1;
            int[][] arr =new int[n][m];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    arr[i][j] = merdpara.get(i).intValue();
                    // System.out.println(arr[i][j]);
                }
            }
            writeFile("/Users/xulei/Desktop/java_io/array.txt",arr);
            System.out.println("finish");
        } catch (Exception e) {
            logger.error(" mergeSwarmPara exception, error message is {}", e.getMessage());

            System.out.printf(" merge swarm para failed, error message is %s%n", e.getMessage());
        }
    }

    public void renewSwarmIndiv(String swarmParaAddr, BigInteger rank) {
        try {
            String contractAddress = loadSwarmAddr();
            Swarm swarm = Swarm.load(contractAddress, client, cryptoKeyPair);
            //从swarmParaAddr读取参数
            BigInteger i = swarm.paralen();
            List<BigInteger> swarmPara = readFile(swarmParaAddr,i.intValue());
            TransactionReceipt receipt = swarm.renew(swarmPara,rank);
        } catch (Exception e) {
            logger.error(" renewSwarmIndiv exception, error message is {}", e.getMessage());

            System.out.printf(" renew swarm indiv failed, error message is %s%n", e.getMessage());
        }
    }

    public static void Usage() {
        System.out.println(" Usage:");
        System.out.println(
                "\t java -cp 'conf/:lib/*:apps/*' org.fisco.bcos.swarm.client.SwarmClient deploy parameter_len individual_list_address");
        System.out.println(
                "\t java -cp 'conf/:lib/*:apps/*' org.fisco.bcos.swarm.client.SwarmClient append append_individual_list_address");
        System.out.println(
                "\t java -cp 'conf/:lib/*:apps/*' org.fisco.bcos.swarm.client.SwarmClient merge");
        System.out.println(
                "\t java -cp 'conf/:lib/*:apps/*' org.fisco.bcos.swarm.client.SwarmClient renew swarm_parameter_address individual_rank");
        System.exit(0);
    }

    public static void main(String[] args) throws Exception {

        if (args.length < 1) {
            Usage();
        }

        SwarmClient client = new SwarmClient();
        client.initialize();
        System.out.println("initialize over");

        switch (args[0]) {
            case "deploy":
                if (args.length < 3) {
                    Usage();
                }
                client.deploySwarmAndRecordAddr(new BigInteger(args[1]), args[2]);
                break;
            case "append":
                if (args.length < 2) {
                    Usage();
                }
                client.appendSwarmIndiv(args[1]);
                break;
            case "merge":
                client.mergeSwarmPara();
                break;
            case "renew":
                if (args.length < 3) {
                    Usage();
                }
                client.renewSwarmIndiv(args[1], new BigInteger(args[2]));
                break;
            default: {
                Usage();
            }
        }
        System.exit(0);
    }
}
